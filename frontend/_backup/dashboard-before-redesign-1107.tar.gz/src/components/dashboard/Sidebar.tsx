"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LogoMark } from "@/components/landing/icons";

/* ------------------------------------------------------------------ */
/* Navigation data                                                     */
/* ------------------------------------------------------------------ */
export const moduleNav = [
  { href: "/dashboard",                label: "Overview",           color: "#0f172a", exact: true },
  { href: "/dashboard/bunkerflow",     label: "BunkerFlow",         color: "#0284c7" },
  { href: "/dashboard/pipe-integrity", label: "PipeIntegrity",      color: "#059669" },
  { href: "/dashboard/refinery-link",  label: "RefineryLink",       color: "#d97706" },
  { href: "/dashboard/haul-trac",      label: "HaulTrac",           color: "#7c3aed" },
  { href: "/dashboard/epc-link",       label: "EPC-Link",           color: "#0891b2" },
  { href: "/dashboard/safe-pass",      label: "SafePass",           color: "#dc2626" },
  { href: "/dashboard/marine-stores",  label: "MarineStores",       color: "#0e7490" },
  { href: "/dashboard/tank-works",     label: "TankWorks",          color: "#ca8a04" },
  { href: "/dashboard/compliance-shield", label: "Compliance Shield", color: "#4f46e5" },
  { href: "/dashboard/billing",        label: "Billing",            color: "#64748b" },
  { href: "/dashboard/client-portal",  label: "Client Portal",      color: "#0369a1" },
];

/* ------------------------------------------------------------------ */
/* Sidebar                                                             */
/* ------------------------------------------------------------------ */
export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  function isActive(item: typeof moduleNav[0]) {
    if (item.exact) return pathname === item.href;
    return pathname.startsWith(item.href);
  }

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-40 flex flex-col bg-white border-r border-slate-200 transition-all duration-300 ease-[cubic-bezier(0.2,0.8,0.2,1)] ${
        collapsed ? "w-[72px]" : "w-[248px]"
      }`}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-slate-100">
        <LogoMark size={32} className="shrink-0" />
        {!collapsed && (
          <span className="leading-none overflow-hidden whitespace-nowrap">
            <span className="block text-[13px] font-extrabold uppercase tracking-[0.08em] text-slate-900">
              Petro<span className="text-emerald-600">Ledger</span>
            </span>
            <span className="mt-0.5 block text-[8px] font-bold uppercase tracking-[0.32em] text-emerald-700">
              Energy OS
            </span>
          </span>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1 no-scrollbar">
        {!collapsed && (
          <p className="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
            Platform
          </p>
        )}

        {moduleNav.slice(0, 1).map((item) => {
          const active = isActive(item);
          return (
            <Link
              key={item.href}
              href={item.href}
              title={collapsed ? item.label : undefined}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-medium transition-all duration-200 group ${
                active
                  ? "bg-emerald-50/80 text-emerald-800 font-semibold"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              } ${collapsed ? "justify-center" : ""}`}
            >
              <span
                className={`h-2 w-2 rounded-full shrink-0 transition-all duration-200 ${active ? "scale-125" : "group-hover:scale-110"}`}
                style={{ backgroundColor: active ? "#059669" : item.color }}
              />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          );
        })}

        {/* Modules section */}
        {!collapsed && (
          <p className="px-3 pt-5 pb-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
            Modules
          </p>
        )}
        {collapsed && <div className="pt-3 mb-1 mx-auto w-6 border-t border-slate-200" />}

        {moduleNav.slice(1).map((item) => {
          const active = isActive(item);
          return (
            <Link
              key={item.href}
              href={item.href}
              title={collapsed ? item.label : undefined}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-medium transition-all duration-200 group ${
                active
                  ? "bg-emerald-50/80 text-emerald-800 font-semibold"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              } ${collapsed ? "justify-center" : ""}`}
            >
              <span
                className={`h-2 w-2 rounded-full shrink-0 transition-all duration-200 ${active ? "scale-125" : "group-hover:scale-110"}`}
                style={{ backgroundColor: active ? "#059669" : item.color }}
              />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Bottom: collapse toggle */}
      <div className="border-t border-slate-100 px-3 py-3">
        <button
          type="button"
          onClick={() => setCollapsed((c) => !c)}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium text-slate-500 hover:bg-slate-50 hover:text-slate-700 transition"
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <svg
            width={16}
            height={16}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.7}
            strokeLinecap="round"
            strokeLinejoin="round"
            className={`shrink-0 transition-transform duration-300 ${collapsed ? "rotate-180" : ""}`}
          >
            <path d="M11 17l-5-5 5-5M18 17l-5-5 5-5" />
          </svg>
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  );
}
