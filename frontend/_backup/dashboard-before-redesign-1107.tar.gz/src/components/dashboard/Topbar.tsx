"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { moduleNav } from "./Sidebar";

export function Topbar({
  onOpenSearch,
  onOpenAstm,
}: {
  onOpenSearch?: () => void;
  onOpenAstm?: () => void;
}) {
  const pathname = usePathname();
  const [showNotif, setShowNotif] = useState(false);
  const [showUser, setShowUser] = useState(false);

  /* Build breadcrumb from pathname */
  const crumbs = pathname
    .split("/")
    .filter(Boolean)
    .map((seg, i, arr) => {
      const href = "/" + arr.slice(0, i + 1).join("/");
      const mod = moduleNav.find((m) => m.href === href);
      const label = mod?.label ?? seg.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
      return { href, label };
    });

  /* Mock notifications */
  const notifications = [
    { id: 1, title: "Certificate expiry alert", desc: "3 crew BOSIET certificates expire within 30 days", time: "12 min ago", tone: "crit" as const },
    { id: 2, title: "Reconciliation complete", desc: "Depot BK-04 monthly reconciliation shows 0.12% variance", time: "1 hr ago", tone: "ok" as const },
    { id: 3, title: "PTW pending approval", desc: "Hot work permit HW-2026-0412 awaiting sign-off", time: "2 hr ago", tone: "warn" as const },
  ];

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-4 bg-white/90 backdrop-blur-md border-b border-slate-200 px-6 py-3">
      {/* Breadcrumbs */}
      <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-[13px] min-w-0">
        {crumbs.map((c, i) => (
          <span key={c.href} className="flex items-center gap-1.5 min-w-0">
            {i > 0 && (
              <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="text-slate-300 shrink-0">
                <path d="m9 6 6 6-6 6" />
              </svg>
            )}
            {i === crumbs.length - 1 ? (
              <span className="font-semibold text-slate-900 truncate">{c.label}</span>
            ) : (
              <Link href={c.href} className="text-slate-500 hover:text-slate-700 transition truncate">
                {c.label}
              </Link>
            )}
          </span>
        ))}
      </nav>

      {/* Right actions */}
      <div className="flex items-center gap-2">
        {/* Search trigger */}
        <button
          type="button"
          onClick={onOpenSearch}
          className="hidden sm:flex items-center gap-2.5 rounded-xl bg-slate-50 border border-slate-200 px-3 py-1.5 w-[220px] text-left text-sm text-slate-400 hover:border-slate-300 hover:bg-slate-100/60 transition-all duration-200"
        >
          <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="text-slate-400 shrink-0">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
          </svg>
          <span className="flex-1 text-[13px] truncate">Search records…</span>
          <kbd className="hidden md:inline text-[10px] font-mono text-slate-400 border border-slate-200 bg-white rounded px-1.5 py-0.5">⌘K</kbd>
        </button>

        {/* ASTM 54B Tool button */}
        {onOpenAstm && (
          <button
            type="button"
            onClick={onOpenAstm}
            className="hidden md:flex items-center gap-1.5 rounded-xl border border-sky-200 bg-sky-50 px-2.5 py-1.5 text-[12px] font-semibold text-sky-800 hover:bg-sky-100 transition"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-sky-600" />
            <span>ASTM 54B</span>
          </button>
        )}

        {/* Notifications */}
        <div className="relative">
          <button
            type="button"
            onClick={() => { setShowNotif(!showNotif); setShowUser(false); }}
            className="relative grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition"
            aria-label="Notifications"
          >
            <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0" />
            </svg>
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-rose-500 text-[9px] font-bold text-white flex items-center justify-center">
              3
            </span>
          </button>

          {/* Notification dropdown */}
          {showNotif && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowNotif(false)} />
              <div className="absolute right-0 top-full mt-2 w-[340px] rounded-2xl border border-slate-200 bg-white shadow-xl z-50 overflow-hidden modal-in">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
                  <p className="text-[13px] font-bold text-slate-900">Notifications</p>
                  <span className="text-[11px] font-semibold text-emerald-600 cursor-pointer hover:text-emerald-700 transition">
                    Mark all read
                  </span>
                </div>
                <div className="max-h-[320px] overflow-y-auto">
                  {notifications.map((n) => (
                    <div key={n.id} className="flex items-start gap-3 px-4 py-3 hover:bg-slate-50/70 transition cursor-pointer border-b border-slate-50 last:border-0">
                      <span className={`mt-1.5 h-2 w-2 rounded-full shrink-0 ${
                        n.tone === "ok" ? "bg-emerald-500" : n.tone === "crit" ? "bg-rose-500" : "bg-amber-500"
                      }`} />
                      <div className="min-w-0">
                        <p className="text-[13px] font-semibold text-slate-800 truncate">{n.title}</p>
                        <p className="text-[12px] text-slate-500 mt-0.5 line-clamp-2">{n.desc}</p>
                        <p className="text-[11px] text-slate-400 mt-1">{n.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* User avatar */}
        <div className="relative">
          <button
            type="button"
            onClick={() => { setShowUser(!showUser); setShowNotif(false); }}
            className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 hover:bg-slate-50 transition"
          >
            <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-[11px] font-bold text-white shrink-0">
              EO
            </div>
            <div className="hidden md:block text-left min-w-0">
              <p className="text-[12px] font-semibold text-slate-800 truncate">Emeka Okafor</p>
              <p className="text-[10px] text-slate-400 truncate">Edflo Energy • MD</p>
            </div>
            <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" className="text-slate-400 shrink-0 hidden md:block">
              <path d="m6 9 6 6 6-6" />
            </svg>
          </button>

          {/* User dropdown */}
          {showUser && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowUser(false)} />
              <div className="absolute right-0 top-full mt-2 w-[220px] rounded-2xl border border-slate-200 bg-white shadow-xl z-50 overflow-hidden modal-in p-2">
                <div className="px-3 py-2 border-b border-slate-100 mb-1">
                  <p className="text-[12px] font-semibold text-slate-900">Emeka Okafor</p>
                  <p className="text-[11px] text-slate-400">emeka@edfloenergy.com</p>
                  <span className="mt-1 inline-block text-[9.5px] font-mono bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded">Enterprise Tier</span>
                </div>
                {[
                  { label: "Profile & Role Security", href: "/dashboard" },
                  { label: "Offline SQLite Cache", href: "/dashboard" },
                  { label: "Audit Log Trail", href: "/dashboard" },
                ].map((a) => (
                  <Link
                    key={a.label}
                    href={a.href}
                    onClick={() => setShowUser(false)}
                    className="flex items-center rounded-lg px-3 py-2 text-[12.5px] font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition"
                  >
                    {a.label}
                  </Link>
                ))}
                <div className="my-1 border-t border-slate-100" />
                <Link
                  href="/login"
                  className="flex items-center rounded-lg px-3 py-2 text-[12.5px] font-medium text-rose-600 hover:bg-rose-50 transition"
                >
                  Sign out
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
