"use client";

import { useState, useEffect } from "react";

export function StatusBar({ onOpenAstm }: { onOpenAstm?: () => void }) {
  const [online, setOnline] = useState(true);
  const [lastSync, setLastSync] = useState("Just now");
  const [cachedRecords, setCachedRecords] = useState(148);

  useEffect(() => {
    const timer = setInterval(() => {
      setLastSync(`${Math.floor(Math.random() * 8 + 2)}s ago`);
    }, 15000);
    return () => clearInterval(timer);
  }, []);

  return (
    <footer className="sticky bottom-0 z-30 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200/90 bg-white/95 px-4 sm:px-6 py-2.5 backdrop-blur-md text-[12px] text-slate-600">
      {/* Left: Node & Connection Heartbeat */}
      <div className="flex items-center gap-3 sm:gap-4 flex-wrap">
        <button
          type="button"
          onClick={() => setOnline(!online)}
          title="Click to toggle offline mode simulation"
          className="flex items-center gap-2 group cursor-pointer"
        >
          <span
            className={`relative flex h-2 w-2 rounded-full ${
              online ? "bg-emerald-500" : "bg-amber-500"
            }`}
          >
            {online && (
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            )}
          </span>
          <span className="font-semibold text-slate-800">
            {online ? "Lekki Terminal Node 04" : "Field Mode (Offline)"}
          </span>
          <span className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[10.5px] font-mono text-slate-500 group-hover:bg-slate-200 transition">
            {online ? "Online" : "Cached"}
          </span>
        </button>

        <span className="hidden sm:inline text-slate-300">|</span>

        {/* SQLite Cache */}
        <div className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-sky-500" />
          <span className="font-medium text-slate-700">
            {cachedRecords} records
          </span>
          <span className="text-slate-400 font-mono text-[11px]">SQLite sync</span>
        </div>

        <span className="hidden sm:inline text-slate-300">|</span>

        {/* Last Sync */}
        <div className="hidden md:flex items-center gap-1.5 text-slate-500">
          <span>Delta sync:</span>
          <span className="font-mono text-slate-700 font-medium">{lastSync}</span>
        </div>
      </div>

      {/* Right: Currency Rate & Tools */}
      <div className="flex items-center gap-3 sm:gap-4 ml-auto">
        {/* NGN / USD Rate Snapshot */}
        <div className="flex items-center gap-1.5 rounded-lg bg-slate-50 border border-slate-200/80 px-2.5 py-1 font-mono text-[11px]">
          <span className="text-slate-400">FX Snapshot:</span>
          <span className="font-semibold text-slate-800">$1 = ₦1,480.00</span>
          <span className="text-[9.5px] text-emerald-600 font-sans font-bold uppercase tracking-wider">CBN/NUPRC</span>
        </div>

        {/* ASTM 54B Quick Trigger */}
        {onOpenAstm && (
          <button
            type="button"
            onClick={onOpenAstm}
            className="flex items-center gap-1.5 rounded-lg border border-sky-200 bg-sky-50/80 px-2.5 py-1 text-[11.5px] font-semibold text-sky-800 hover:bg-sky-100 transition"
          >
            <span className="h-1.5 w-1.5 rounded-sm bg-sky-600" />
            <span>ASTM 54B Calc</span>
          </button>
        )}

        {/* SHA-256 Audit Seal */}
        <div className="hidden lg:flex items-center gap-1.5 text-slate-400 text-[11px]">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          <span className="font-mono">Audit Log: SHA-256 Verified</span>
        </div>
      </div>
    </footer>
  );
}
