"use client";

import { useState } from "react";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */
const kpis = [
  { label: "Avg. Turnaround", value: "4.2 hrs", change: "-12%", tone: "ok" as const, sub: "vs. 4.8 hrs last month" },
  { label: "Shrinkage Rate", value: "0.18%", change: "-0.04%", tone: "ok" as const, sub: "Below 0.5% threshold" },
  { label: "Reconciliation", value: "98.6%", change: "+1.2%", tone: "ok" as const, sub: "42 of 42 depots reconciled" },
  { label: "Certificate Risk", value: "7", change: "+3", tone: "warn" as const, sub: "Expiring within 30 days" },
  { label: "Fleet Utilization", value: "87%", change: "+5%", tone: "ok" as const, sub: "62 of 71 trucks active" },
  { label: "Active Permits", value: "14", change: "0", tone: "ok" as const, sub: "All within validity" },
];

const exceptions = [
  { id: 1, tone: "crit" as const, title: "Variance over 0.5%", desc: "Depot BK-07 Lekki discharge — 0.72% volume loss detected on truck NG-LAG-4412.", time: "14 min ago" },
  { id: 2, tone: "crit" as const, title: "Failed gas test", desc: "H₂S reading at 12 ppm — confined space entry blocked at Tank TK-09, Apapa.", time: "28 min ago" },
  { id: 3, tone: "warn" as const, title: "BOSIET expiry warning", desc: "3 crew members BOSIET certificates expire within 21 days — offshore manifest blocked.", time: "1 hr ago" },
  { id: 4, tone: "warn" as const, title: "Pig velocity deviation", desc: "Trunkline TL-04 pig run PG-19 below plan velocity at KP-38. Receiver crew notified.", time: "2 hr ago" },
  { id: 5, tone: "warn" as const, title: "Route deviation alert", desc: "Truck NG-ABJ-0091 deviated 4.2 km from approved route on Lekki-Epe corridor.", time: "3 hr ago" },
];

const activity = [
  { time: "10:42", label: "e-BDN BDN-2026-0419 signed", module: "BunkerFlow", tone: "ok" as const },
  { time: "10:38", label: "Hydrotest hold period passed", module: "PipeIntegrity", tone: "ok" as const },
  { time: "10:31", label: "Truck NG-LAG-4418 dispatched", module: "HaulTrac", tone: "ok" as const },
  { time: "10:24", label: "PTW HW-2026-0413 approved", module: "SafePass", tone: "ok" as const },
  { time: "10:15", label: "NCFCC renewal submitted", module: "EPC-Link", tone: "ok" as const },
  { time: "10:08", label: "Gantry meter ticket reconciled", module: "RefineryLink", tone: "ok" as const },
  { time: "09:55", label: "Lube order PO-2026-1102 placed", module: "MarineStores", tone: "ok" as const },
  { time: "09:42", label: "Tank TK-06 cleaning completed", module: "TankWorks", tone: "ok" as const },
];

const moduleMetrics = [
  { label: "BunkerFlow", value: "3,420 MT", sub: "Delivered today", color: "#0284c7", pct: 82 },
  { label: "HaulTrac", value: "48 trips", sub: "Completed today", color: "#7c3aed", pct: 68 },
  { label: "PipeIntegrity", value: "2 runs", sub: "Pig runs active", color: "#059669", pct: 45 },
  { label: "SafePass", value: "14 active", sub: "Permits issued", color: "#dc2626", pct: 92 },
  { label: "RefineryLink", value: "₦42.8M", sub: "Throughput value", color: "#d97706", pct: 74 },
  { label: "ComplianceShield", value: "96%", sub: "Certificate coverage", color: "#4f46e5", pct: 96 },
];

/* ------------------------------------------------------------------ */
/* Mini sparkline (pure CSS)                                           */
/* ------------------------------------------------------------------ */
function Sparkline({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;

  return (
    <div className="flex items-end gap-[2px] h-8">
      {data.map((v, i) => (
        <div
          key={i}
          className="w-[3px] rounded-full transition-all duration-500"
          style={{
            height: `${Math.max(12, ((v - min) / range) * 100)}%`,
            backgroundColor: color,
            opacity: 0.3 + ((v - min) / range) * 0.7,
            animationDelay: `${i * 60}ms`,
          }}
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Owner Dashboard                                                     */
/* ------------------------------------------------------------------ */
export default function DashboardPage() {
  const [timeRange, setTimeRange] = useState("today");

  return (
    <div className="space-y-6 max-w-[1400px]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-2 rounded-lg border border-emerald-200/90 bg-emerald-50/80 px-2.5 py-1 text-[11px] font-bold uppercase tracking-[0.16em] text-emerald-800">
            <span className="h-1.5 w-1.5 rounded-sm bg-emerald-600" />
            Owner Dashboard
          </span>
          <h1 className="mt-3 text-[1.65rem] font-extrabold tracking-[-0.03em] text-slate-900">
            Operations Overview
          </h1>
          <p className="mt-1 text-[14px] text-slate-500">
            Live cross-module KPIs, exceptions, and activity feed.
          </p>
        </div>

        {/* Time range toggle */}
        <div className="flex items-center rounded-xl bg-slate-100/80 border border-slate-200/70 p-1">
          {["today", "7d", "30d", "90d"].map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setTimeRange(r)}
              className={`rounded-lg px-3.5 py-1.5 text-[12px] font-semibold transition ${
                timeRange === r
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-500 hover:text-slate-700"
              }`}
            >
              {r === "today" ? "Today" : r}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {kpis.map((kpi) => (
          <div
            key={kpi.label}
            className="rounded-2xl bg-white border border-slate-200 p-5 hover:shadow-[0_4px_20px_rgba(0,0,0,0.04)] transition-shadow duration-300"
          >
            <div className="flex items-start justify-between">
              <p className="text-[12px] font-semibold text-slate-500 uppercase tracking-wide">{kpi.label}</p>
              <span
                className={`inline-flex items-center rounded-md px-1.5 py-0.5 text-[11px] font-bold ring-1 ${
                  kpi.tone === "ok"
                    ? "bg-emerald-50 text-emerald-700 ring-emerald-200/80"
                    : kpi.tone === "warn"
                    ? "bg-amber-50 text-amber-700 ring-amber-200/80"
                    : "bg-rose-50 text-rose-700 ring-rose-200/80"
                }`}
              >
                {kpi.change}
              </span>
            </div>
            <p className="mt-2 text-[1.7rem] font-extrabold tracking-[-0.03em] text-slate-900">
              {kpi.value}
            </p>
            <p className="mt-1 text-[12px] text-slate-400">{kpi.sub}</p>
            <div className="mt-3">
              <Sparkline
                data={[4, 6, 5, 8, 7, 9, 6, 8, 10, 7, 9, 11]}
                color={kpi.tone === "ok" ? "#10b981" : kpi.tone === "warn" ? "#f59e0b" : "#ef4444"}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Module Performance + Exceptions split */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
        {/* Module Metrics */}
        <div className="xl:col-span-3 rounded-2xl bg-white border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-[14px] font-bold text-slate-900">Module Performance</h2>
            <span className="text-[11px] text-slate-400 font-medium">Real-time</span>
          </div>
          <div className="space-y-4">
            {moduleMetrics.map((m) => {
              const href = `/dashboard/${m.label.toLowerCase().replace(/\s+/g, "-")}`;
              return (
                <a
                  key={m.label}
                  href={href}
                  className="flex items-center gap-4 group p-2 -mx-2 rounded-xl hover:bg-slate-50 transition"
                >
                  <span
                    className="h-2.5 w-2.5 rounded-full shrink-0 group-hover:scale-125 transition-transform"
                    style={{ backgroundColor: m.color }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-[13px] font-semibold text-slate-700 group-hover:text-slate-900 transition truncate">
                        {m.label}
                      </p>
                      <p className="text-[13px] font-bold text-slate-900 tabular-nums">{m.value}</p>
                    </div>
                    <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-1000 ease-out"
                        style={{
                          width: `${m.pct}%`,
                          backgroundColor: m.color,
                          opacity: 0.7,
                        }}
                      />
                    </div>
                    <p className="mt-1 text-[11px] text-slate-400">{m.sub}</p>
                  </div>
                </a>
              );
            })}
          </div>
        </div>

        {/* Exception Feed */}
        <div className="xl:col-span-2 rounded-2xl bg-white border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[14px] font-bold text-slate-900">Exception Feed</h2>
            <span className="inline-flex items-center rounded-md bg-rose-50 px-1.5 py-0.5 text-[11px] font-bold text-rose-700 ring-1 ring-rose-200/80">
              {exceptions.length} active
            </span>
          </div>
          <div className="space-y-0.5 max-h-[440px] overflow-y-auto no-scrollbar">
            {exceptions.map((ex) => (
              <div
                key={ex.id}
                className="flex items-start gap-3 rounded-xl px-3 py-3 hover:bg-slate-50/70 transition cursor-pointer"
              >
                <span
                  className={`mt-1.5 h-2 w-2 rounded-full shrink-0 ${
                    ex.tone === "crit" ? "bg-rose-500" : "bg-amber-500"
                  }`}
                />
                <div className="min-w-0">
                  <p className="text-[13px] font-semibold text-slate-800">{ex.title}</p>
                  <p className="text-[12px] text-slate-500 mt-0.5 line-clamp-2">{ex.desc}</p>
                  <p className="text-[11px] text-slate-400 mt-1">{ex.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Activity Timeline */}
      <div className="rounded-2xl bg-white border border-slate-200 p-5">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-[14px] font-bold text-slate-900">Recent Activity</h2>
          <span className="text-[12px] font-mono text-slate-400">
            Real-time Audit Trail
          </span>
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-[19px] top-2 bottom-2 w-px bg-slate-200" />

          <div className="space-y-0">
            {activity.map((a, i) => (
              <div key={i} className="flex items-start gap-4 py-2.5 relative">
                {/* Dot */}
                <div className="relative z-10 mt-0.5">
                  <span className="flex h-[10px] w-[10px] items-center justify-center rounded-full bg-white border-2 border-emerald-400">
                    <span className="h-1 w-1 rounded-full bg-emerald-500" />
                  </span>
                </div>

                {/* Content */}
                <div className="flex flex-1 items-center justify-between min-w-0 gap-4">
                  <div className="min-w-0">
                    <p className="text-[13px] text-slate-700 truncate">{a.label}</p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-[11px] font-medium text-slate-400 bg-slate-50 rounded-md px-2 py-0.5 border border-slate-100">
                      {a.module}
                    </span>
                    <span className="text-[12px] tabular-nums text-slate-400 font-mono">{a.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Launchpad to Key Modules */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <a
          href="/dashboard/client-portal"
          className="rounded-2xl bg-white border border-slate-200 p-4 hover:border-sky-300 hover:shadow-xs transition group"
        >
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-sky-500" />
            <span className="text-[12px] font-bold text-slate-900 group-hover:text-sky-600 transition">
              External Client Portal
            </span>
          </div>
          <p className="mt-1.5 text-[12px] text-slate-500 leading-relaxed">
            Read-only verified access for IOCs (Shell, Chevron, Dangote). Shared e-BDNs & PODs.
          </p>
        </a>

        <a
          href="/dashboard/epc-link"
          className="rounded-2xl bg-white border border-slate-200 p-4 hover:border-emerald-300 hover:shadow-xs transition group"
        >
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span className="text-[12px] font-bold text-slate-900 group-hover:text-emerald-600 transition">
              NCFCC & NOGIC-JQS Dossier
            </span>
          </div>
          <p className="mt-1.5 text-[12px] text-slate-500 leading-relaxed">
            NCDMB compliance readiness checker and export pack for upstream tenders.
          </p>
        </a>

        <a
          href="/dashboard/bunkerflow"
          className="rounded-2xl bg-white border border-slate-200 p-4 hover:border-indigo-300 hover:shadow-xs transition group"
        >
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-indigo-500" />
            <span className="text-[12px] font-bold text-slate-900 group-hover:text-indigo-600 transition">
              Bunker Delivery & e-BDN
            </span>
          </div>
          <p className="mt-1.5 text-[12px] text-slate-500 leading-relaxed">
            Dual-signed digital delivery notes with ASTM 54B temperature correction.
          </p>
        </a>
      </div>
    </div>
  );
}
