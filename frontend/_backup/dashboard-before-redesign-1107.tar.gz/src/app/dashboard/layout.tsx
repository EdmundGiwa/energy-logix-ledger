"use client";

import { useState } from "react";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Topbar } from "@/components/dashboard/Topbar";
import { MobileSidebar } from "@/components/dashboard/MobileSidebar";
import { StatusBar } from "@/components/dashboard/StatusBar";
import { AstmCalculatorModal } from "@/components/dashboard/AstmCalculatorModal";
import { CommandPalette } from "@/components/dashboard/CommandPalette";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [astmOpen, setAstmOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#fafbfc] flex flex-col">
      {/* Modals & Overlays */}
      <AstmCalculatorModal open={astmOpen} onClose={() => setAstmOpen(false)} />
      <CommandPalette
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        onOpenAstm={() => setAstmOpen(true)}
      />

      {/* Desktop sidebar */}
      <div className="hidden lg:block">
        <Sidebar />
      </div>

      {/* Mobile sidebar overlay */}
      <MobileSidebar open={mobileOpen} onClose={() => setMobileOpen(false)} />

      {/* Main content wrapper */}
      <div className="lg:pl-[248px] flex flex-col flex-1 transition-all duration-300">
        {/* Mobile topbar hamburger */}
        <div className="lg:hidden sticky top-0 z-30 flex items-center justify-between bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 py-2.5">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600"
              aria-label="Open menu"
            >
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round">
                <path d="M4 7h16M4 12h16M4 17h16" />
              </svg>
            </button>
            <span className="text-[13px] font-extrabold uppercase tracking-[0.06em] text-slate-900">
              Petro<span className="text-emerald-600">Ledger</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setAstmOpen(true)}
              className="rounded-lg border border-sky-200 bg-sky-50 px-2 py-1 text-[11px] font-bold text-sky-800"
            >
              ASTM 54B
            </button>
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-600"
              aria-label="Search"
            >
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
              </svg>
            </button>
          </div>
        </div>

        {/* Desktop topbar */}
        <div className="hidden lg:block">
          <Topbar
            onOpenSearch={() => setSearchOpen(true)}
            onOpenAstm={() => setAstmOpen(true)}
          />
        </div>

        {/* Page content */}
        <main className="p-4 sm:p-6 lg:p-8 flex-1">
          {children}
        </main>

        {/* Persistent Industrial Status Bar */}
        <StatusBar onOpenAstm={() => setAstmOpen(true)} />
      </div>
    </div>
  );
}
