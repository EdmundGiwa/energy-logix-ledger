import { Navbar } from "@/components/landing/Navbar";
import { Hero } from "@/components/landing/Hero";
import { Problem } from "@/components/landing/Problem";
import { OperationsWall } from "@/components/landing/OperationsWall";
import { Platforms } from "@/components/landing/Platforms";
import { Modules } from "@/components/landing/Modules";
import { OfflineSync } from "@/components/landing/OfflineSync";
import { WhiteLabel } from "@/components/landing/WhiteLabel";
import { Security } from "@/components/landing/Security";
import { Pricing } from "@/components/landing/Pricing";
import { Closing } from "@/components/landing/Closing";

export default function Home() {
  return (
    <main className="relative overflow-x-clip">
      <Navbar />
      <Hero />
      <Problem />
      <OperationsWall />
      <Platforms />
      <Modules />
      <OfflineSync />
      <WhiteLabel />
      <Security />
      <Pricing />
      <Closing />
    </main>
  );
}
