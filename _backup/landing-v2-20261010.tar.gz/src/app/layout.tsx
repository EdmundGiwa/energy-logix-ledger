import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PetroLogix Core — Offshore Ops, Marine Fleet & Compliance OS",
  description:
    "The private-instance operating system for indigenous oilfield and marine service contractors. Crew certification gatekeeping, vessel bunker & off-hire ledgers, LOLER compliance and offline-first field apps.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrains.variable} antialiased`}>
      <body className="min-h-full">{children}</body>
    </html>
  );
}
