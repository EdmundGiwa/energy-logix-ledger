"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import { HexLogo, Icon } from "./icons";
import { SegmentBar, Sparkline, seeded } from "./charts";
import { Reveal, SectionHeading, useInView } from "./primitives";

const tabs = {
  Fuel: { seed: 11, unit: "MT", label: "Fleet fuel burn at 12:00", peak: 38.4, axis: ["48", "36", "24", "12", "0"] },
  Crew: { seed: 23, unit: "POB", label: "Personnel on board at 12:00", peak: 186, axis: ["240", "180", "120", "60", "0"] },
  Combined: { seed: 37, unit: "%", label: "Ops efficiency at 12:00", peak: 92.6, axis: ["100", "75", "50", "25", "0"] },
} as const;
type Tab = keyof typeof tabs;

const sideIcons = [Icon.Grid, Icon.Chart, Icon.Wrench, Icon.Shield, Icon.Barrel, Icon.Cube, Icon.Users, Icon.Clipboard];

const nodes = [
  { id: "A", x: 70, y: 40, label: "Onne Base", tone: "ok" },
  { id: "B", x: 150, y: 78, label: "PSV Atlantic Grace", tone: "ok" },
  { id: "E", x: 45, y: 118, label: "Crewboat CB-07", tone: "warn" },
  { id: "03", x: 238, y: 112, label: "FPSO Aje Star", tone: "ok" },
  { id: "C", x: 135, y: 170, label: "AHTS Delta Titan", tone: "crit" },
  { id: "D", x: 255, y: 196, label: "Wellhead D", tone: "ok" },
] as const;
const edges: [number, number][] = [[0, 1], [1, 3], [0, 2], [2, 4], [1, 4], [3, 5], [4, 5]];

const toneColor = { ok: "#b4f05a", warn: "#f59e0b", crit: "#ef4444" };

const compliance = [
  {
    name: "AHTS Delta Titan",
    sub: "Main engine breakdown, logged 06:40",
    action: "Off-hire clock running · 7.5 h",
    pct: 42,
    badge: { text: "Off-hire", cls: "bg-hazard/20 text-red-300" },
    bar: "bg-hazard",
    icon: Icon.Ship,
  },
  {
    name: "Crew Rotation 28/28",
    sub: "4 BOSIET certificates < 30 days",
    action: "Renewal booked for 2 of 4",
    pct: 68,
    badge: { text: "Warning", cls: "bg-amber/20 text-amber-300" },
    bar: "bg-amber",
    icon: Icon.IdCard,
  },
  {
    name: "Sling Set SL-204",
    sub: "LOLER proof-load · Q4 colour applied",
    action: "Cleared for dispatch",
    pct: 100,
    badge: { text: "Compliant", cls: "bg-ok/20 text-green-300" },
    bar: "bg-lime",
    icon: Icon.Anchor,
  },
];

function FleetChart({ tab }: { tab: Tab }) {
  const { ref, inView } = useInView<HTMLDivElement>(0.3);
  const cfg = tabs[tab];
  const data = useMemo(() => seeded(72, cfg.seed, 0.22, 0.78), [cfg.seed]);
  const [hover, setHover] = useState<number | null>(null);
  const hiStart = 30;
  const hiEnd = 44;

  return (
    <div ref={ref} className="relative mt-4 flex h-[200px] gap-3">
      <div className="flex flex-col justify-between pb-6 font-mono text-[10px] text-slate-500">
        {cfg.axis.map((a) => (
          <span key={a}>{a}</span>
        ))}
      </div>
      <div className="relative flex-1">
        {/* allowance line */}
        <div className="absolute inset-x-0 top-[34%] z-10 border-t border-dashed border-sky/50">
          <span className="absolute -top-5 right-0 rounded bg-sky/15 px-1.5 py-0.5 font-mono text-[9px] text-sky-300">
            Charter allowance
          </span>
        </div>
        <div className="absolute inset-x-0 bottom-6 top-0 flex items-end gap-[2px]" onMouseLeave={() => setHover(null)}>
          {data.map((v, i) => {
            const hi = i >= hiStart && i <= hiEnd;
            const boosted = hi ? Math.min(0.98, v + 0.22 * Math.sin(((i - hiStart) / (hiEnd - hiStart)) * Math.PI)) : v;
            return (
              <div
                key={`${tab}-${i}`}
                onMouseEnter={() => setHover(i)}
                className="relative flex h-full flex-1 items-end"
              >
                <span
                  className={`block w-full rounded-t-[2px] ${inView ? "bar-anim" : "scale-y-0"} ${
                    hi ? "bg-gradient-to-t from-lime-2/70 to-lime shadow-[0_0_12px_rgba(180,240,90,0.5)]" : "bg-white/25"
                  } ${hover === i ? "!bg-white" : ""}`}
                  style={{ height: `${boosted * 100}%`, animationDelay: `${i * 12}ms`, transformOrigin: "bottom" }}
                />
                {hover === i && (
                  <span className="absolute bottom-full left-1/2 z-20 mb-2 -translate-x-1/2 whitespace-nowrap rounded-md bg-white px-2 py-1 font-mono text-[10px] font-semibold text-navy">
                    {(boosted * Number(cfg.axis[0])).toFixed(1)} {cfg.unit}
                  </span>
                )}
              </div>
            );
          })}
        </div>
        <div className="absolute inset-x-0 bottom-0 flex justify-between px-4 font-mono text-[10px] text-slate-500">
          {["10:00", "11:00", "12:00", "13:00", "14:00"].map((t) => (
            <span key={t} className={t === "12:00" ? "text-lime" : ""}>
              {t}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export function OperationsWall() {
  const [tab, setTab] = useState<Tab>("Fuel");

  return (
    <section id="platform" className="relative py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          center
          eyebrow="Executive Operations Wall"
          title={
            <>
              Every rig, vessel and technician <span className="text-gradient">on one screen.</span>
            </>
          }
          sub="Live vessel positions, crew mobilization readiness, fleet fuel burn against charter allowances and active off-hire alerts, all in one live view for operations managers and marine superintendents."
        />
      </div>

      <Reveal className="mx-auto mt-16 max-w-[1440px] px-3 sm:px-6">
        <div className="relative overflow-hidden rounded-[32px] border border-white/10 p-3 shadow-[0_60px_120px_-40px_rgba(2,132,199,0.45)] sm:p-4">
          <Image
            src="/images/rig-vessel.jpg"
            alt="Supply vessel alongside an offshore platform"
            fill
            sizes="(max-width: 1440px) 100vw, 1440px"
            className="-z-10 object-cover object-[40%_50%]"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-b from-navy/40 via-navy/20 to-navy/70" />

          <div className="grid gap-3 lg:grid-cols-[64px_minmax(0,340px)_minmax(0,1fr)_minmax(0,360px)]">
            {/* Sidebar */}
            <aside className="hidden flex-col items-center gap-3 lg:flex">
              <div className="glass grid h-16 w-16 place-items-center rounded-2xl">
                <HexLogo size={30} />
              </div>
              <div className="glass flex flex-1 flex-col items-center gap-2 rounded-2xl py-3">
                {sideIcons.map((I, i) => (
                  <span
                    key={i}
                    className={`grid h-11 w-11 place-items-center rounded-xl transition ${
                      i === 0 ? "bg-lime/20 text-lime ring-1 ring-lime/30" : "text-slate-300 hover:bg-white/10"
                    }`}
                  >
                    <I size={19} />
                  </span>
                ))}
                <span className="mt-auto grid h-11 w-11 place-items-center rounded-xl text-slate-300">
                  <Icon.Settings size={19} />
                </span>
                <span className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-amber to-orange-600 text-xs font-bold text-white">
                  AO
                </span>
              </div>
            </aside>

            {/* Left column */}
            <div className="flex flex-col gap-3">
              <div className="glass-lime relative overflow-hidden rounded-3xl p-5">
                <div className="flex items-center gap-3">
                  <span className="grid h-11 w-11 place-items-center rounded-2xl bg-lime/90 text-[#0b2a0f]">
                    <Icon.Sparkle size={22} />
                  </span>
                  <div>
                    <p className="font-semibold text-white">AI Operations Assistant</p>
                    <p className="text-xs text-white/60">Optimize operations in real time.</p>
                  </div>
                </div>
                <div className="relative my-5 flex h-28 items-center justify-center">
                  <svg viewBox="0 0 200 110" className="h-full opacity-80" aria-hidden>
                    <g fill="none" stroke="rgba(255,255,255,0.75)" strokeWidth="1">
                      <path d="M30 80 L100 100 L170 80 L100 60 Z" />
                      <path d="M30 80 V60 L100 40 L170 60 V80" />
                      <path d="M100 40 V60 M100 100 V80" />
                      <path d="M60 52 V22 h10 v35 M130 52 V14 h12 v42" />
                      <circle cx="65" cy="20" r="6" />
                      <path d="M50 70 q20 -14 50 -4 t50 0" />
                      <rect x="85" y="56" width="30" height="18" rx="3" />
                      <path d="M115 64 h22 v-14 M85 64 h-20 v10" />
                    </g>
                  </svg>
                  <span className="absolute left-1/2 top-0 h-[2px] w-2/3 -translate-x-1/2 animate-scan bg-lime/70 shadow-[0_0_14px_#b4f05a]" />
                </div>
                <p className="text-lg font-semibold text-white">Primary Recommendation</p>
                <p className="mt-2 text-[13px] leading-relaxed text-white/80">
                  Move the <b className="text-white">PSV Atlantic Grace</b> cargo run to the 02:00–04:00 tide window.
                  Projected bunker saving: <b className="text-white">4.2 MT MGO</b>, with no change to the charterer&apos;s
                  standby time.
                </p>
              </div>

              <div className="glass flex-1 rounded-3xl p-4">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-white">Offshore Assets Map</p>
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-white/[0.06] text-slate-300">
                    <Icon.ArrowUpRight size={15} />
                  </span>
                </div>
                <div className="relative mt-3 overflow-hidden rounded-2xl bg-navy/50 ring-1 ring-white/5">
                  <div className="dots-bg absolute inset-0 opacity-40" />
                  <span className="absolute right-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-full bg-lime/15 px-2.5 py-1 text-[11px] font-medium text-lime ring-1 ring-lime/30">
                    <span className="h-1.5 w-1.5 rounded-full bg-lime" /> Online 5/6
                  </span>
                  <svg viewBox="0 0 300 230" className="relative w-full" role="img" aria-label="Fleet positions map">
                    {edges.map(([a, b], i) => (
                      <line
                        key={i}
                        x1={nodes[a].x}
                        y1={nodes[a].y}
                        x2={nodes[b].x}
                        y2={nodes[b].y}
                        stroke="rgba(255,255,255,0.22)"
                        strokeWidth="1"
                        strokeDasharray="3 5"
                        className="animate-dash"
                      />
                    ))}
                    {nodes.map((n) => (
                      <g key={n.id} transform={`translate(${n.x} ${n.y})`}>
                        {n.tone === "crit" && (
                          <circle r="20" fill="none" stroke={toneColor.crit} strokeOpacity="0.5">
                            <animate attributeName="r" from="13" to="26" dur="1.8s" repeatCount="indefinite" />
                            <animate attributeName="stroke-opacity" from="0.7" to="0" dur="1.8s" repeatCount="indefinite" />
                          </circle>
                        )}
                        <path
                          d="M0 -13 L11.3 -6.5 V6.5 L0 13 L-11.3 6.5 V-6.5 Z"
                          fill="rgba(11,31,51,0.9)"
                          stroke={toneColor[n.tone]}
                          strokeWidth="1.5"
                        />
                        <text y="3.5" textAnchor="middle" fontSize="9" fontWeight="700" fill="#fff">
                          {n.id}
                        </text>
                        <text y="25" textAnchor="middle" fontSize="7" fill="rgba(203,213,225,0.75)">
                          {n.label}
                        </text>
                      </g>
                    ))}
                  </svg>
                  <div className="absolute bottom-3 left-3 space-y-0.5 text-[10px] text-slate-400">
                    <p><span className="mr-1.5 inline-block h-2 w-0.5 bg-lime" />Normal</p>
                    <p><span className="mr-1.5 inline-block h-2 w-0.5 bg-amber" />Warning</p>
                    <p><span className="mr-1.5 inline-block h-2 w-0.5 bg-hazard" />Off-hire</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Center column */}
            <div className="flex flex-col justify-between gap-3">
              <div className="flex flex-wrap gap-2">
                <div className="glass flex items-center gap-3 rounded-2xl px-4 py-2.5 text-[13px]">
                  <span className="text-slate-400">Coordinates</span>
                  <span className="h-3 w-px bg-white/15" />
                  <span className="font-mono text-white">4.2333° N, 6.9833° E</span>
                </div>
                <div className="glass flex items-center gap-2 rounded-2xl px-4 py-2.5 text-[13px] text-white">
                  <Icon.Cloud size={16} /> 29 °C · Partly cloudy
                </div>
                <div className="glass flex items-center gap-2 rounded-2xl px-4 py-2.5 text-[13px] text-white">
                  <Icon.Wind size={16} /> 14 kn · SW
                </div>
              </div>

              <div className="py-16 lg:py-0">
                <span className="glass inline-block rounded-xl px-3 py-1.5 text-sm text-white">Cluster 2 · Shallow Water</span>
                <h3 className="mt-3 text-4xl font-semibold tracking-tight text-white drop-shadow-[0_4px_20px_rgba(0,0,0,0.6)] md:text-5xl">
                  Bonny Offshore – Niger Delta
                </h3>
                <p className="mt-3 flex flex-wrap items-center gap-3 text-[15px] text-white/90">
                  <Icon.Clock size={18} /> 14:23 UTC <span className="h-4 w-px bg-white/30" /> Day Shift (06:00 – 18:00)
                </p>
              </div>

              <div className="glass-strong rounded-3xl p-5">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="text-lg font-semibold text-white">Fleet performance</p>
                    <p className="mt-1 flex items-center gap-1.5 text-xs text-slate-400">
                      <span className="h-1.5 w-1.5 rounded-full bg-lime" /> Updated 3 min ago
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-[11px] text-slate-400">{tabs[tab].label}</p>
                    <p className="font-mono text-3xl font-semibold text-white md:text-4xl">
                      {tabs[tab].peak}
                      <span className="ml-1 text-sm text-slate-400">{tabs[tab].unit}</span>
                    </p>
                  </div>
                  <div className="flex gap-1 rounded-xl bg-white/[0.05] p-1" role="tablist">
                    {(Object.keys(tabs) as Tab[]).map((t) => (
                      <button
                        key={t}
                        role="tab"
                        aria-selected={tab === t}
                        onClick={() => setTab(t)}
                        className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                          tab === t ? "bg-white text-navy" : "text-slate-300 hover:text-white"
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <FleetChart tab={tab} />
              </div>
            </div>

            {/* Right column */}
            <div className="flex flex-col gap-3">
              <div className="glass rounded-3xl p-4">
                <div className="flex items-center justify-between px-1">
                  <p className="text-lg font-semibold text-white">Live Status</p>
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-white/[0.06] text-slate-300">
                    <Icon.ArrowUpRight size={15} />
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2.5">
                  <div className="glass-tile rounded-2xl p-3.5">
                    <div className="flex items-center justify-between text-[12.5px] text-slate-300">
                      Mobilization <Icon.Users size={15} />
                    </div>
                    <span className="mt-1.5 inline-block rounded bg-ok/20 px-1.5 text-[10px] font-semibold text-green-300">↑ 4.2%</span>
                    <p className="mt-1 text-2xl font-semibold text-white">
                      94<span className="text-xs text-slate-400"> % ready</span>
                    </p>
                    <div className="mt-1 h-9">
                      <Sparkline id="w1" data={seeded(22, 4, 0.25, 0.95)} />
                    </div>
                  </div>
                  <div className="glass-tile rounded-2xl p-3.5">
                    <div className="flex items-center justify-between text-[12.5px] text-slate-300">
                      Fuel burn <Icon.Fuel size={15} />
                    </div>
                    <span className="mt-1.5 inline-block rounded bg-amber/20 px-1.5 text-[10px] font-semibold text-amber-300">↓ 1.3%</span>
                    <p className="mt-1 text-2xl font-semibold text-white">
                      61.7<span className="text-xs text-slate-400"> MT/d</span>
                    </p>
                    <div className="mt-1 h-9">
                      <Sparkline id="w2" data={seeded(22, 9, 0.25, 0.95)} />
                    </div>
                  </div>
                  <div className="glass-tile rounded-2xl p-3.5">
                    <p className="text-[12.5px] text-slate-300">
                      Uptime <span className="text-slate-500">(24h)</span>
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-white">97.8%</p>
                    <p className="text-[11px] text-slate-400">Target: 98.5%</p>
                    <div className="mt-3">
                      <SegmentBar value={0.95} segments={16} />
                    </div>
                  </div>
                  <div className="glass-tile rounded-2xl p-3.5">
                    <p className="text-[12.5px] text-slate-300">Vessels on-hire</p>
                    <p className="mt-3 text-2xl font-semibold text-white">8/9</p>
                    <p className="text-[11px] text-slate-400">1 breakdown off-hire</p>
                    <div className="mt-3">
                      <SegmentBar value={8 / 9} segments={16} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="glass flex-1 rounded-3xl p-4">
                <div className="flex items-center justify-between px-1">
                  <p className="text-lg font-semibold text-white">Critical Compliance</p>
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-white/[0.06] text-slate-300">
                    <Icon.ArrowUpRight size={15} />
                  </span>
                </div>
                <div className="mt-3 space-y-2.5">
                  {compliance.map((c) => (
                    <div key={c.name} className="glass-tile flex gap-3 rounded-2xl p-3">
                      <span className="grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-white/10 to-white/[0.02] text-slate-200 ring-1 ring-white/10">
                        <c.icon size={24} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <p className="truncate text-[14px] font-medium text-white">{c.name}</p>
                          <span className={`shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${c.badge.cls}`}>
                            {c.badge.text}
                          </span>
                        </div>
                        <p className="truncate text-[11.5px] text-slate-400">{c.sub}</p>
                        <div className="mt-1.5 flex items-end justify-between gap-2">
                          <p className="truncate text-[11.5px] text-slate-300">{c.action}</p>
                          <p className="font-mono text-sm font-semibold text-white">{c.pct}%</p>
                        </div>
                        <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10">
                          <div className={`h-full rounded-full ${c.bar}`} style={{ width: `${c.pct}%` }} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
