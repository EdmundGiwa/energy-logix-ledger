"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const modes = [
  {
    key: "offline",
    label: "Communication blackout",
    link: "No link",
    desc: "Crew keep working. Manifest sign-offs, fuel entries and safety cards are written to the encrypted on-device database.",
  },
  {
    key: "pending",
    label: "Link detected",
    link: "VSAT · Jetty Wi-Fi · LTE",
    desc: "A background process detects the link and sends compact change deltas (JSON CRDTs) to the central API.",
  },
  {
    key: "synced",
    label: "Reconciled",
    link: "TLS 1.3",
    desc: "The server resolves conflicts using its own timestamps, so HQ dashboards and audit ledgers show the same record as the field.",
  },
] as const;

export function OfflineSync() {
  const [m, setM] = useState(1);
  const flowing = m >= 1;

  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-14 lg:grid-cols-[0.85fr_1.15fr]">
          <div>
            <SectionHeading
              eyebrow="Store-and-forward sync"
              title={
                <>
                  Works in a communication blackout.{" "}
                  <span className="text-slate-500">Syncs when the link returns.</span>
                </>
              }
              sub="Rigs, vessels and fabrication yards often lose connectivity. Field-Link does not depend on a network connection: it keeps working offline and reconciles when one is available."
            />
            <Reveal delay={150} className="mt-8 space-y-2">
              {modes.map((mode, i) => (
                <button
                  key={mode.key}
                  onClick={() => setM(i)}
                  className={`w-full rounded-2xl p-4 text-left transition ${
                    m === i ? "glass ring-1 ring-lime/40" : "hover:bg-white/[0.03]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <p className="flex items-center gap-3 font-semibold text-white">
                      <span
                        className={`grid h-7 w-7 place-items-center rounded-full font-mono text-[11px] ${
                          m === i ? "bg-lime text-[#0b2a0f]" : "bg-white/10 text-slate-300"
                        }`}
                      >
                        {i + 1}
                      </span>
                      {mode.label}
                    </p>
                    <span className="font-mono text-[10px] uppercase tracking-wider text-slate-500">{mode.link}</span>
                  </div>
                  {m === i && <p className="mt-2 pl-10 text-[13.5px] leading-relaxed text-slate-400">{mode.desc}</p>}
                </button>
              ))}
            </Reveal>
          </div>

          <Reveal delay={100}>
            <div className="glass relative overflow-hidden rounded-[32px] p-6 sm:p-10">
              <div className="dots-bg absolute inset-0 opacity-30" />
              <div className="relative grid grid-cols-[1fr_auto_1fr] items-center gap-3 sm:gap-6">
                {/* Device */}
                <div className="glass-tile rounded-3xl p-4 sm:p-5">
                  <div className="flex items-center gap-2 text-[12px] text-slate-400">
                    <Icon.Phone size={16} className="text-amber-300" /> Field device
                  </div>
                  <p className="mt-3 text-sm font-semibold text-white sm:text-base">Encrypted SQLite</p>
                  <p className="text-[11px] text-slate-500">WatermelonDB · Drift</p>
                  <div className="mt-4 space-y-1.5">
                    {["DSR · ROB 182.4", "PTW-0921 signed", "Scan CB-118", "STOP card #44"].map((r, i) => (
                      <div
                        key={r}
                        className={`flex items-center justify-between rounded-lg px-2.5 py-1.5 font-mono text-[10px] transition-all duration-500 ${
                          m === 2 ? "bg-lime/10 text-lime" : "bg-white/[0.05] text-slate-300"
                        }`}
                        style={{ transitionDelay: `${i * 120}ms` }}
                      >
                        <span className="truncate">{r}</span>
                        <span>{m === 2 ? "✓" : m === 1 ? "↑" : "●"}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Link */}
                <div className="flex flex-col items-center gap-3">
                  <span
                    className={`grid h-14 w-14 place-items-center rounded-2xl ring-1 transition-all duration-500 ${
                      m === 0 ? "bg-white/5 text-slate-500 ring-white/10" : "bg-lime/15 text-lime ring-lime/40 shadow-[0_0_30px_rgba(180,240,90,0.35)]"
                    }`}
                  >
                    {m === 0 ? <Icon.WifiOff size={24} /> : <Icon.Satellite size={24} />}
                  </span>
                  <svg width="90" height="24" viewBox="0 0 90 24" className="hidden sm:block" aria-hidden>
                    <line
                      x1="0"
                      y1="12"
                      x2="90"
                      y2="12"
                      stroke={flowing ? "#b4f05a" : "rgba(255,255,255,0.15)"}
                      strokeWidth="2"
                      strokeDasharray="6 6"
                      className={flowing ? "animate-dash" : ""}
                    />
                  </svg>
                  <span className="font-mono text-[9px] uppercase tracking-widest text-slate-500">
                    {m === 0 ? "Queued" : m === 1 ? "Δ deltas" : "Ack"}
                  </span>
                </div>

                {/* Server */}
                <div className="glass-tile rounded-3xl p-4 sm:p-5">
                  <div className="flex items-center gap-2 text-[12px] text-slate-400">
                    <Icon.Server size={16} className="text-sky-300" /> Central API
                  </div>
                  <p className="mt-3 text-sm font-semibold text-white sm:text-base">Server-authoritative</p>
                  <p className="text-[11px] text-slate-500">PostgreSQL · Redis · S3</p>
                  <div className="mt-4 space-y-1.5 font-mono text-[10px]">
                    <div className="flex justify-between rounded-lg bg-white/[0.05] px-2.5 py-1.5 text-slate-300">
                      <span>Deltas</span>
                      <span className="text-white">{m === 0 ? 0 : m === 1 ? "7/12" : "12/12"}</span>
                    </div>
                    <div className="flex justify-between rounded-lg bg-white/[0.05] px-2.5 py-1.5 text-slate-300">
                      <span>Conflicts</span>
                      <span className="text-white">{m === 2 ? "1 resolved" : "—"}</span>
                    </div>
                    <div className="flex justify-between rounded-lg bg-white/[0.05] px-2.5 py-1.5 text-slate-300">
                      <span>Ledger</span>
                      <span className={m === 2 ? "text-lime" : "text-amber-300"}>{m === 2 ? "Current" : "Stale"}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="relative mt-8 grid grid-cols-3 gap-3 border-t border-white/10 pt-6 text-center">
                {[
                  ["AES-256", "at rest"],
                  ["TLS 1.3", "in transit"],
                  ["Δ CRDT", "differential"],
                ].map(([a, b]) => (
                  <div key={a}>
                    <p className="font-mono text-base font-semibold text-white sm:text-lg">{a}</p>
                    <p className="text-[11px] text-slate-500">{b}</p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
