"use client";

import Image from "next/image";
import { useState } from "react";
import { HexLogo, Icon } from "./icons";
import { Reveal } from "./primitives";

const hubs = [
  { city: "Port Harcourt", coord: "4.8156° N, 7.0498° E" },
  { city: "Warri", coord: "5.5160° N, 5.7500° E" },
  { city: "Lagos", coord: "6.4550° N, 3.3841° E" },
];

export function Closing() {
  const [sent, setSent] = useState(false);
  const [email, setEmail] = useState("");

  return (
    <>
      <section id="contact" className="relative px-3 py-20 sm:px-6">
        <Reveal className="relative mx-auto max-w-7xl overflow-hidden rounded-[40px] border border-white/10">
          <Image
            src="/images/rig-aerial.jpg"
            alt="Aerial view of an offshore platform with a supply vessel"
            fill
            sizes="(max-width: 1280px) 100vw, 1280px"
            className="-z-10 object-cover"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink via-ink/85 to-ink/30" />
          <div className="grid gap-10 p-8 sm:p-14 lg:grid-cols-[1.2fr_0.8fr] lg:p-20">
            <div>
              <HexLogo size={44} />
              <h2 className="mt-8 text-4xl font-semibold leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-6xl">
                Stop losing money on paperwork failures offshore.
              </h2>
              <p className="mt-6 max-w-xl text-lg text-slate-300">
                See PetroLogix Core running on your own fleet, crew records and IOC formats. We set up a tailored demo
                instance within a week.
              </p>
              <div className="mt-10 flex flex-wrap gap-3">
                {hubs.map((h) => (
                  <div key={h.city} className="glass rounded-2xl px-4 py-3">
                    <p className="flex items-center gap-2 text-sm font-semibold text-white">
                      <Icon.Pin size={15} className="text-lime" /> {h.city}
                    </p>
                    <p className="mt-0.5 font-mono text-[10.5px] text-slate-400">{h.coord}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-strong self-center rounded-[28px] p-6 sm:p-8">
              {sent ? (
                <div className="py-6 text-center [animation:float-in_0.5s_ease]">
                  <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-lime text-[#0b2a0f]">
                    <Icon.Check size={26} />
                  </span>
                  <p className="mt-5 text-xl font-semibold text-white">Request received</p>
                  <p className="mt-2 text-sm text-slate-400">
                    Our solutions team will reach out to <span className="text-white">{email}</span> within one business day.
                  </p>
                </div>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSent(true);
                  }}
                  className="space-y-4"
                >
                  <p className="text-xl font-semibold text-white">Book a private demo</p>
                  {[
                    { id: "name", label: "Full name", type: "text", ph: "Adaeze Okafor" },
                    { id: "company", label: "Company", type: "text", ph: "Delta Marine Services Ltd" },
                  ].map((f) => (
                    <label key={f.id} className="block">
                      <span className="text-[12px] font-medium text-slate-400">{f.label}</span>
                      <input
                        required
                        type={f.type}
                        placeholder={f.ph}
                        className="mt-1.5 h-12 w-full rounded-xl bg-white/[0.06] px-4 text-[15px] text-white ring-1 ring-white/10 outline-none transition placeholder:text-slate-600 focus:ring-lime/60"
                      />
                    </label>
                  ))}
                  <label className="block">
                    <span className="text-[12px] font-medium text-slate-400">Work email</span>
                    <input
                      required
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="ops@company.com"
                      className="mt-1.5 h-12 w-full rounded-xl bg-white/[0.06] px-4 text-[15px] text-white ring-1 ring-white/10 outline-none transition placeholder:text-slate-600 focus:ring-lime/60"
                    />
                  </label>
                  <label className="block">
                    <span className="text-[12px] font-medium text-slate-400">Fleet size</span>
                    <select className="mt-1.5 h-12 w-full rounded-xl bg-white/[0.06] px-4 text-[15px] text-white ring-1 ring-white/10 outline-none focus:ring-lime/60 [&>option]:bg-navy">
                      <option>Up to 3 vessels · 50 crew</option>
                      <option>Up to 10 vessels · 250 crew</option>
                      <option>Larger fleet</option>
                    </select>
                  </label>
                  <button type="submit" className="btn-lime flex h-12 w-full items-center justify-center gap-2 rounded-xl font-semibold">
                    Request demo <Icon.Arrow size={18} />
                  </button>
                  <p className="text-center text-[11px] text-slate-500">No commitment. Your data stays confidential.</p>
                </form>
              )}
            </div>
          </div>
        </Reveal>
      </section>

      <footer className="border-t border-white/10">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <HexLogo size={26} />
              <span className="font-semibold text-white">PetroLogix Core</span>
            </div>
            <p className="mt-4 max-w-xs text-[13.5px] leading-relaxed text-slate-400">
              Offshore ops, marine fleet and compliance operating system for indigenous energy service contractors.
            </p>
          </div>
          {[
            { h: "Platform", l: ["Operations Wall", "Field-Link Mobile", "Manifest Studio", "White-label"] },
            { h: "Engines", l: ["CrewPass", "SeaLog", "YardTrace", "SafeWork"] },
            { h: "Company", l: ["About", "Security", "Pricing", "Contact"] },
          ].map((c) => (
            <div key={c.h}>
              <p className="text-[12px] font-semibold uppercase tracking-widest text-slate-500">{c.h}</p>
              <ul className="mt-4 space-y-2.5">
                {c.l.map((x) => (
                  <li key={x}>
                    <a href="#top" className="text-[14px] text-slate-300 transition hover:text-white">
                      {x}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-white/5">
          <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-[11.5px] text-slate-500 sm:px-6 md:flex-row md:items-center md:justify-between">
            <p>© {new Date().getFullYear()} PetroLogix Core. All rights reserved.</p>
            <p>
              Photography: &ldquo;Holstein at Dusk&rdquo; &amp; &ldquo;Oil Platform Crew Transfer&rdquo; by GuavaTrain (CC0) · BSEE (public
              domain), via Wikimedia Commons.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
