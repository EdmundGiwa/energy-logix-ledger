import Image from "next/image";
import { Icon } from "./icons";
import { SegmentBar, Sparkline, seeded } from "./charts";

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <div className="glass flex items-center gap-2.5 rounded-2xl px-4 py-2.5 text-[13px] text-slate-200/90">{children}</div>
  );
}

export function Hero() {
  return (
    <section id="top" className="relative isolate min-h-[100svh] overflow-hidden">
      {/* Backdrop */}
      <div className="absolute inset-0 -z-10">
        <Image
          src="/images/rig-dusk.jpg"
          alt="Offshore production platform lit up at dusk"
          fill
          preload
          sizes="100vw"
          className="animate-slow-zoom object-cover object-[60%_40%]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/75 to-ink/10" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/60" />
        <div className="absolute -left-40 top-1/3 h-[520px] w-[520px] rounded-full bg-blue/20 blur-[120px]" />
      </div>

      <div className="mx-auto grid min-h-[100svh] max-w-7xl grid-cols-1 items-center gap-12 px-4 pb-20 pt-32 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:pt-36">
        {/* Copy */}
        <div>
          <div className="flex flex-wrap gap-2">
            <Chip>
              <Icon.Pin size={16} className="text-lime" />
              <span className="text-slate-400">Bonny Terminal</span>
              <span className="h-3 w-px bg-white/15" />
              <span className="font-mono text-[12px]">4.4167° N, 7.1500° E</span>
            </Chip>
            <Chip>
              <Icon.Cloud size={16} />
              <span>29 °C · Sea state 3</span>
            </Chip>
          </div>

          <h1 className="mt-8 text-[2.6rem] font-semibold leading-[1.02] tracking-tight text-white sm:text-6xl lg:text-[4.6rem]">
            The command deck for
            <br />
            <span className="text-gradient">offshore operations.</span>
          </h1>

          <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-300/90 sm:text-lg">
            PetroLogix Core is the private-instance operating system for indigenous oilfield and marine
            contractors. It gates crew mobilization on valid certificates, reconciles every litre of bunker
            fuel, and keeps you audit-ready for every IOC. It also keeps working when the VSAT link drops.
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <a href="#contact" className="btn-lime inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-4 text-[15px] font-semibold">
              Book a private demo <Icon.Arrow size={18} />
            </a>
            <a
              href="#platform"
              className="glass inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-4 text-[15px] font-medium text-white transition hover:bg-white/10"
            >
              Tour the Operations Wall
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-slate-400">
            {["Dedicated single-tenant", "Offline-first field app", "Your brand, your domain"].map((t) => (
              <span key={t} className="inline-flex items-center gap-2">
                <Icon.Check size={16} className="text-lime" /> {t}
              </span>
            ))}
          </div>
        </div>

        {/* Floating product cards */}
        <div className="relative hidden h-[680px] lg:block">
          {/* AI assistant */}
          <div className="animate-float absolute right-8 top-0 w-[370px] overflow-hidden rounded-[28px] glass-lime p-5 shadow-[0_30px_80px_-30px_rgba(126,217,87,0.6)]">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-lime/90 text-[#0b2a0f]">
                <Icon.Sparkle size={22} />
              </span>
              <div>
                <p className="text-[15px] font-semibold text-white">AI Operations Assistant</p>
                <p className="text-xs text-white/60">Watching 214 crew · 9 vessels</p>
              </div>
            </div>
            <p className="mt-6 text-lg font-semibold text-white">Primary recommendation</p>
            <p className="mt-2 text-[13.5px] leading-relaxed text-white/80">
              Swap <b className="text-white">3 technicians</b> off the <b className="text-white">MV Bonny Star</b>{" "}
              manifest. Their BOSIET expires in 6 days. Standby crew from Onne base is fit to mobilize.
              Avoided NPT exposure: <b className="text-lime">$31,500</b>.
            </p>
            <div className="mt-5 flex gap-2">
              <span className="rounded-xl bg-white/90 px-3.5 py-2 text-xs font-semibold text-navy">Apply swap</span>
              <span className="rounded-xl bg-white/10 px-3.5 py-2 text-xs font-medium text-white ring-1 ring-white/20">
                View manifest
              </span>
            </div>
          </div>

          {/* Live status */}
          <div className="animate-float-slow absolute bottom-0 left-0 w-[380px] rounded-[28px] glass-strong p-4 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.8)]">
            <div className="flex items-center justify-between px-1 pb-3">
              <p className="text-[15px] font-semibold text-white">Live Status</p>
              <span className="inline-flex items-center gap-1.5 text-[11px] text-lime">
                <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-lime text-lime" /> Synced 14:23 UTC
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <div className="glass-tile rounded-2xl p-3.5">
                <p className="text-[12px] text-slate-300">Crew readiness</p>
                <p className="mt-2 text-2xl font-semibold text-white">
                  94<span className="text-sm text-slate-400">%</span>
                </p>
                <div className="mt-2 h-8">
                  <Sparkline id="h1" data={seeded(18, 3, 0.3, 0.95)} />
                </div>
              </div>
              <div className="glass-tile rounded-2xl p-3.5">
                <p className="text-[12px] text-slate-300">Fuel variance</p>
                <p className="mt-2 text-2xl font-semibold text-white">
                  −1.8<span className="text-sm text-slate-400">%</span>
                </p>
                <div className="mt-2 h-8">
                  <Sparkline id="h2" data={seeded(18, 7, 0.2, 0.9)} color="#38bdf8" />
                </div>
              </div>
              <div className="glass-tile rounded-2xl p-3.5">
                <p className="text-[12px] text-slate-300">Certs expiring · 30d</p>
                <p className="mt-2 text-2xl font-semibold text-amber-300">17</p>
                <div className="mt-3">
                  <SegmentBar value={0.34} segments={18} tone="amber" />
                </div>
              </div>
              <div className="glass-tile rounded-2xl p-3.5">
                <p className="text-[12px] text-slate-300">Vessels on-hire</p>
                <p className="mt-2 text-2xl font-semibold text-white">
                  8<span className="text-sm text-slate-400">/9</span>
                </p>
                <div className="mt-3">
                  <SegmentBar value={8 / 9} segments={18} />
                </div>
              </div>
            </div>
          </div>

          {/* Small alert toast */}
          <div className="absolute bottom-[120px] right-0 z-10 w-[240px] rounded-2xl glass-strong p-3.5 shadow-[0_20px_50px_-20px_rgba(0,0,0,0.8)]">
            <div className="flex items-start gap-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-hazard/20 text-red-300">
                <Icon.Alert size={18} />
              </span>
              <div>
                <p className="text-[13px] font-semibold text-white">Mobilization blocked</p>
                <p className="mt-0.5 text-[12px] leading-snug text-slate-400">
                  E. Okon: OSP expired 2 days ago. Removed from outbound manifest.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="pointer-events-none absolute inset-x-0 bottom-6 hidden justify-center md:flex">
        <div className="flex h-10 w-6 justify-center rounded-full border border-white/20 pt-2">
          <span className="h-2 w-1 animate-bounce rounded-full bg-white/60" />
        </div>
      </div>
    </section>
  );
}
