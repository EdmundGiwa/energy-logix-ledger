"use client";

import { useEffect, useState } from "react";
import { HexLogo, Icon } from "./icons";

const links = [
  { href: "#platform", label: "Platform" },
  { href: "#modules", label: "Modules" },
  { href: "#field-link", label: "Field-Link" },
  { href: "#white-label", label: "White-label" },
  { href: "#pricing", label: "Pricing" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-4 pt-4 sm:px-6">
      <nav
        className={`mx-auto flex max-w-7xl items-center justify-between rounded-2xl px-3 py-2.5 transition-all duration-500 sm:px-4 ${
          scrolled ? "glass-strong shadow-[0_20px_60px_-20px_rgba(0,0,0,0.6)]" : "border border-transparent"
        }`}
      >
        <a href="#top" className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/[0.06] ring-1 ring-white/10">
            <HexLogo size={24} />
          </span>
          <span className="leading-none">
            <span className="block text-[15px] font-semibold tracking-tight text-white">PetroLogix</span>
            <span className="block font-mono text-[10px] uppercase tracking-[0.22em] text-lime/80">Core</span>
          </span>
        </a>

        <ul className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="rounded-lg px-3.5 py-2 text-sm text-slate-300 transition hover:bg-white/[0.06] hover:text-white"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <a href="#contact" className="hidden rounded-lg px-3.5 py-2 text-sm text-slate-300 transition hover:text-white sm:block">
            Sign in
          </a>
          <a href="#contact" className="btn-lime hidden items-center gap-1.5 rounded-xl px-4 py-2.5 text-sm font-semibold sm:inline-flex">
            Book a demo <Icon.ArrowUpRight size={16} />
          </a>
          <button
            type="button"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
            className="grid h-11 w-11 place-items-center rounded-xl bg-white/[0.06] text-white ring-1 ring-white/10 lg:hidden"
          >
            {open ? <Icon.X /> : <Icon.Menu />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="glass-strong mx-auto mt-2 max-w-7xl rounded-2xl p-3 lg:hidden">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block rounded-lg px-4 py-3 text-slate-200 hover:bg-white/[0.06]"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="btn-lime mt-2 flex items-center justify-center gap-1.5 rounded-xl px-4 py-3 font-semibold"
          >
            Book a demo <Icon.ArrowUpRight size={16} />
          </a>
        </div>
      )}
    </header>
  );
}
