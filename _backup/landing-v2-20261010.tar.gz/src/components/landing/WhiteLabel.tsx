"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const brands = [
  { name: "Delta Marine Services", short: "DM", domain: "portal.deltamarine.ng", color: "#b4f05a", ink: "#0b2a0f" },
  { name: "Riverside Offshore", short: "RO", domain: "ops.riversideoffshore.com", color: "#38bdf8", ink: "#062033" },
  { name: "Kalabari Energy Logistics", short: "KE", domain: "core.kalabari-energy.com", color: "#f59e0b", ink: "#2a1600" },
  { name: "Ogoni Subsea Works", short: "OS", domain: "field.ogonisubsea.com", color: "#e879f9", ink: "#2a0730" },
];

const assetTypes = ["AHTS", "PSV", "Crewboat", "Slickline Truck", "Well-testing Unit", "Subsea Spread", "Tug", "Barge"];

export function WhiteLabel() {
  const [b, setB] = useState(0);
  const [assets, setAssets] = useState<string[]>(["AHTS", "PSV", "Crewboat"]);
  const [grid, setGrid] = useState<4 | 5>(5);
  const brand = brands[b];

  const toggle = (a: string) =>
    setAssets((cur) => (cur.includes(a) ? (cur.length > 1 ? cur.filter((x) => x !== a) : cur) : [...cur, a]));

  return (
    <section id="white-label" className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          center
          eyebrow="White-label tailoring"
          title={
            <>
              Your brand, your fleet, your safety rules.{" "}
              <span className="text-gradient">No custom code to maintain.</span>
            </>
          }
          sub="Each client runs a private instance on its own domain. Your IOC auditors see your company's technology, and every screen uses the names your crews already use."
        />

        <Reveal className="mt-16 grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          {/* Controls */}
          <div className="space-y-4">
            <div className="glass rounded-3xl p-5">
              <p className="flex items-center gap-2 text-sm font-semibold text-white">
                <Icon.Palette size={18} className="text-lime" /> Brand & portal identity
              </p>
              <div className="mt-4 grid grid-cols-2 gap-2">
                {brands.map((x, i) => (
                  <button
                    key={x.name}
                    onClick={() => setB(i)}
                    className={`flex items-center gap-2.5 rounded-xl p-2.5 text-left text-[12.5px] transition ${
                      b === i ? "bg-white/[0.08] ring-1 ring-white/25" : "hover:bg-white/[0.04]"
                    }`}
                  >
                    <span
                      className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[11px] font-bold"
                      style={{ background: x.color, color: x.ink }}
                    >
                      {x.short}
                    </span>
                    <span className="leading-tight text-slate-200">{x.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="glass rounded-3xl p-5">
              <p className="flex items-center gap-2 text-sm font-semibold text-white">
                <Icon.Layers size={18} className="text-lime" /> Asset taxonomy & fleet mix
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {assetTypes.map((a) => {
                  const on = assets.includes(a);
                  return (
                    <button
                      key={a}
                      onClick={() => toggle(a)}
                      aria-pressed={on}
                      className={`rounded-full px-3 py-1.5 text-[12px] font-medium ring-1 transition ${
                        on ? "text-white" : "text-slate-400 ring-white/10 hover:text-white"
                      }`}
                      style={on ? { background: `${brand.color}22`, boxShadow: `inset 0 0 0 1px ${brand.color}88` } : undefined}
                    >
                      {on && "✓ "}
                      {a}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="glass rounded-3xl p-5">
              <p className="flex items-center gap-2 text-sm font-semibold text-white">
                <Icon.Shield size={18} className="text-lime" /> HSE & permit logic
              </p>
              <div className="mt-4 flex items-center gap-4">
                <div className="flex rounded-xl bg-white/[0.05] p-1">
                  {[4, 5].map((g) => (
                    <button
                      key={g}
                      onClick={() => setGrid(g as 4 | 5)}
                      className={`rounded-lg px-3 py-1.5 font-mono text-xs transition ${
                        grid === g ? "bg-white text-navy" : "text-slate-300"
                      }`}
                    >
                      {g}×{g}
                    </button>
                  ))}
                </div>
                <p className="text-[12px] leading-snug text-slate-400">Risk matrix, gas limits and STOP workflows set per IOC client</p>
              </div>
            </div>
          </div>

          {/* Live preview */}
          <div className="glass-strong relative overflow-hidden rounded-[32px] p-3">
            <div
              className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full blur-[100px] transition-colors duration-700"
              style={{ background: `${brand.color}40` }}
            />
            {/* Browser chrome */}
            <div className="flex items-center gap-2 rounded-t-2xl bg-white/[0.04] px-4 py-3">
              <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-yellow-400/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-green-400/70" />
              <div className="ml-3 flex flex-1 items-center gap-2 rounded-lg bg-black/30 px-3 py-1.5 font-mono text-[11px] text-slate-300">
                <Icon.Lock size={12} className="text-green-400" />
                <span className="truncate">https://{brand.domain}</span>
              </div>
            </div>

            <div className="relative grid gap-3 rounded-b-2xl bg-navy/50 p-4 sm:grid-cols-[150px_1fr]">
              <aside className="hidden flex-col gap-1 rounded-2xl bg-black/20 p-3 sm:flex">
                <div className="mb-3 flex items-center gap-2">
                  <span
                    className="grid h-8 w-8 place-items-center rounded-lg text-[11px] font-bold transition-colors duration-500"
                    style={{ background: brand.color, color: brand.ink }}
                  >
                    {brand.short}
                  </span>
                  <span className="text-[11px] font-semibold leading-tight text-white">{brand.name.split(" ")[0]}</span>
                </div>
                {["Overview", "Crew", "Fleet", "Yard", "Permits"].map((n, i) => (
                  <span
                    key={n}
                    className="rounded-lg px-2.5 py-1.5 text-[12px] transition-colors duration-500"
                    style={i === 2 ? { background: `${brand.color}22`, color: brand.color } : { color: "#94a3b8" }}
                  >
                    {n}
                  </span>
                ))}
              </aside>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[11px] text-slate-400">{brand.name}</p>
                    <p className="text-lg font-semibold text-white">Fleet register</p>
                  </div>
                  <span
                    className="rounded-lg px-3 py-1.5 text-[11px] font-semibold transition-colors duration-500"
                    style={{ background: brand.color, color: brand.ink }}
                  >
                    + Add asset
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
                  {assets.map((a, i) => (
                    <div key={a} className="glass-tile rounded-xl p-3 [animation:float-in_0.4s_ease]">
                      <div className="flex items-center justify-between">
                        <Icon.Ship size={16} className="text-slate-300" />
                        <span className="font-mono text-[10px] text-slate-500">×{(i * 3 + 2) % 7 + 1}</span>
                      </div>
                      <p className="mt-2 text-[12.5px] font-medium text-white">{a}</p>
                      <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                        <div
                          className="h-full rounded-full transition-colors duration-500"
                          style={{ width: `${60 + ((i * 17) % 38)}%`, background: brand.color }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="grid gap-3 md:grid-cols-[1fr_auto]">
                  {/* Manifest letterhead */}
                  <div className="rounded-xl bg-white p-4 text-navy">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2">
                        <span
                          className="grid h-6 w-6 place-items-center rounded text-[9px] font-bold transition-colors duration-500"
                          style={{ background: brand.color, color: brand.ink }}
                        >
                          {brand.short}
                        </span>
                        <span className="text-[11px] font-bold">{brand.name}</span>
                      </div>
                      <span className="font-mono text-[9px] text-slate-500">PERSONNEL MANIFEST · MF-2291</span>
                    </div>
                    <div className="mt-2 space-y-1">
                      {[1, 2, 3].map((r) => (
                        <div key={r} className="flex gap-2">
                          <span className="h-1.5 w-1/4 rounded bg-slate-200" />
                          <span className="h-1.5 w-1/3 rounded bg-slate-200" />
                          <span className="h-1.5 flex-1 rounded bg-slate-100" />
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-[9px] text-slate-500">Client format: IOC Standard v3</span>
                      <span
                        className="rotate-[-8deg] rounded border-2 px-1.5 text-[9px] font-bold uppercase transition-colors duration-500"
                        style={{ borderColor: brand.color, color: brand.color === "#b4f05a" ? "#4d7c0f" : brand.color }}
                      >
                        Verified
                      </span>
                    </div>
                  </div>
                  {/* Risk matrix */}
                  <div className="rounded-xl bg-black/20 p-3">
                    <p className="font-mono text-[9px] text-slate-400">RISK {grid}×{grid}</p>
                    <div className="mt-2 grid gap-[3px]" style={{ gridTemplateColumns: `repeat(${grid}, 16px)` }}>
                      {Array.from({ length: grid * grid }).map((_, i) => {
                        const r = grid - Math.floor(i / grid);
                        const c = (i % grid) + 1;
                        const v = (r * c) / (grid * grid);
                        return (
                          <span
                            key={i}
                            className="h-4 w-4 rounded-[3px]"
                            style={{ background: v > 0.6 ? "#ef4444" : v > 0.3 ? "#f59e0b" : v > 0.15 ? "#facc15" : "#22c55e", opacity: 0.8 }}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
