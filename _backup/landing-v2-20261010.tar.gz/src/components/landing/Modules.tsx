"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading, StatusPill } from "./primitives";

type ModuleKey = "crewpass" | "sealog" | "yardtrace" | "safework";

const modules: Record<
  ModuleKey,
  {
    name: string;
    tagline: string;
    badge: { text: string; tone: "info" | "ok" | "warn" | "crit" };
    icon: (p: { size?: number; className?: string }) => React.ReactElement;
    summary: string;
    features: { t: string; d: string }[];
  }
> = {
  crewpass: {
    name: "CrewPass",
    tagline: "Personnel & mobilization gatekeeper",
    badge: { text: "High priority", tone: "info" },
    icon: Icon.IdCard,
    summary:
      "Stops technicians with expired offshore papers from being mobilized, before it turns into a dockside rejection, terminal delay or NPT penalty.",
    features: [
      { t: "Multi-credential vault", d: "OSP, BOSIET/FOET, STCW, medicals, seaman's books, and driver and crane licences." },
      { t: "Automated expiry push matrix", d: "Background jobs alert HR and the technician by SMS/WhatsApp at 90, 60, 30 and 7 days." },
      { t: "Mobilization gatekeeper", d: "Assignment to an outbound manifest is blocked if any mandatory credential fails validation." },
    ],
  },
  sealog: {
    name: "SeaLog",
    tagline: "Vessel fleet, bunker & off-hire engine",
    badge: { text: "Direct cost saver", tone: "ok" },
    icon: Icon.Ship,
    summary:
      "Closes fuel discrepancies worth millions of dollars or naira, and ends long disputes between vessel owners and the exploration companies that charter them.",
    features: [
      { t: "Digital Daily Status Report", d: "ROB, bunker received, engine hours, auxiliary loads and ops mode (Steaming, DP2, Cargo Ops, Standby)." },
      { t: "Off-hire discrepancy ledger", d: "Separates breakdown, weather standby and charterer waiting time, then builds credit memos against day-rates." },
      { t: "Statutory survey tracker", d: "Class survey schedules (DNV, BV, Lloyd's) plus Cabotage and NIMASA operating licences." },
    ],
  },
  yardtrace: {
    name: "YardTrace",
    tagline: "Rigging, tools & LOLER compliance",
    badge: { text: "Asset protection", tone: "info" },
    icon: Icon.Anchor,
    summary:
      "Stops equipment being rejected at FPSOs and platforms because of missing calibration curves or expired LOLER proof-load certificates.",
    features: [
      { t: "Quarterly colour-coding", d: "Flags slings, shackles and cargo baskets against the current industry quarter colour." },
      { t: "Digital chain of custody", d: "Scanned at each handover from shore base to supply boat deck to offshore platform, with dual touch sign-off." },
      { t: "Certificate-linked assets", d: "Every serial number carries its inspection history, load test and calibration documents." },
    ],
  },
  safework: {
    name: "SafeWork",
    tagline: "Permit-to-Work & HSE observations",
    badge: { text: "Field critical", tone: "warn" },
    icon: Icon.Shield,
    summary:
      "Brings permits and safety observations to the worksite, with gas limits and risk matrices set to match each IOC's safety management system.",
    features: [
      { t: "Digital Permit-to-Work", d: "Multi-stakeholder signature capture with photo evidence, even when the device is offline." },
      { t: "Configurable gas thresholds", d: "Dynamic H₂S, LEL and O₂ limits that trigger a hold when breached." },
      { t: "Tailored risk matrices", d: "5×5 or 4×4 assessment grids plus client-specific STOP and safety observation workflows." },
    ],
  },
};

/* ---------------- Previews ---------------- */

function CrewPassPreview() {
  const rows = [
    { n: "Adaeze Okafor", trade: "Crane Op.", c: ["ok", "ok", "ok", "warn"] },
    { n: "Tunde Ibekwe", trade: "Rigger", c: ["ok", "ok", "ok", "ok"] },
    { n: "Emeka Okon", trade: "Electrician", c: ["crit", "ok", "warn", "ok"] },
    { n: "Fatima Bassey", trade: "Deck Foreman", c: ["ok", "warn", "ok", "ok"] },
    { n: "Ibrahim Musa", trade: "Mechanic", c: ["ok", "ok", "ok", "ok"] },
  ];
  const cols = ["OSP", "BOSIET", "Medical", "STCW"];
  const pill = { ok: "bg-ok/20 text-green-300", warn: "bg-amber/20 text-amber-300", crit: "bg-hazard/20 text-red-300" };
  const txt = { ok: "Valid", warn: "28d", crit: "Expired" };
  return (
    <div className="space-y-3">
      <div className="overflow-x-auto rounded-2xl bg-navy/70 ring-1 ring-white/10">
        <div className="min-w-[440px]">
        <div className="grid grid-cols-[1.6fr_repeat(4,1fr)] gap-2 border-b border-white/10 bg-white/[0.03] px-4 py-2.5 font-mono text-[10px] uppercase tracking-wider text-slate-400">
          <span>Personnel</span>
          {cols.map((c) => (
            <span key={c}>{c}</span>
          ))}
        </div>
        {rows.map((r) => (
          <div key={r.n} className="grid grid-cols-[1.6fr_repeat(4,1fr)] items-center gap-2 border-b border-white/5 px-4 py-2.5 last:border-0">
            <div>
              <p className="text-[13px] text-white">{r.n}</p>
              <p className="text-[11px] text-slate-500">{r.trade}</p>
            </div>
            {r.c.map((c, i) => (
              <span key={i} className={`w-fit rounded-md px-2 py-0.5 text-[10px] font-semibold ${pill[c as keyof typeof pill]}`}>
                {txt[c as keyof typeof txt]}
              </span>
            ))}
          </div>
        ))}
        </div>
      </div>
      <div className="flex items-start gap-3 rounded-2xl border border-hazard/30 bg-hazard/10 p-4">
        <Icon.Lock size={18} className="mt-0.5 shrink-0 text-red-300" />
        <div>
          <p className="text-[13px] font-semibold text-white">Gatekeeper: assignment blocked</p>
          <p className="text-[12px] text-slate-300">
            Emeka Okon cannot join Manifest #MF-2291 (Bonny Star, 06:00). OSP expired 2 days ago. HR and technician notified on WhatsApp.
          </p>
        </div>
      </div>
    </div>
  );
}

function SeaLogPreview() {
  const rows = [
    ["02 Oct", "196.2", "8.1", "0.0", "DP2"],
    ["03 Oct", "188.0", "8.2", "0.0", "Cargo Ops"],
    ["04 Oct", "182.4", "7.9", "2.1", "Standby"],
  ];
  return (
    <div className="space-y-3">
      <div className="overflow-x-auto rounded-2xl bg-navy/70 ring-1 ring-white/10">
        <div className="min-w-[420px]">
          <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
            <p className="font-mono text-[11px] text-slate-400">DSR LEDGER · PSV ATLANTIC GRACE · IMO 9734521</p>
          </div>
          <div className="grid grid-cols-5 gap-2 px-4 py-2 font-mono text-[10px] uppercase tracking-wider text-slate-500">
            <span>Date</span><span>ROB MGO</span><span>Consumed</span><span>Variance</span><span>State</span>
          </div>
          {rows.map((r) => (
            <div key={r[0]} className="grid grid-cols-5 gap-2 border-t border-white/5 px-4 py-2.5 font-mono text-[12px] text-white">
              <span className="text-slate-300">{r[0]}</span>
              <span>{r[1]}</span>
              <span>{r[2]}</span>
              <span className={r[3] !== "0.0" ? "text-amber-300" : "text-green-300"}>{r[3] !== "0.0" ? `⚠ ${r[3]}` : "✓ 0.0"}</span>
              <span className="text-slate-300">{r[4]}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        {[
          ["Breakdown", "7.5 h", "text-red-300"],
          ["Weather standby", "3.0 h", "text-sky-300"],
          ["Charterer waiting", "1.5 h", "text-amber-300"],
        ].map(([k, v, c]) => (
          <div key={k} className="glass-tile rounded-2xl p-3.5">
            <p className="text-[11px] text-slate-400">{k}</p>
            <p className={`mt-1 font-mono text-lg font-semibold ${c}`}>{v}</p>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between rounded-2xl border border-lime/25 bg-lime/[0.07] p-4">
        <div>
          <p className="text-[12px] text-slate-300">Auto credit memo · day-rate $18,500</p>
          <p className="font-mono text-xl font-semibold text-white">−$5,781.25</p>
        </div>
        <span className="rounded-lg bg-white px-3 py-1.5 text-xs font-semibold text-navy">Export dispute pack</span>
      </div>
    </div>
  );
}

function YardTracePreview() {
  const steps = [
    { t: "Shore Base", s: "Onne · 05:10", done: true },
    { t: "Supply Boat Deck", s: "Atlantic Grace · 07:45", done: true },
    { t: "Offshore Platform", s: "FPSO Aje Star · ETA 13:00", done: false },
  ];
  const quarters = [
    { q: "Q1", c: "bg-red-500" },
    { q: "Q2", c: "bg-yellow-400" },
    { q: "Q3", c: "bg-blue-500" },
    { q: "Q4", c: "bg-green-500" },
  ];
  return (
    <div className="space-y-3">
      <div className="rounded-2xl bg-navy/70 p-5 ring-1 ring-white/10">
        <p className="font-mono text-[11px] text-slate-400">CHAIN OF CUSTODY · BASKET CB-118</p>
        <div className="mt-5 flex items-start">
          {steps.map((s, i) => (
            <div key={s.t} className="relative flex-1">
              {i < steps.length - 1 && (
                <span className={`absolute left-5 right-0 top-5 h-[2px] ${s.done ? "bg-lime" : "bg-white/15"}`} />
              )}
              <span
                className={`relative grid h-10 w-10 place-items-center rounded-full ring-4 ring-navy ${
                  s.done ? "bg-lime text-[#0b2a0f]" : "bg-white/10 text-slate-300"
                }`}
              >
                {s.done ? <Icon.Check size={18} /> : <Icon.Ship size={18} />}
              </span>
              <p className="mt-3 pr-2 text-[12.5px] font-semibold text-white">{s.t}</p>
              <p className="pr-2 text-[11px] text-slate-400">{s.s}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="glass-tile rounded-2xl p-4">
          <p className="text-[12px] text-slate-400">Quarter colour standard</p>
          <div className="mt-3 flex gap-2">
            {quarters.map((q) => (
              <div key={q.q} className={`flex-1 rounded-lg p-2 text-center ${q.q === "Q4" ? "ring-2 ring-white" : "opacity-40"}`}>
                <span className={`mx-auto block h-5 w-5 rounded-full ${q.c}`} />
                <span className="mt-1 block font-mono text-[10px] text-white">{q.q}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="glass-tile rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <p className="font-mono text-[12px] text-white">SH-4471 · 8.5T Shackle</p>
            <StatusPill tone="ok">LOLER pass</StatusPill>
          </div>
          <p className="mt-2 text-[12px] text-slate-400">Proof-load 17T · Inspected 18 Sep 2026</p>
          <p className="text-[12px] text-slate-400">Next due 18 Mar 2027</p>
          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full w-[82%] rounded-full bg-lime" />
          </div>
        </div>
      </div>
    </div>
  );
}

function SafeWorkPreview() {
  const gases = [
    { g: "H₂S", v: 3, max: 10, unit: "ppm", tone: "bg-lime" },
    { g: "LEL", v: 8, max: 20, unit: "%", tone: "bg-amber" },
    { g: "O₂", v: 20.8, max: 23.5, unit: "%", tone: "bg-lime" },
  ];
  const matrix = [
    [1, 2, 3, 4, 5],
    [2, 4, 6, 8, 10],
    [3, 6, 9, 12, 15],
    [4, 8, 12, 16, 20],
    [5, 10, 15, 20, 25],
  ];
  const color = (v: number) => (v >= 15 ? "bg-hazard/70" : v >= 8 ? "bg-amber/70" : v >= 4 ? "bg-yellow-400/40" : "bg-ok/50");
  return (
    <div className="grid gap-3 sm:grid-cols-[1.2fr_1fr]">
      <div className="rounded-2xl bg-navy/70 p-4 ring-1 ring-white/10">
        <div className="flex items-center justify-between">
          <p className="font-mono text-[11px] text-slate-400">PTW-0921 · HOT WORK · DECK 2</p>
          <StatusPill tone="warn">Awaiting AA</StatusPill>
        </div>
        <div className="mt-4 space-y-3">
          {gases.map((g) => (
            <div key={g.g}>
              <div className="flex justify-between text-[12px]">
                <span className="text-slate-300">{g.g}</span>
                <span className="font-mono text-white">
                  {g.v} <span className="text-slate-500">/ {g.max} {g.unit}</span>
                </span>
              </div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                <div className={`h-full rounded-full ${g.tone}`} style={{ width: `${(g.v / g.max) * 100}%` }} />
              </div>
            </div>
          ))}
        </div>
        <div className="mt-5 flex gap-2">
          {[
            ["PA", true],
            ["AA", false],
            ["OIM", false],
          ].map(([r, ok]) => (
            <div key={r as string} className={`flex-1 rounded-xl border p-2 text-center ${ok ? "border-lime/40 bg-lime/10" : "border-dashed border-white/15"}`}>
              <Icon.Pen size={14} className={`mx-auto ${ok ? "text-lime" : "text-slate-500"}`} />
              <p className="mt-1 font-mono text-[10px] text-slate-300">{r as string}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="rounded-2xl bg-navy/70 p-4 ring-1 ring-white/10">
        <p className="font-mono text-[11px] text-slate-400">RISK MATRIX · 5×5</p>
        <div className="mt-3 grid grid-cols-5 gap-1">
          {matrix
            .slice()
            .reverse()
            .flat()
            .map((v, i) => (
              <span
                key={i}
                className={`grid aspect-square place-items-center rounded-md font-mono text-[10px] text-white/90 ${color(v)} ${v === 8 && i === 6 ? "ring-2 ring-white" : ""}`}
              >
                {v}
              </span>
            ))}
        </div>
        <p className="mt-3 text-[11px] text-slate-400">Likelihood × Severity · residual risk 8 (Medium)</p>
      </div>
    </div>
  );
}

const previews: Record<ModuleKey, () => React.ReactElement> = {
  crewpass: CrewPassPreview,
  sealog: SeaLogPreview,
  yardtrace: YardTracePreview,
  safework: SafeWorkPreview,
};

export function Modules() {
  const [active, setActive] = useState<ModuleKey>("crewpass");
  const m = modules[active];
  const Preview = previews[active];

  return (
    <section id="modules" className="relative py-28">
      <div className="absolute right-0 top-40 h-[480px] w-[480px] rounded-full bg-blue/15 blur-[140px]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Core engines"
          title={
            <>
              Four engines that close <span className="text-gradient">four kinds of loss.</span>
            </>
          }
          sub="CrewPass, SeaLog, YardTrace and SafeWork share one relational core. A certificate, vessel or sling is entered once and every module sees the same record."
        />

        <Reveal className="mt-14">
          <div className="grid grid-cols-2 gap-2 rounded-2xl bg-white/[0.03] p-2 ring-1 ring-white/10 md:grid-cols-4" role="tablist">
            {(Object.keys(modules) as ModuleKey[]).map((k) => {
              const mod = modules[k];
              const on = k === active;
              return (
                <button
                  key={k}
                  role="tab"
                  aria-selected={on}
                  onClick={() => setActive(k)}
                  className={`group flex items-center gap-3 rounded-xl px-4 py-3.5 text-left transition ${
                    on ? "bg-white/[0.08] ring-1 ring-lime/40" : "hover:bg-white/[0.04]"
                  }`}
                >
                  <span
                    className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl transition ${
                      on ? "bg-lime text-[#0b2a0f]" : "bg-white/[0.06] text-slate-300"
                    }`}
                  >
                    <mod.icon size={19} />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[15px] font-semibold text-white">{mod.name}</span>
                    <span className="hidden truncate text-[11.5px] text-slate-400 sm:block">{mod.tagline}</span>
                  </span>
                </button>
              );
            })}
          </div>

          <div key={active} className="glass mt-5 grid gap-8 rounded-[32px] p-6 sm:p-9 lg:grid-cols-[0.9fr_1.1fr] [animation:float-in_0.5s_ease]">
            <div>
              <StatusPill tone={m.badge.tone}>{m.badge.text.toUpperCase()}</StatusPill>
              <h3 className="mt-4 text-3xl font-semibold tracking-tight text-white">{m.name}</h3>
              <p className="mt-1 text-sm text-lime/90">{m.tagline}</p>
              <p className="mt-5 text-[15px] leading-relaxed text-slate-300">{m.summary}</p>
              <ul className="mt-7 space-y-4">
                {m.features.map((f) => (
                  <li key={f.t} className="flex gap-3">
                    <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-lime/15 text-lime">
                      <Icon.Check size={14} />
                    </span>
                    <div>
                      <p className="text-[14.5px] font-semibold text-white">{f.t}</p>
                      <p className="text-[13px] leading-relaxed text-slate-400">{f.d}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <div className="min-w-0">
              <Preview />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
