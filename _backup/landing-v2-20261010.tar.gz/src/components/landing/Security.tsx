import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const pillars = [
  { icon: Icon.Server, t: "Dedicated single-tenant", d: "Your data never shares a database with another contractor. Each client gets its own private instance." },
  { icon: Icon.Lock, t: "AES-256 at rest · TLS 1.3 in transit", d: "Certificates, manifests and DSRs are encrypted on device, in the database and in object storage." },
  { icon: Icon.Pin, t: "Data residency", d: "Run on-premises, in a local data centre, or in a private cloud in AWS or Azure South Africa regions." },
  { icon: Icon.Shield, t: "Audit trail", d: "Every signature, sync and edit is timestamped and attributed to a person, ready for an IOC audit." },
];

const stack = [
  ["Next.js 15 · React 19", "Web console"],
  ["NestJS / Go", "REST & GraphQL"],
  ["PostgreSQL", "Master relational data"],
  ["Redis", "Sessions & queues"],
  ["S3-compatible", "Encrypted PDF vault"],
  ["Flutter", "iOS & Android"],
  ["WatermelonDB / Drift", "Offline SQLite"],
  ["ML Kit / ZXing", "QR & barcode"],
];

export function Security() {
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Enterprise grade"
          title={
            <>
              Built for the scrutiny of <span className="text-gradient">IOC auditors.</span>
            </>
          }
          sub="Security, hosting and data residency are set up to fit your contract requirements."
        />
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {pillars.map((p, i) => (
            <Reveal key={p.t} delay={i * 90}>
              <div className="glass h-full rounded-3xl p-6">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-lime/10 text-lime ring-1 ring-lime/25">
                  <p.icon size={20} />
                </span>
                <p className="mt-5 text-[15.5px] font-semibold text-white">{p.t}</p>
                <p className="mt-2 text-[13.5px] leading-relaxed text-slate-400">{p.d}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-6 overflow-hidden rounded-3xl border border-white/10 bg-white/[0.02] py-5">
          <div className="flex w-max animate-marquee gap-3 hover:[animation-play-state:paused]">
            {[...stack, ...stack].map(([a, b], i) => (
              <div key={i} className="flex items-center gap-3 rounded-2xl bg-white/[0.04] px-5 py-3 ring-1 ring-white/10">
                <span className="h-2 w-2 rounded-full bg-lime/80" />
                <span className="whitespace-nowrap font-mono text-[13px] text-white">{a}</span>
                <span className="whitespace-nowrap text-[12px] text-slate-500">{b}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
