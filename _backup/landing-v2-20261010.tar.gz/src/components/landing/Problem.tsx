import { Icon } from "./icons";
import { CountUp, Reveal, SectionHeading } from "./primitives";

const stats = [
  { value: <><CountUp prefix="$" to={45} />k</>, label: "Upper daily cost of one mobilization delay or off-hire dispute" },
  { value: <>90·60·30·7</>, label: "Day alert ladder on every certificate, sent by SMS and WhatsApp" },
  { value: <><CountUp to={100} />%</>, label: "Offline-first field writes with store-and-forward sync" },
  { value: <>1</>, label: "Prevented incident a year and the platform has paid for itself" },
];

const leaks = [
  {
    icon: Icon.IdCard,
    tone: "text-red-300 bg-hazard/15 ring-hazard/25",
    title: "Dockside rejections",
    cost: "NPT penalties",
    body: "A technician with an expired OSP or BOSIET gets turned back at the terminal. That costs you the vessel slot, the client relationship and tens of thousands of dollars.",
    fix: "CrewPass blocks non-compliant personnel from outbound manifests automatically.",
  },
  {
    icon: Icon.Fuel,
    tone: "text-amber-300 bg-amber/15 ring-amber/25",
    title: "Bunker & off-hire leakage",
    cost: "Disputed day-rates",
    body: "Paper DSRs and spreadsheet reconciliation hide fuel discrepancies. Without hour-level evidence, charter off-hire disputes drag on for months.",
    fix: "SeaLog reconciles ROB daily and builds credit memo schedules against the charter party.",
  },
  {
    icon: Icon.FileText,
    tone: "text-sky-300 bg-sky/15 ring-sky/25",
    title: "Bid disqualification",
    cost: "Lost contracts",
    body: "IOC auditors ask for certificate trails, LOLER proof-load records and permit evidence. Gaps in that paperwork can quietly cost you a tender.",
    fix: "Every record is timestamped, signed and exportable in the client's own format.",
  },
];

export function Problem() {
  return (
    <section className="relative">
      {/* Metrics band */}
      <div className="relative z-10 mx-auto -mt-10 max-w-7xl px-4 sm:px-6">
        <div className="glass-strong grid grid-cols-2 divide-white/10 overflow-hidden rounded-3xl lg:grid-cols-4 lg:divide-x">
          {stats.map((s, i) => (
            <Reveal key={i} delay={i * 90} className="p-6 sm:p-8">
              <p className="font-mono text-2xl font-semibold text-white sm:text-3xl">{s.value}</p>
              <p className="mt-2 text-[13px] leading-snug text-slate-400">{s.label}</p>
            </Reveal>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-28 sm:px-6">
        <SectionHeading
          eyebrow="Why PetroLogix"
          title={
            <>
              Generic ERPs miss the
              <span className="text-slate-500"> three leaks that drain service contractors.</span>
            </>
          }
          sub="PetroLogix is built around the failure points between your coastal office in Lagos, Port Harcourt or Warri and your crews on jetties, supply vessels and production platforms."
        />

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {leaks.map((l, i) => (
            <Reveal key={l.title} delay={i * 120}>
              <article className="group glass relative h-full overflow-hidden rounded-3xl p-7 transition duration-500 hover:-translate-y-1 hover:border-white/20">
                <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-lime/0 blur-3xl transition duration-700 group-hover:bg-lime/10" />
                <div className="flex items-center justify-between">
                  <span className={`grid h-12 w-12 place-items-center rounded-2xl ring-1 ${l.tone}`}>
                    <l.icon size={22} />
                  </span>
                  <span className="font-mono text-[11px] uppercase tracking-widest text-slate-500">{l.cost}</span>
                </div>
                <h3 className="mt-6 text-xl font-semibold text-white">{l.title}</h3>
                <p className="mt-3 text-[14.5px] leading-relaxed text-slate-400">{l.body}</p>
                <div className="mt-6 flex gap-3 rounded-2xl border border-lime/15 bg-lime/[0.05] p-4">
                  <Icon.Check size={18} className="mt-0.5 shrink-0 text-lime" />
                  <p className="text-[13.5px] leading-relaxed text-slate-200">{l.fix}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
