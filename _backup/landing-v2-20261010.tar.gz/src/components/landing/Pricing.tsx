"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const tiers = [
  {
    name: "Tier 1",
    price: 12000,
    scope: "Up to 50 crew · 3 vessels",
    features: ["Central Web Portal", "Unlimited Field-Link syncs", "CrewPass, SeaLog, YardTrace & SafeWork", "Statutory compliance updates", "Server maintenance"],
  },
  {
    name: "Tier 2",
    price: 24000,
    scope: "Up to 250 crew · 10 vessels",
    featured: true,
    features: ["Everything in Tier 1", "5× the crew capacity", "Over 3× the fleet capacity", "Manifest Studio client formats", "Bunker & off-hire ledger at fleet scale"],
  },
  {
    name: "Enterprise",
    price: null,
    scope: "Unlimited assets",
    features: ["Everything in Tier 2", "Unlimited crew & vessels", "On-premises or local DC hosting", "Private cloud (AWS / Azure South Africa)", "Custom quote for your footprint"],
  },
];

function fmt(n: number) {
  return "$" + Math.round(n).toLocaleString("en-US");
}

function Slider({
  label,
  value,
  display,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  display: string;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <div className="flex items-center justify-between text-[13px]">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono font-semibold text-white">{display}</span>
      </div>
      <input
        type="range"
        className="mt-3 w-full"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ background: `linear-gradient(90deg, var(--lime) ${((value - min) / (max - min)) * 100}%, rgba(255,255,255,0.1) 0)` }}
      />
    </label>
  );
}

function RoiCalculator() {
  const [incidents, setIncidents] = useState(2);
  const [days, setDays] = useState(3);
  const [cost, setCost] = useState(30000);
  const [tier, setTier] = useState(1);

  const license = tier === 0 ? 12000 : 24000;
  const avoided = incidents * days * cost;
  const multiple = avoided / license;
  const payback = avoided > 0 ? Math.max(1, Math.round((license / avoided) * 365)) : 0;

  return (
    <div className="glass grid gap-8 rounded-[32px] p-6 sm:p-9 lg:grid-cols-2">
      <div>
        <p className="text-xl font-semibold text-white">How fast does it pay for itself?</p>
        <p className="mt-2 text-[14px] text-slate-400">
          One offshore mobilization delay or off-hire dispute typically costs $15,000–$45,000 a day.
        </p>
        <div className="mt-8 space-y-7">
          <Slider label="Incidents prevented per year" value={incidents} display={`${incidents}`} min={0} max={12} step={1} onChange={setIncidents} />
          <Slider label="Average days lost per incident" value={days} display={`${days} d`} min={1} max={10} step={1} onChange={setDays} />
          <Slider label="Cost per day" value={cost} display={fmt(cost)} min={15000} max={45000} step={1000} onChange={setCost} />
          <div className="flex items-center justify-between text-[13px]">
            <span className="text-slate-300">License tier</span>
            <div className="flex rounded-xl bg-white/[0.05] p-1">
              {["Tier 1", "Tier 2"].map((t, i) => (
                <button
                  key={t}
                  onClick={() => setTier(i)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${tier === i ? "bg-white text-navy" : "text-slate-300"}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="relative flex flex-col justify-between overflow-hidden rounded-3xl bg-gradient-to-br from-lime/20 via-lime/5 to-transparent p-6 ring-1 ring-lime/25 sm:p-8">
        <div className="absolute -right-10 -top-10 h-48 w-48 rounded-full bg-lime/20 blur-3xl" />
        <div className="relative">
          <p className="text-[13px] text-slate-300">Losses avoided per year</p>
          <p className="mt-2 font-mono text-4xl font-semibold text-white sm:text-5xl">{fmt(avoided)}</p>
        </div>
        <div className="relative mt-8 grid grid-cols-2 gap-4">
          <div className="rounded-2xl bg-black/20 p-4">
            <p className="text-[12px] text-slate-400">Return on license</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-lime">{multiple.toFixed(1)}×</p>
          </div>
          <div className="rounded-2xl bg-black/20 p-4">
            <p className="text-[12px] text-slate-400">Payback period</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-white">{avoided > 0 ? `${payback} days` : "—"}</p>
          </div>
        </div>
        <p className="relative mt-6 text-[12px] text-slate-400">
          Against a {fmt(license)}/yr license. Excludes one-time setup.
        </p>
      </div>
    </div>
  );
}

export function Pricing() {
  return (
    <section id="pricing" className="relative py-28">
      <div className="absolute left-1/2 top-20 h-[400px] w-[700px] -translate-x-1/2 rounded-full bg-lime/[0.06] blur-[140px]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          center
          eyebrow="Commercials"
          title={
            <>
              A revenue-protection service, <span className="text-gradient">not another software bill.</span>
            </>
          }
          sub="If PetroLogix Core prevents one off-hire dispute or mobilization failure a year, it has paid for itself."
        />

        <Reveal className="mt-14">
          <RoiCalculator />
        </Reveal>

        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          {tiers.map((t, i) => (
            <Reveal key={t.name} delay={i * 100}>
              <div
                className={`relative h-full rounded-[28px] p-7 ${
                  t.featured ? "glass-strong ring-1 ring-lime/50 shadow-[0_30px_80px_-30px_rgba(180,240,90,0.45)]" : "glass"
                }`}
              >
                {t.featured && (
                  <span className="absolute -top-3 left-7 rounded-full bg-lime px-3 py-1 text-[11px] font-bold text-[#0b2a0f]">
                    Most popular
                  </span>
                )}
                <p className="text-sm font-semibold text-slate-300">{t.name}</p>
                <p className="mt-4 flex items-baseline gap-1.5">
                  <span className="text-4xl font-semibold tracking-tight text-white">{t.price ? fmt(t.price) : "Custom"}</span>
                  {t.price && <span className="text-sm text-slate-400">/ year</span>}
                </p>
                <p className="mt-2 text-[13px] text-lime/90">{t.scope}</p>
                <ul className="mt-6 space-y-3 border-t border-white/10 pt-6">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-center gap-2.5 text-[14px] text-slate-300">
                      <Icon.Check size={16} className="shrink-0 text-lime" /> {f}
                    </li>
                  ))}
                </ul>
                <a
                  href="#contact"
                  className={`mt-8 flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition ${
                    t.featured ? "btn-lime" : "bg-white/[0.06] text-white ring-1 ring-white/10 hover:bg-white/10"
                  }`}
                >
                  {t.price ? "Start with " + t.name : "Talk to sales"} <Icon.Arrow size={16} />
                </a>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-4">
          <div className="flex flex-col items-start justify-between gap-4 rounded-[28px] border border-dashed border-white/15 p-6 sm:flex-row sm:items-center">
            <div className="flex items-start gap-4">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/[0.06] text-lime">
                <Icon.Wrench size={20} />
              </span>
              <div>
                <p className="font-semibold text-white">Implementation & custom tailoring</p>
                <p className="text-[13.5px] text-slate-400">
                  White-labelling, domain setup, migrating historical Excel records to SQL, and client-specific manifest formats.
                </p>
              </div>
            </div>
            <p className="shrink-0 font-mono text-lg font-semibold text-white">
              $8k – $15k <span className="text-xs font-normal text-slate-400">one-time · or NGN equivalent</span>
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
