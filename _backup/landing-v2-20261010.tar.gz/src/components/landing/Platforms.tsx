"use client";

import { useEffect, useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const portal = [
  { icon: Icon.IdCard, t: "Certification expiry matrix", d: "Automated 90/60/30-day statutory expiry tracking with mobilization gatekeeping." },
  { icon: Icon.Users, t: "Crew rotation master", d: "14/14 and 28/28 hitch scheduling with payroll standby calculations." },
  { icon: Icon.Fuel, t: "Bunker & off-hire ledger", d: "Real-time marine bunker reconciliation and a charter party off-hire audit trail." },
  { icon: Icon.FileText, t: "Client Manifest Studio", d: "Drag crew onto a hitch and generate manifests in each IOC's required format." },
];

const field = [
  { icon: Icon.Database, t: "Encrypted local database", d: "Every write lands in on-device SQLite first and syncs later." },
  { icon: Icon.QR, t: "QR equipment scanner", d: "High-speed scanning for base yard dispatch and dock receipts." },
  { icon: Icon.Ship, t: "Daily Status Reports", d: "Captains log ROB fuel, running hours and sea state from the bridge." },
  { icon: Icon.Pen, t: "Digital Permit-to-Work", d: "Multi-party signature capture with photo evidence." },
];

const syncStates = [
  { label: "Offline", sub: "12 records stored on device", cls: "bg-slate-500/20 text-slate-300 ring-slate-400/30", icon: Icon.WifiOff },
  { label: "Pending Sync", sub: "Uploading 12 deltas via VSAT", cls: "bg-amber/20 text-amber-300 ring-amber/30", icon: Icon.Sync },
  { label: "Synced", sub: "All records confirmed by HQ", cls: "bg-lime/20 text-lime ring-lime/30", icon: Icon.Check },
];

function Phone() {
  const [s, setS] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setS((x) => (x + 1) % 3), 2600);
    return () => clearInterval(t);
  }, []);
  const st = syncStates[s];

  const tiles = [
    { icon: Icon.QR, t: "Scan Equipment", c: "from-lime/30 to-lime/5 text-lime" },
    { icon: Icon.Ship, t: "Submit DSR", c: "from-sky/30 to-sky/5 text-sky-300" },
    { icon: Icon.Eye, t: "Safety Observation", c: "from-amber/30 to-amber/5 text-amber-300" },
    { icon: Icon.IdCard, t: "My Digital Pass", c: "from-white/20 to-white/5 text-white" },
  ];

  return (
    <div className="relative mx-auto w-[290px]">
      <div className="absolute -inset-10 rounded-full bg-lime/10 blur-3xl" />
      <div className="relative rounded-[46px] border border-white/15 bg-gradient-to-b from-[#1c2c3e] to-[#0a1522] p-2.5 shadow-[0_50px_100px_-30px_rgba(0,0,0,0.9)]">
        <div className="relative overflow-hidden rounded-[38px] bg-[#071321]">
          <div className="absolute left-1/2 top-2 z-10 h-6 w-24 -translate-x-1/2 rounded-full bg-black" />
          <div className="px-5 pb-6 pt-12">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>MV Bonny Star</span>
              <span className="font-mono">05:42</span>
            </div>
            <p className="mt-1 text-xl font-semibold text-white">Field Home</p>

            <div className="mt-4 rounded-2xl bg-white/[0.05] p-3.5 ring-1 ring-white/10">
              <p className="text-[10px] uppercase tracking-widest text-slate-500">Sync health</p>
              <div className="mt-2 flex items-center gap-2.5">
                <span className={`grid h-9 w-9 place-items-center rounded-xl ring-1 transition-all duration-500 ${st.cls}`}>
                  <st.icon size={18} className={s === 1 ? "animate-spin [animation-duration:2s]" : ""} />
                </span>
                <div>
                  <p className="text-sm font-semibold text-white">{st.label}</p>
                  <p className="text-[11px] text-slate-400">{st.sub}</p>
                </div>
              </div>
              <div className="mt-3 flex gap-1">
                {syncStates.map((_, i) => (
                  <span key={i} className={`h-1 flex-1 rounded-full transition-all duration-500 ${i <= s ? "bg-lime" : "bg-white/10"}`} />
                ))}
              </div>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2.5">
              {tiles.map((t) => (
                <div key={t.t} className={`flex min-h-[92px] flex-col justify-between rounded-2xl bg-gradient-to-br p-3 ring-1 ring-white/10 ${t.c}`}>
                  <t.icon size={22} />
                  <p className="text-[12px] font-semibold leading-tight text-white">{t.t}</p>
                </div>
              ))}
            </div>

            <div className="mt-3 rounded-2xl bg-white/[0.05] p-3 ring-1 ring-white/10">
              <div className="flex items-center justify-between">
                <p className="text-[12px] font-medium text-white">Today&apos;s DSR</p>
                <span className="rounded bg-amber/20 px-1.5 text-[10px] font-semibold text-amber-300">Draft</span>
              </div>
              <div className="mt-2 grid grid-cols-3 gap-2 font-mono text-[10px]">
                <div><p className="text-slate-500">ROB</p><p className="text-white">182.4</p></div>
                <div><p className="text-slate-500">Burn</p><p className="text-white">7.9</p></div>
                <div><p className="text-slate-500">Mode</p><p className="text-white">DP2</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeatureList({ items }: { items: typeof portal }) {
  return (
    <ul className="mt-7 grid gap-3 sm:grid-cols-2">
      {items.map((f) => (
        <li key={f.t} className="glass-tile rounded-2xl p-4">
          <f.icon size={20} className="text-lime" />
          <p className="mt-3 text-[14.5px] font-semibold text-white">{f.t}</p>
          <p className="mt-1 text-[13px] leading-relaxed text-slate-400">{f.d}</p>
        </li>
      ))}
    </ul>
  );
}

export function Platforms() {
  return (
    <section id="field-link" className="relative py-28">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Dual-platform architecture"
          title={
            <>
              One system for <span className="text-gradient">headquarters</span> and{" "}
              <span className="text-gradient">the field.</span>
            </>
          }
          sub="The central web portal runs your coastal office and the Field-Link mobile suite runs on deck. Both work from the same record, even when the field has no signal."
        />

        <div className="mt-16 grid gap-6 lg:grid-cols-2">
          <Reveal className="glass relative overflow-hidden rounded-[32px] p-7 sm:p-9">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-2 text-sm font-semibold text-white">
                <Icon.Monitor size={20} className="text-sky-300" /> Central Ops Web Portal
              </span>
              <span className="rounded-md bg-sky/15 px-2 py-1 font-mono text-[10px] font-bold text-sky-300">DESKTOP / HQ</span>
            </div>
            <p className="mt-4 text-[15px] leading-relaxed text-slate-300">
              For operations managers, logistics coordinators, crewing and HR executives, and marine technical
              superintendents.
            </p>
            <FeatureList items={portal} />

            {/* Mini manifest preview */}
            <div className="mt-6 overflow-hidden rounded-2xl bg-navy/60 ring-1 ring-white/10">
              <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
                <p className="font-mono text-[11px] text-slate-400">MANIFEST · MV BONNY STAR · HITCH 28/28</p>
                <span className="rounded bg-lime/15 px-1.5 text-[10px] font-semibold text-lime">Ready to sign</span>
              </div>
              {[
                ["A. Okafor", "Crane Operator", "ok"],
                ["T. Ibekwe", "Rigger", "ok"],
                ["E. Okon", "Electrician", "crit"],
                ["F. Bassey", "Deck Foreman", "warn"],
              ].map(([n, r, s]) => (
                <div key={n} className="flex items-center justify-between border-b border-white/5 px-4 py-2 text-[12.5px] last:border-0">
                  <span className="text-white">{n}</span>
                  <span className="hidden text-slate-400 sm:block">{r}</span>
                  <span
                    className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                      s === "ok" ? "bg-ok/15 text-green-300" : s === "warn" ? "bg-amber/15 text-amber-300" : "bg-hazard/15 text-red-300"
                    }`}
                  >
                    {s === "ok" ? "Fit to mobilize" : s === "warn" ? "Expires 21d" : "Blocked · OSP"}
                  </span>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={120} className="glass relative overflow-hidden rounded-[32px] p-7 sm:p-9">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-2 text-sm font-semibold text-white">
                <Icon.Phone size={20} className="text-amber-300" /> Field-Link Mobile Suite
              </span>
              <span className="rounded-md bg-amber/15 px-2 py-1 font-mono text-[10px] font-bold text-amber-300">iOS & ANDROID</span>
            </div>
            <p className="mt-4 text-[15px] leading-relaxed text-slate-300">
              For vessel captains, offshore technicians, yard foremen, HSE field inspectors and rig supervisors.
              Large touch targets work with gloves on deck.
            </p>
            <div className="mt-8 grid items-center gap-8 xl:grid-cols-[auto_1fr]">
              <Phone />
              <ul className="space-y-3">
                {field.map((f) => (
                  <li key={f.t} className="flex gap-3">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/[0.06] text-lime ring-1 ring-white/10">
                      <f.icon size={18} />
                    </span>
                    <div>
                      <p className="text-[14px] font-semibold text-white">{f.t}</p>
                      <p className="text-[12.5px] leading-relaxed text-slate-400">{f.d}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
