"use client";

import { useMemo, useState, type ComponentType } from "react";
import { Icon } from "./icons";
import { seeded } from "./charts";
import { Reveal, SectionHeading } from "./primitives";

type Group = "Marine" | "Pipeline & EPC" | "Depot & Haulage" | "HSE & Compliance" | "Commercial";
type Preview =
  | "bunker"
  | "pipe"
  | "refinery"
  | "haul"
  | "epc"
  | "safe"
  | "stores"
  | "tank"
  | "shield"
  | "billing"
  | "portal"
  | "owner";

type Module = {
  n: number;
  name: string;
  tag: string;
  group: Group;
  icon: ComponentType<{ size?: number; className?: string }>;
  phase: string;
  addon?: string;
  blurb: string;
  features: string[];
  preview: Preview;
};

const modules: Module[] = [
  {
    n: 1,
    name: "BunkerFlow",
    tag: "Marine fuel and port services",
    group: "Marine",
    icon: Icon.Ship,
    phase: "Phase 1 · MVP",
    addon: "e-BDN export interoperability add-on",
    blurb: "Nomination to dual-signed e-BDN, with soundings corrected to standard and every sample seal tracked.",
    features: [
      "Nomination intake, stem confirmation, price quote and invoice",
      "Tank sounding with ASTM 54B / 56 conversion, fore and aft, trim and temperature correction",
      "e-BDN with flashpoint, viscosity, sulphur and water content, signed by Chief Engineer and supplier",
      "Sample seal tracking and MARPOL Annex VI-linked records",
      "STS transfer ledger: mooring, fenders, vapour balancing, pump rate, JSA",
      "Port husbandry: fresh water, lube oils, spares and provisions with receipts",
      "e-BDN export in standard formats for international counterparties",
    ],
    preview: "bunker",
  },
  {
    n: 2,
    name: "PipeIntegrity",
    tag: "Pipeline services and EPC support",
    group: "Pipeline & EPC",
    icon: Icon.Pipe,
    phase: "Phase 2",
    addon: "Intelligent pigging ingestion · CP and asset integrity add-ons",
    blurb: "Pig runs, hydrotests, NDT, cathodic protection and right-of-way checks for every line, in one integrity record.",
    features: [
      "Pigging run tracker: scraper, brush, gauging, intelligent MFL/UT, launcher to receiver",
      "Hydrotest engine: pressure vs. temperature, hold-period validation, pressure-drop alerts",
      "Code basis per line: ASME B31.4 (liquid), B31.8 (gas), API 1110 test procedure",
      "NDT and corrosion registry with weld IDs and remaining-life calculation",
      "Cathodic protection: CIPS and DCVG surveys, rectifier readings, anode records",
      "Valve leak detection and maintenance, chemical cleaning and commissioning packs",
      "Right-of-way surveillance with geotagged photos; IOC audit-format export",
    ],
    preview: "pipe",
  },
  {
    n: 3,
    name: "RefineryLink",
    tag: "Gantry, tank farm and depot",
    group: "Depot & Haulage",
    icon: Icon.Tank,
    phase: "Phase 3",
    addon: "Lagos e-Call-Up connector · Gantry bridge (subject to access)",
    blurb: "Depot reconciliation at every discharge, not at month-end, from ATG import to quality certificate per batch.",
    features: [
      "Terminal offtake and truck appointment scheduling",
      "Holding-park queue manager: check-in, RFID or QR read, slot assignment, driver accreditation",
      "Automated tank gauging import and ullage dips; GOV to NSV at 15 °C or 20 °C",
      "Gantry meter ticket reconciliation with AccuLoad and Smith Meter batch controllers",
      "Quality certificate per batch: density, flash point, distillation, RON, sulphur ppm",
      "Lagos e-Call-Up connector, conditional on confirmed API access",
    ],
    preview: "refinery",
  },
  {
    n: 4,
    name: "HaulTrac",
    tag: "Bulk road haulage",
    group: "Depot & Haulage",
    icon: Icon.Truck,
    phase: "Phase 1 · MVP",
    blurb: "From weighbridge to buyer e-signature, every truck carries a tamper-evident e-Waybill.",
    features: [
      "Weighbridge tare and gross capture with digital weighbridge integration",
      "Encrypted, tamper-evident e-Waybill with QR dispatch data",
      "Compartment valve and geofence monitoring via telematics",
      "Route deviation and unauthorised-stop alerts",
      "Proof of delivery: ullage, temperature, water-paste test, buyer e-signature",
      "Fleet compliance: papers, licences, tanker inspection and calibration certificates",
      "Fee and levy ledger with evidence for disputes",
    ],
    preview: "haul",
  },
  {
    n: 5,
    name: "EPC-Link",
    tag: "Procurement, OCTG and local content",
    group: "Pipeline & EPC",
    icon: Icon.Building,
    phase: "Phase 2",
    addon: "NCFCC / NOGIC-JQS export pack · free in Growth and above",
    blurb: "Stay tender-ready: NCFCC readiness, Nigerian Content spend and bid dossiers, all from one place.",
    features: [
      "Material requisition and pipe yard control: heat numbers, MTCs, wall thickness, bays, QR tags",
      "NCDMB Nigerian Content spend engine: payroll, local fabrication, raw materials",
      "NCFCC readiness checker and renewal alerts",
      "NOGIC-JQS export pack for registration, tenders and M&E reporting",
      "NCEC expiry and calibration tracker for cranes and test spreads",
      "Bid dossier export: NUPRC permits, NCDMB documents, PENCOM, ITF, NSITF",
      "Vendor prequalification workflow for IOC tenders",
    ],
    preview: "epc",
  },
  {
    n: 6,
    name: "SafePass",
    tag: "HSE, permits and rotations",
    group: "HSE & Compliance",
    icon: Icon.Shield,
    phase: "Phase 1 · MVP",
    addon: "WhatsApp crew-expiry bot add-on",
    blurb: "No valid ticket, no seat on the boat. No passed gas test, no permit.",
    features: [
      "Mobilisation gate: BOSIET, HUET, OSP, STCW, medical. Blocks manifests when credentials expire within 30 days",
      "Digital Permit-to-Work: hot work, confined space, heights, excavation; multi-level approvals",
      "Gas test entry (H₂S, LEL, O₂) with interlocks that block permit issue on failure",
      "JSA and toolbox talk records",
      "Hazard observation and near-miss reporting, offline with photos and risk matrix",
      "CAPA tracking to closure",
      "Rotation scheduler (14/14, 28/28) with standby vs. active day-rate ledger",
    ],
    preview: "safe",
  },
  {
    n: 7,
    name: "MarineStores",
    tag: "Ship spares, provisions and consumables",
    group: "Marine",
    icon: Icon.Package,
    phase: "Phase 3",
    addon: "MarineStores · Refrigerant gas tracking add-ons",
    blurb: "One catalogue for everything you put on board, from lube grades to refrigerant cylinders.",
    features: [
      "Catalogue for ship spares, PPE, safety and life-saving equipment, deck and engine stores",
      "Branded lubricant catalogue with grade and pack-size lookup",
      "Bonded stores and provisions management",
      "Medical supplies with expiry tracking",
      "Charts and publications subscription tracking",
      "Refrigerant gas inventory (R404, R22, R407, R134a, R407C, R410A) with cylinder and recovery logs",
    ],
    preview: "stores",
  },
  {
    n: 8,
    name: "TankWorks",
    tag: "Tank and field services",
    group: "Pipeline & EPC",
    icon: Icon.Wrench,
    phase: "Phase 3",
    addon: "TankWorks job-costing add-on",
    blurb: "Job costing for tank evacuation, cleaning, blasting and recoating, linked to confined-space permits.",
    features: [
      "Job costing for tank evacuation, cleaning, blasting and recoating",
      "Confined-space entry linked to SafePass permits",
      "Sludge and waste disposal manifests",
      "Recoating inspection records: DFT readings and adhesion tests",
      "Crew hours and equipment utilisation per job",
    ],
    preview: "tank",
  },
  {
    n: 9,
    name: "Compliance Shield",
    tag: "Regulatory calendar",
    group: "HSE & Compliance",
    icon: Icon.Calendar,
    phase: "Phase 2",
    blurb: "Every licence, permit and certificate on one calendar, with alerts well before expiry.",
    features: [
      "Single calendar for NCDMB, NUPRC, NMDPRA, NIMASA, NPA and ISO renewals",
      "Automatic alerts at 90, 60, 30 and 7 days",
      "Audit pack generation per regulator or client",
      "Evidence trail for ISO 9001, 14001 and 45001 audits",
    ],
    preview: "shield",
  },
  {
    n: 10,
    name: "Billing & Commercial",
    tag: "Job costing to cash",
    group: "Commercial",
    icon: Icon.Receipt,
    phase: "Phase 3",
    blurb: "Invoice in naira or dollars with the rate captured, and get paid through local gateways.",
    features: [
      "Job costing across modules",
      "Interim payment certificates (IPC) for EPC contracts",
      "Invoices in NGN and USD with a rate snapshot",
      "Payment links through local gateways such as Paystack and Flutterwave",
      "Customer statements and ageing reports",
    ],
    preview: "billing",
  },
  {
    n: 11,
    name: "Client Portal",
    tag: "External, read-only",
    group: "Commercial",
    icon: Icon.Globe,
    phase: "Phase 2",
    addon: "Client Portal add-on · free in Enterprise",
    blurb: "Your IOC and EPC clients see the BDNs, PODs and certificates themselves, and ask their other vendors to use PetroLedger too.",
    features: [
      "Read-only portal for IOCs, EPC clients and fleet customers",
      "Shared BDNs, PODs, test certificates and inspection reports",
      "Creates pull from the demand side: clients see it working",
    ],
    preview: "portal",
  },
  {
    n: 12,
    name: "Owner Dashboard",
    tag: "Cross-module KPIs",
    group: "Commercial",
    icon: Icon.Chart,
    phase: "Phase 4",
    blurb: "Turnaround, shrinkage, reconciliation status and certificate risk across the whole business on one screen.",
    features: [
      "Live KPIs: turnaround time, shrinkage %, reconciliation status, certificate risk, utilisation",
      "Exception feed: variances over 0.5%, failed gas tests, expired credentials",
    ],
    preview: "owner",
  },
];

const groups: ("All" | Group)[] = ["All", "Marine", "Pipeline & EPC", "Depot & Haulage", "HSE & Compliance", "Commercial"];

/* ------------------------------------------------------------------ */
/* Previews                                                            */
/* ------------------------------------------------------------------ */

function Row({ l, r, tone = "text-white" }: { l: string; r: string; tone?: string }) {
  return (
    <div className="flex items-center justify-between border-b border-white/[0.06] py-2 text-[12.5px] last:border-0">
      <span className="text-slate-400">{l}</span>
      <span className={`font-mono font-semibold ${tone}`}>{r}</span>
    </div>
  );
}

function Ring({ pct, label }: { pct: number; label: string }) {
  const c = 2 * Math.PI * 42;
  return (
    <div className="relative h-36 w-36">
      <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
        <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="9" />
        <circle
          cx="50"
          cy="50"
          r="42"
          fill="none"
          stroke="url(#ringG)"
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)" }}
        />
        <defs>
          <linearGradient id="ringG" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#fbbf24" />
            <stop offset="1" stopColor="#d97706" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <p className="text-3xl font-extrabold text-white">{Math.round(pct * 100)}%</p>
          <p className="text-[10.5px] font-semibold uppercase tracking-wider text-slate-400">{label}</p>
        </div>
      </div>
    </div>
  );
}

function Bars({ seed, n = 14, tone = "bg-gold" }: { seed: number; n?: number; tone?: string }) {
  const d = useMemo(() => seeded(n, seed, 0.25, 1), [seed, n]);
  return (
    <div className="flex h-24 items-end gap-1.5">
      {d.map((v, i) => (
        <span key={i} className={`bar-anim flex-1 rounded-t-md ${tone}`} style={{ height: `${v * 100}%`, opacity: 0.45 + v * 0.55, animationDelay: `${i * 0.04}s` }} />
      ))}
    </div>
  );
}

function PreviewBody({ kind }: { kind: Preview }) {
  switch (kind) {
    case "bunker":
      return (
        <div className="grid gap-4 sm:grid-cols-[150px_1fr]">
          <div className="relative mx-auto h-48 w-28 overflow-hidden rounded-[22px] border border-white/15 bg-black/20">
            <div className="bar-anim absolute inset-x-0 bottom-0 h-[68%] bg-gradient-to-t from-safety via-amber to-gold/80">
              <div className="shimmer absolute inset-x-0 top-0 h-3" />
            </div>
            {[20, 40, 60, 80].map((y) => (
              <span key={y} className="absolute left-0 h-px w-3 bg-white/40" style={{ bottom: `${y}%` }} />
            ))}
            <span className="absolute right-2 top-[30%] rounded bg-ink/80 px-1.5 py-0.5 font-mono text-[10px] text-white">2.84 m</span>
          </div>
          <div>
            <p className="text-[12px] font-bold uppercase tracking-wider text-slate-500">Tank 3P · Aft sounding</p>
            <Row l="Observed volume" r="412.60 m³" />
            <Row l="Trim correction" r="−0.84 m³" />
            <Row l="Temperature" r="38.5 °C" />
            <Row l="VCF · Table 54B" r="0.98143" />
            <Row l="Mass · Table 56" r="388.9 MT" tone="text-gold" />
            <div className="mt-3 flex gap-2">
              <span className="rounded-lg bg-white/10 px-2.5 py-1.5 text-[11px] font-semibold text-white">Chief Engineer ✓</span>
              <span className="rounded-lg bg-amber/15 px-2.5 py-1.5 text-[11px] font-semibold text-amber-200">Supplier · pending</span>
            </div>
          </div>
        </div>
      );
    case "pipe": {
      const pts = seeded(30, 3, 0.86, 0.9);
      const d = pts.map((v, i) => `${i ? "L" : "M"}${(i / 29) * 300},${120 - v * 100}`).join(" ");
      return (
        <div>
          <div className="flex items-center justify-between text-[12px]">
            <span className="font-bold uppercase tracking-wider text-slate-500">Hydrotest · Line TL-04 · B31.4</span>
            <span className="rounded-full bg-ok/15 px-2 py-0.5 font-bold text-emerald-300">Hold valid</span>
          </div>
          <svg viewBox="0 0 300 130" className="mt-3 h-40 w-full">
            {[20, 50, 80, 110].map((y) => (
              <line key={y} x1="0" x2="300" y1={y} y2={y} stroke="rgba(255,255,255,0.06)" />
            ))}
            <path d="M0,120 L30,26 L300,26" stroke="rgba(56,189,248,0.5)" strokeDasharray="4 4" fill="none" />
            <path d={`M0,120 L30,${120 - pts[0] * 100} ${d.replace(/^M[^L]+/, "")}`} pathLength={1} className="draw-line" stroke="#fbbf24" strokeWidth="2.4" fill="none" />
            <text x="232" y="20" fontSize="9" fill="#7dd3fc" fontWeight="700">Test pressure</text>
          </svg>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[
              ["Hold", "22h 14m"],
              ["ΔP", "0.3 bar"],
              ["ΔT", "+1.2 °C"],
            ].map(([a, b]) => (
              <div key={a} className="rounded-xl bg-white/[0.05] py-2">
                <p className="text-[10.5px] text-slate-500">{a}</p>
                <p className="font-mono text-[13px] font-bold text-white">{b}</p>
              </div>
            ))}
          </div>
        </div>
      );
    }
    case "refinery":
      return (
        <div>
          <p className="text-[12px] font-bold uppercase tracking-wider text-slate-500">Tank farm · GOV → NSV @ 15 °C</p>
          <div className="mt-4 grid grid-cols-4 gap-3">
            {[0.82, 0.46, 0.67, 0.28].map((v, i) => (
              <div key={i} className="text-center">
                <div className="relative mx-auto h-32 w-full overflow-hidden rounded-t-2xl rounded-b-lg border border-white/12 bg-black/20">
                  <div
                    className={`bar-anim absolute inset-x-0 bottom-0 ${i === 3 ? "bg-gradient-to-t from-azure to-sky" : "bg-gradient-to-t from-safety to-gold"}`}
                    style={{ height: `${v * 100}%`, animationDelay: `${i * 0.1}s` }}
                  />
                </div>
                <p className="mt-2 text-[11px] font-bold text-white">TK-0{i + 1}</p>
                <p className="font-mono text-[10.5px] text-slate-400">{Math.round(v * 12000).toLocaleString()} m³</p>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between rounded-xl bg-white/[0.05] px-3 py-2.5 text-[12px]">
            <span className="text-slate-400">Gantry bay 4 · AccuLoad ticket #88213</span>
            <span className="font-mono font-bold text-emerald-300">Δ 0.06%</span>
          </div>
        </div>
      );
    case "haul":
      return (
        <div className="grid gap-4 sm:grid-cols-[1fr_120px]">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-gold px-2 py-0.5 text-[10px] font-extrabold text-[#2a1800]">e-WAYBILL</span>
              <span className="font-mono text-[12px] text-slate-400">WB-2026-104882</span>
            </div>
            <Row l="Truck · Compartments" r="LSD 482 XY · 3" />
            <Row l="Gross / Tare" r="49.8 t / 15.2 t" />
            <Row l="Product · Volume" r="PMS · 45,000 L" />
            <Row l="Geofence" r="On route" tone="text-emerald-300" />
            <Row l="Seals" r="3/3 intact" tone="text-emerald-300" />
          </div>
          <div className="flex flex-col items-center justify-center rounded-2xl bg-white p-3">
            <svg viewBox="0 0 21 21" className="h-24 w-24" shapeRendering="crispEdges">
              {Array.from({ length: 21 * 21 }).map((_, i) => {
                const x = i % 21;
                const y = Math.floor(i / 21);
                const finder = (x < 7 && y < 7) || (x > 13 && y < 7) || (x < 7 && y > 13);
                const fOn = finder && ((x % 14 === 0 || x % 14 === 6 || y % 14 === 0 || y % 14 === 6) || ((x % 14) > 1 && (x % 14) < 5 && (y % 14) > 1 && (y % 14) < 5));
                const on = finder ? fOn : ((x * 7 + y * 13 + x * y) % 5) < 2;
                return on ? <rect key={i} x={x} y={y} width="1" height="1" fill="#0b1f33" /> : null;
              })}
            </svg>
            <p className="mt-1 text-[9px] font-bold text-navy">SIGNED · SHA-256</p>
          </div>
        </div>
      );
    case "epc":
      return (
        <div className="flex flex-col items-center gap-5 sm:flex-row">
          <Ring pct={0.82} label="NCFCC ready" />
          <div className="w-full flex-1 space-y-2">
            {[
              ["NCDF remittance evidence", true],
              ["Audited accounts uploaded", true],
              ["Nigerian Content plan", true],
              ["NOGIC-JQS profile current", false],
              ["NCEC for Crane CR-02", false],
            ].map(([t, ok]) => (
              <div key={t as string} className="flex items-center gap-2.5 rounded-xl bg-white/[0.04] px-3 py-2 text-[12.5px]">
                <span className={`grid h-5 w-5 place-items-center rounded-full ${ok ? "bg-ok/20 text-emerald-300" : "bg-amber/20 text-amber-300"}`}>
                  {ok ? <Icon.Check size={12} strokeWidth={3} /> : <span className="h-1.5 w-1.5 rounded-full bg-amber" />}
                </span>
                <span className={ok ? "text-slate-300" : "font-semibold text-white"}>{t as string}</span>
              </div>
            ))}
          </div>
        </div>
      );
    case "safe":
      return (
        <div className="space-y-2">
          {[
            { n: "A. Bello", c: "BOSIET", d: "212 days", s: "ok" },
            { n: "C. Eze", c: "HUET", d: "41 days", s: "ok" },
            { n: "E. Okon", c: "OSP", d: "Expired 2 d", s: "crit" },
            { n: "F. Adeyemi", c: "BOSIET", d: "19 days", s: "warn" },
          ].map((p) => (
            <div key={p.n} className="flex items-center gap-3 rounded-2xl bg-white/[0.04] p-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-azure to-navy-2 text-[11px] font-bold text-white">
                {p.n.split(" ").map((x) => x[0]).join("")}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-semibold text-white">{p.n}</p>
                <p className="text-[11px] text-slate-500">
                  {p.c} · {p.d}
                </p>
              </div>
              <span
                className={`rounded-lg px-2.5 py-1 text-[10.5px] font-bold ${
                  p.s === "ok" ? "bg-ok/15 text-emerald-300" : p.s === "warn" ? "bg-amber/15 text-amber-300" : "bg-crit/20 text-red-300"
                }`}
              >
                {p.s === "ok" ? "Cleared" : p.s === "warn" ? "Blocked · <30d" : "Blocked"}
              </span>
            </div>
          ))}
        </div>
      );
    case "stores":
      return (
        <div>
          <p className="text-[12px] font-bold uppercase tracking-wider text-slate-500">Refrigerant cylinders on hand</p>
          <div className="mt-4 grid grid-cols-6 gap-2">
            {[
              ["R404", 0.8],
              ["R22", 0.35],
              ["R407", 0.6],
              ["R134a", 0.9],
              ["R407C", 0.5],
              ["R410A", 0.2],
            ].map(([g, v], i) => (
              <div key={g as string} className="text-center">
                <div className="relative mx-auto h-24 w-9 overflow-hidden rounded-t-full rounded-b-lg border border-white/15 bg-black/20">
                  <div
                    className={`bar-anim absolute inset-x-0 bottom-0 ${(v as number) < 0.3 ? "bg-crit" : "bg-gradient-to-t from-azure to-sky"}`}
                    style={{ height: `${(v as number) * 100}%`, animationDelay: `${i * 0.07}s` }}
                  />
                </div>
                <p className="mt-1.5 font-mono text-[10px] font-bold text-white">{g as string}</p>
              </div>
            ))}
          </div>
          <Row l="Lube: Total Rubia TIR 7400 · 209 L" r="24 drums" />
          <Row l="Medical stores expiring · 60d" r="7 items" tone="text-amber-300" />
        </div>
      );
    case "tank":
      return (
        <div>
          <div className="flex items-center justify-between text-[12px]">
            <span className="font-bold uppercase tracking-wider text-slate-500">Job TW-221 · Tank 7 recoat</span>
            <span className="font-mono font-bold text-gold">₦18.4M / ₦21.0M</span>
          </div>
          <div className="mt-4 space-y-3">
            {[
              ["Evacuation", 1],
              ["Cleaning", 1],
              ["Blasting", 0.72],
              ["Recoating", 0.18],
            ].map(([s, v], i) => (
              <div key={s as string}>
                <div className="flex justify-between text-[12px]">
                  <span className="text-slate-300">{s as string}</span>
                  <span className="font-mono text-slate-400">{Math.round((v as number) * 100)}%</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-white/[0.06]">
                  <div className="bar-anim-x h-full rounded-full bg-gradient-to-r from-amber to-gold" style={{ width: `${(v as number) * 100}%`, animationDelay: `${i * 0.1}s` }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2 text-[12px]">
            <div className="rounded-xl bg-white/[0.05] p-2.5">
              <p className="text-slate-500">DFT avg.</p>
              <p className="font-mono font-bold text-white">312 µm</p>
            </div>
            <div className="rounded-xl bg-white/[0.05] p-2.5">
              <p className="text-slate-500">Confined-space PTW</p>
              <p className="font-bold text-emerald-300">Linked · valid</p>
            </div>
          </div>
        </div>
      );
    case "shield":
      return (
        <div>
          <div className="grid grid-cols-7 gap-1.5 text-center text-[10px] text-slate-500">
            {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
              <span key={i}>{d}</span>
            ))}
            {Array.from({ length: 28 }).map((_, i) => {
              const hit = { 3: "bg-gold text-[#2a1800]", 9: "bg-sky text-ink", 16: "bg-crit text-white", 22: "bg-gold text-[#2a1800]", 25: "bg-sky text-ink" }[i];
              return (
                <span key={i} className={`grid aspect-square place-items-center rounded-lg text-[11px] font-semibold ${hit ?? "bg-white/[0.04] text-slate-400"}`}>
                  {i + 1}
                </span>
              );
            })}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {["90 d", "60 d", "30 d", "7 d"].map((t, i) => (
              <span key={t} className={`rounded-full px-2.5 py-1 text-[10.5px] font-bold ${i === 3 ? "bg-crit/20 text-red-300" : "bg-white/[0.06] text-slate-300"}`}>
                Alert · {t}
              </span>
            ))}
          </div>
        </div>
      );
    case "billing":
      return (
        <div className="rounded-2xl bg-canvas p-4 text-navy">
          <div className="flex items-center justify-between">
            <p className="text-[13px] font-extrabold">INVOICE INV-2026-0418</p>
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">Paystack link</span>
          </div>
          <div className="mt-3 space-y-1.5 text-[12px]">
            <div className="flex justify-between"><span className="text-slate-500">IPC 3 · Pipeline rehab</span><span className="font-mono font-semibold">$48,200.00</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Rate snapshot · 10 Oct</span><span className="font-mono">₦1,512.40 / $</span></div>
            <div className="flex justify-between border-t border-slate-200 pt-1.5 font-bold"><span>Total NGN</span><span className="font-mono">₦72,897,680</span></div>
          </div>
          <div className="mt-3 flex gap-1.5">
            {["0–30", "31–60", "61–90", "90+"].map((b, i) => (
              <div key={b} className="flex-1 rounded-lg bg-slate-100 p-1.5 text-center">
                <p className="text-[9px] text-slate-500">{b} d</p>
                <p className="text-[11px] font-bold">{["$212k", "$64k", "$18k", "$4k"][i]}</p>
              </div>
            ))}
          </div>
        </div>
      );
    case "portal":
      return (
        <div className="space-y-2">
          {[
            ["e-BDN · MV Atlantic Grace", "Signed · 2 parties", Icon.FileText],
            ["POD · WB-2026-104882", "Buyer e-signature", Icon.Pen],
            ["Hydrotest certificate · TL-04", "API 1110", Icon.Gauge],
            ["MPI report · Weld W-2231", "NDT", Icon.Eye],
          ].map(([t, s, I], i) => {
            const C = I as ComponentType<{ size?: number }>;
            return (
              <div key={i} className="flex items-center gap-3 rounded-2xl bg-white/[0.04] p-2.5">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-sky/15 text-sky-300">
                  <C size={17} />
                </span>
                <div className="flex-1">
                  <p className="text-[13px] font-semibold text-white">{t as string}</p>
                  <p className="text-[11px] text-slate-500">{s as string}</p>
                </div>
                <Icon.Eye size={16} className="text-slate-500" />
              </div>
            );
          })}
        </div>
      );
    case "owner":
      return (
        <div className="grid grid-cols-2 gap-2.5">
          {[
            ["Turnaround", "6.4 h", "−11%"],
            ["Shrinkage", "0.18%", "Below 0.5%"],
            ["Reconciled", "98.2%", "Today"],
            ["Cert. risk", "17", "Next 30 d"],
          ].map(([a, b, c]) => (
            <div key={a} className="rounded-2xl bg-white/[0.05] p-3">
              <p className="text-[11.5px] text-slate-400">{a}</p>
              <p className="mt-1 text-2xl font-extrabold text-white">{b}</p>
              <p className="text-[10.5px] font-semibold text-gold">{c}</p>
            </div>
          ))}
          <div className="col-span-2 rounded-2xl bg-white/[0.04] p-3">
            <Bars seed={51} n={20} />
          </div>
        </div>
      );
  }
}

/* ------------------------------------------------------------------ */

export function Modules() {
  const [group, setGroup] = useState<(typeof groups)[number]>("All");
  const [sel, setSel] = useState(1);
  const list = modules.filter((m) => group === "All" || m.group === group);
  const m = modules.find((x) => x.n === sel) ?? modules[0];
  const MI = m.icon;

  return (
    <section id="modules" className="relative scroll-mt-24 px-4 py-24 sm:px-6 md:py-28">
      <div className="absolute inset-x-0 top-0 -z-10 h-[600px] bg-[radial-gradient(ellipse_at_top,rgba(2,132,199,0.18),transparent_60%)]" />
      <div className="mx-auto max-w-[1440px]">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="12 modules · one ledger"
            title={
              <>
                License what you run today. <span className="text-gradient">Add the rest as you grow.</span>
              </>
            }
            sub="Modules are grouped by who buys them. A Starter customer may license one or two; a multi-service contractor runs the full suite on one audit trail."
          />
          <Reveal className="flex flex-wrap gap-2">
            {groups.map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => {
                  setGroup(g);
                  const first = modules.find((x) => g === "All" || x.group === g);
                  if (first) setSel(first.n);
                }}
                className={`rounded-full px-4 py-2 text-[13px] font-semibold transition ${
                  group === g ? "bg-white text-navy" : "bg-white/[0.05] text-slate-300 ring-1 ring-white/10 hover:bg-white/10"
                }`}
              >
                {g}
              </button>
            ))}
          </Reveal>
        </div>

        <div className="mt-12 grid gap-5 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
          {/* List */}
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 lg:mx-0 lg:flex-col lg:overflow-visible lg:px-0">
            {list.map((x) => {
              const I = x.icon;
              const on = x.n === sel;
              return (
                <button
                  key={x.n}
                  type="button"
                  onClick={() => setSel(x.n)}
                  className={`group relative flex min-w-[250px] items-center gap-4 overflow-hidden rounded-2xl p-3.5 text-left transition lg:min-w-0 ${
                    on ? "bg-gradient-to-r from-amber/20 to-amber/[0.04] ring-1 ring-amber/40" : "bg-white/[0.03] ring-1 ring-white/[0.06] hover:bg-white/[0.06]"
                  }`}
                >
                  <span
                    className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl transition ${
                      on ? "bg-gradient-to-b from-gold to-amber text-[#2a1800]" : "bg-white/[0.06] text-slate-300"
                    }`}
                  >
                    <I size={21} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="font-mono text-[10.5px] text-slate-500">{String(x.n).padStart(2, "0")}</span>
                      <span className="truncate text-[15px] font-bold text-white">{x.name}</span>
                    </span>
                    <span className="block truncate text-[12.5px] text-slate-400">{x.tag}</span>
                  </span>
                  <Icon.Chevron size={16} className={`shrink-0 transition ${on ? "text-gold" : "text-slate-600 group-hover:translate-x-0.5"}`} />
                </button>
              );
            })}
          </div>

          {/* Detail */}
          <div key={m.n} className="glass-dark relative overflow-hidden rounded-[32px] p-6 sm:p-8 lg:sticky lg:top-24 lg:self-start">
            <div className="absolute -right-32 -top-32 h-80 w-80 rounded-full bg-amber/15 blur-[100px]" />
            <div className="absolute -bottom-32 -left-20 h-72 w-72 rounded-full bg-azure/20 blur-[100px]" />
            <div className="relative">
              <div className="rise flex flex-wrap items-center gap-3">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-b from-gold to-amber text-[#2a1800] shadow-[0_10px_30px_-10px_rgba(251,191,36,0.9)]">
                  <MI size={26} />
                </span>
                <div>
                  <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-slate-500">
                    Module {String(m.n).padStart(2, "0")} · {m.group}
                  </p>
                  <h3 className="text-2xl font-extrabold tracking-tight text-white sm:text-3xl">{m.name}</h3>
                </div>
                <span className="ml-auto rounded-full bg-white/[0.07] px-3 py-1.5 text-[11.5px] font-bold text-sky-300 ring-1 ring-sky/25">{m.phase}</span>
              </div>
              <p className="rise mt-5 max-w-2xl text-[16px] leading-relaxed text-slate-300" style={{ animationDelay: "0.06s" }}>
                {m.blurb}
              </p>

              <div className="mt-7 grid gap-6 xl:grid-cols-[1fr_1fr]">
                <ul className="space-y-2.5">
                  {m.features.map((f, i) => (
                    <li key={f} className="rise flex gap-3 text-[14px] leading-relaxed text-slate-300" style={{ animationDelay: `${0.1 + i * 0.04}s` }}>
                      <span className="mt-1 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-amber/15 text-gold">
                        <Icon.Check size={12} strokeWidth={3} />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>
                <div className="rise rounded-[24px] border border-white/10 bg-white/[0.03] p-4 sm:p-5" style={{ animationDelay: "0.15s" }}>
                  <div className="mb-4 flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
                    <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
                    <span className="h-2.5 w-2.5 rounded-full bg-white/15" />
                    <span className="ml-auto inline-flex items-center gap-1.5 text-[10.5px] font-semibold text-emerald-300">
                      <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-400 text-emerald-400" /> Live preview
                    </span>
                  </div>
                  <PreviewBody kind={m.preview} />
                </div>
              </div>

              {m.addon && (
                <p className="mt-6 inline-flex items-center gap-2 rounded-xl bg-white/[0.04] px-3.5 py-2 text-[12.5px] text-slate-400 ring-1 ring-white/[0.06]">
                  <Icon.Plug size={15} className="text-gold" /> {m.addon}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
