"use client";

import Image from "next/image";
import { useState } from "react";
import { Icon, LogoMark, Wordmark } from "./icons";
import { Reveal } from "./primitives";

const hubs = [
  { city: "Lagos", coord: "6.4550° N, 3.3841° E" },
  { city: "Port Harcourt", coord: "4.8156° N, 7.0498° E" },
  { city: "Warri", coord: "5.5160° N, 5.7500° E" },
  { city: "Onne", coord: "4.7238° N, 7.1517° E" },
];

const input =
  "mt-1.5 h-12 w-full rounded-xl bg-white/[0.07] px-4 text-[15px] text-white ring-1 ring-white/10 outline-none transition placeholder:text-slate-500 focus:ring-2 focus:ring-gold/70";

export function Closing() {
  const [sent, setSent] = useState(false);
  const [email, setEmail] = useState("");

  return (
    <>
      <section id="contact" className="relative scroll-mt-24 px-3 py-20 sm:px-6">
        <Reveal className="relative mx-auto max-w-[1440px] overflow-hidden rounded-[44px] border border-white/10">
          <Image src="/images/rig-dusk.jpg" alt="Offshore platform at dusk" fill sizes="100vw" className="-z-10 object-cover object-[70%_40%]" />
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink via-ink/85 to-ink/30" />
          <div className="absolute -bottom-40 right-10 -z-10 h-[420px] w-[620px] rounded-full bg-amber/30 blur-[140px]" />
          <div className="grid gap-10 p-6 sm:p-12 lg:grid-cols-[1.15fr_0.85fr] lg:p-20">
            <div className="flex flex-col">
              <LogoMark size={52} />
              <h2 className="mt-8 text-4xl font-extrabold leading-[1.02] tracking-[-0.035em] text-white sm:text-5xl lg:text-[4.2rem]">
                Put every litre <span className="text-gradient">on record.</span>
              </h2>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-slate-300">
                Pick one module and one KPI. We run a 60-day paid pilot on your vessels, lines or trucks, then report the result back to you
                in numbers.
              </p>
              <div className="mt-8 grid max-w-xl gap-3 sm:grid-cols-3">
                {[
                  ["1", "Pick a module", "BunkerFlow, HaulTrac or SafePass"],
                  ["2", "Agree one KPI", "Shrinkage, TAT or reconciliation time"],
                  ["3", "Measure for 60 days", "Pilot fee credited if you convert"],
                ].map(([n, t, d]) => (
                  <div key={n} className="glass rounded-2xl p-4">
                    <span className="grid h-7 w-7 place-items-center rounded-lg bg-gold text-[12px] font-extrabold text-[#2a1800]">{n}</span>
                    <p className="mt-3 text-[14px] font-bold text-white">{t}</p>
                    <p className="mt-0.5 text-[12px] text-slate-400">{d}</p>
                  </div>
                ))}
              </div>
              <div className="mt-auto flex flex-wrap gap-2 pt-10">
                {hubs.map((h) => (
                  <div key={h.city} className="glass rounded-2xl px-4 py-2.5">
                    <p className="flex items-center gap-2 text-[13px] font-bold text-white">
                      <Icon.Pin size={14} className="text-gold" /> {h.city}
                    </p>
                    <p className="mt-0.5 font-mono text-[10px] text-slate-400">{h.coord}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-dark self-center rounded-[30px] p-6 sm:p-8">
              {sent ? (
                <div className="rise py-8 text-center">
                  <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-gradient-to-b from-gold to-amber text-[#2a1800]">
                    <Icon.Check size={30} strokeWidth={2.4} />
                  </span>
                  <p className="mt-5 text-2xl font-extrabold text-white">Request received</p>
                  <p className="mt-2 text-sm text-slate-400">
                    We&apos;ll contact <span className="text-white">{email}</span> within one business day to scope your pilot.
                  </p>
                </div>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSent(true);
                  }}
                  className="space-y-4"
                >
                  <div>
                    <p className="text-2xl font-extrabold text-white">Start a 60-day pilot</p>
                    <p className="mt-1 text-[13px] text-slate-400">Or book a private demo on your own data.</p>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-[12px] font-semibold text-slate-400">Full name</span>
                      <input required type="text" placeholder="Adaeze Okafor" className={input} />
                    </label>
                    <label className="block">
                      <span className="text-[12px] font-semibold text-slate-400">Company</span>
                      <input required type="text" placeholder="Delta Marine Services Ltd" className={input} />
                    </label>
                  </div>
                  <label className="block">
                    <span className="text-[12px] font-semibold text-slate-400">Work email</span>
                    <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ops@company.com" className={input} />
                  </label>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-[12px] font-semibold text-slate-400">Your business</span>
                      <select className={`${input} [&>option]:bg-navy`}>
                        <option>Multi-service contractor</option>
                        <option>Bulk haulage</option>
                        <option>Marine fuel & lubes</option>
                        <option>Pipeline integrity & NDT</option>
                        <option>Depot or terminal</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="text-[12px] font-semibold text-slate-400">Pilot KPI</span>
                      <select className={`${input} [&>option]:bg-navy`}>
                        <option>Shrinkage %</option>
                        <option>Turnaround time</option>
                        <option>Reconciliation time</option>
                        <option>Permit compliance</option>
                      </select>
                    </label>
                  </div>
                  <button type="submit" className="btn-amber flex h-13 w-full items-center justify-center gap-2 rounded-xl py-3.5 text-[15px] font-bold">
                    Request pilot <Icon.Arrow size={18} />
                  </button>
                  <p className="text-center text-[11px] text-slate-500">No commitment. Your data stays confidential under NDPA 2023.</p>
                </form>
              )}
            </div>
          </div>
        </Reveal>
      </section>

      <footer className="border-t border-white/10">
        <div className="mx-auto grid max-w-[1440px] gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <LogoMark size={36} />
              <Wordmark />
            </div>
            <p className="mt-5 max-w-xs text-[13.5px] leading-relaxed text-slate-400">
              <span className="font-semibold italic text-slate-300">Every litre, every line, on record.</span> One operating system for
              Nigerian energy service contractors.
            </p>
          </div>
          {[
            { h: "Modules", l: ["BunkerFlow", "PipeIntegrity", "RefineryLink", "HaulTrac", "EPC-Link", "SafePass"] },
            { h: "More modules", l: ["MarineStores", "TankWorks", "Compliance Shield", "Billing", "Client Portal", "Owner Dashboard"] },
            { h: "Company", l: ["Platform", "Compliance", "Pricing", "Roadmap", "Security", "Contact"] },
          ].map((c) => (
            <div key={c.h}>
              <p className="text-[11.5px] font-bold uppercase tracking-[0.18em] text-slate-500">{c.h}</p>
              <ul className="mt-4 space-y-2.5">
                {c.l.map((x) => (
                  <li key={x}>
                    <a
                      href={c.h === "Company" ? `#${x === "Platform" ? "platform" : x.toLowerCase()}` : "#modules"}
                      className="text-[14px] text-slate-300 transition hover:text-gold"
                    >
                      {x}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-white/5">
          <div className="mx-auto flex max-w-[1440px] flex-col gap-2 px-4 py-6 text-[11.5px] text-slate-500 sm:px-6 md:flex-row md:items-center md:justify-between">
            <p>© {new Date().getFullYear()} PetroLedger Energy OS. A PetroLogix Core product.</p>
            <p>
              Photography: &ldquo;Holstein at Dusk&rdquo; &amp; &ldquo;Oil Platform Crew Transfer&rdquo; by GuavaTrain (CC0) · BSEE (public domain), via
              Wikimedia Commons.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
