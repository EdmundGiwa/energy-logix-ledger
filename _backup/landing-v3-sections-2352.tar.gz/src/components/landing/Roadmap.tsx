"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const segments = [
  { n: "01", t: "Multi-service contractors", d: "Pipeline, marine and procurement in one firm. The best fit for the full suite.", icon: Icon.Layers },
  { n: "02", t: "Bulk haulage firms", d: "Lekki-Epe corridor operators. Micro and Starter tiers.", icon: Icon.Truck },
  { n: "03", t: "Marine fuel & lube suppliers", d: "Lagos, Port Harcourt, Onne and Warri. Led by BunkerFlow.", icon: Icon.Ship },
  { n: "04", t: "Pipeline integrity & NDT", d: "Contractors serving IOCs. PipeIntegrity plus the NCDMB pack.", icon: Icon.Pipe },
  { n: "05", t: "Depots & terminals", d: "Tank farm and gantry owners. RefineryLink, in a later phase.", icon: Icon.Tank },
];

const phases = [
  {
    p: "Phase 1",
    when: "MVP · 4–6 months",
    title: "Prove it in the field",
    items: ["Core platform: offline sync, audit log, vault", "BunkerFlow: sounding and e-BDN", "HaulTrac: e-Waybill and POD", "SafePass: PTW and expiry gate", "Pilots with 2–3 customers"],
  },
  {
    p: "Phase 2",
    when: "6–9 months",
    title: "Integrity and local content",
    items: ["PipeIntegrity: pigging, hydrotest, NDT, CP", "EPC-Link: NCDMB pack, NCFCC checker", "Compliance Shield", "Client Portal"],
  },
  {
    p: "Phase 3",
    when: "9–15 months",
    title: "Depots, stores and billing",
    items: ["RefineryLink: gantry, ATG, e-Call-Up if access allows", "MarineStores and TankWorks", "Billing and commercial", "SAP, Oracle and Odoo connectors"],
  },
  {
    p: "Phase 4",
    when: "15+ months",
    title: "Scale across West Africa",
    items: ["Whitelabel deployments", "e-BDN export interoperability", "Owner analytics", "Ghana, Côte d'Ivoire, Cameroon"],
  },
];

export function Roadmap() {
  const [active, setActive] = useState(0);

  return (
    <section id="roadmap" className="relative scroll-mt-24 px-4 py-24 sm:px-6 md:py-28">
      <div className="mx-auto max-w-[1440px]">
        {/* Segments */}
        <SectionHeading
          eyebrow="Who it's for"
          title={
            <>
              Built first for the firms <span className="text-gradient">that keep Nigeria&apos;s energy moving.</span>
            </>
          }
        />
        <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {segments.map((s, i) => {
            const I = s.icon;
            return (
              <Reveal key={s.n} delay={i * 70}>
                <div className="panel group relative h-full overflow-hidden rounded-[26px] p-5 transition duration-500 hover:-translate-y-1 hover:border-amber/30">
                  <span className="absolute right-4 top-3 font-mono text-[40px] font-extrabold leading-none text-white/[0.05] transition group-hover:text-amber/15">
                    {s.n}
                  </span>
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/[0.06] text-white transition group-hover:bg-gold group-hover:text-[#2a1800]">
                    <I size={20} />
                  </span>
                  <p className="mt-5 text-[15.5px] font-bold text-white">{s.t}</p>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-slate-400">{s.d}</p>
                </div>
              </Reveal>
            );
          })}
        </div>

        {/* Roadmap */}
        <div className="mt-28">
          <SectionHeading
            eyebrow="Roadmap"
            title={
              <>
                Ship the field core first. <span className="text-gradient-azure">Then widen the ledger.</span>
              </>
            }
            sub="Every phase is built with a domain advisor for that module, and a pilot reference comes before the next one starts."
          />

          <div className="relative mt-14">
            {/* Track */}
            <div className="absolute left-0 right-0 top-[27px] hidden h-[3px] rounded-full bg-white/10 lg:block">
              <div
                className="h-full rounded-full bg-gradient-to-r from-sky via-gold to-amber transition-all duration-700"
                style={{ width: `${(active / (phases.length - 1)) * 100}%` }}
              />
            </div>
            <div className="grid gap-4 lg:grid-cols-4">
              {phases.map((ph, i) => {
                const on = i === active;
                return (
                  <Reveal key={ph.p} delay={i * 90}>
                    <button
                      type="button"
                      onMouseEnter={() => setActive(i)}
                      onFocus={() => setActive(i)}
                      onClick={() => setActive(i)}
                      className="group block h-full w-full text-left"
                    >
                      <span
                        className={`relative z-10 grid h-14 w-14 place-items-center rounded-2xl text-[15px] font-extrabold transition duration-500 ${
                          i <= active ? "bg-gradient-to-b from-gold to-amber text-[#2a1800] shadow-[0_10px_30px_-10px_rgba(251,191,36,0.9)]" : "bg-navy-2 text-white ring-1 ring-white/15"
                        }`}
                      >
                        {i + 1}
                      </span>
                      <div
                        className={`mt-5 h-[calc(100%-76px)] rounded-[26px] p-6 transition duration-500 ${
                          on ? "glass-dark ring-1 ring-amber/35" : "panel"
                        }`}
                      >
                        <p className="text-[11.5px] font-bold uppercase tracking-[0.16em] text-sky-300">
                          {ph.p} · {ph.when}
                        </p>
                        <p className="mt-2 text-[19px] font-extrabold text-white">{ph.title}</p>
                        <ul className="mt-4 space-y-2">
                          {ph.items.map((it) => (
                            <li key={it} className="flex gap-2.5 text-[13.5px] text-slate-300">
                              <span className={`mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full ${on ? "bg-gold" : "bg-white/30"}`} /> {it}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </button>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
