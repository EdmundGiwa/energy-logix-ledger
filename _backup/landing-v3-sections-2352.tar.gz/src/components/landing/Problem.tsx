import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const standards = [
  "NCDMB · NOGIC-JQS",
  "NUPRC",
  "NMDPRA",
  "NIMASA",
  "Nigerian Ports Authority",
  "MARPOL Annex VI",
  "ASTM D1250 · Tables 54B / 56",
  "API MPMS",
  "API 1110",
  "ASME B31.4 · B31.8",
  "ISO 9001 · 14001 · 45001",
  "ISO 13623",
  "NDPA 2023",
];

const buyers = [
  {
    role: "Operations GM",
    icon: Icon.Gauge,
    pain: "Shrinkage and turnaround",
    line: "Every sounding, meter ticket and discharge reconciles as it happens, not at month-end.",
  },
  {
    role: "Managing Director",
    icon: Icon.Building,
    pain: "Tender wins and NCDMB status",
    line: "NCFCC readiness, NOGIC-JQS packs and bid dossiers are ready before the tender closes.",
  },
  {
    role: "HSE Manager",
    icon: Icon.Shield,
    pain: "Permit compliance",
    line: "Expired credentials block the manifest. Failed gas tests lock the permit.",
  },
];

type Cell = "yes" | "part" | "no";
const rows: { cap: string; cells: [Cell, Cell, Cell, Cell] }[] = [
  { cap: "e-BDN and bunker reconciliation", cells: ["yes", "no", "part", "yes"] },
  { cap: "Pipeline integrity: pigging, hydrotest, CP", cells: ["no", "no", "part", "yes"] },
  { cap: "Depot, gantry and tank reconciliation", cells: ["no", "yes", "part", "yes"] },
  { cap: "Bulk haulage e-Waybill and POD", cells: ["no", "part", "part", "yes"] },
  { cap: "NCDMB, NCFCC and NOGIC-JQS exports", cells: ["no", "no", "no", "yes"] },
  { cap: "Offline-first field apps", cells: ["part", "part", "no", "yes"] },
  { cap: "One ledger across service lines", cells: ["no", "no", "yes", "yes"] },
];
const cols = ["Global bunker suites", "Depot tools", "ERP partners", "PetroLedger"];

function Mark({ v, hi }: { v: Cell; hi?: boolean }) {
  if (v === "yes")
    return (
      <span className={`grid h-7 w-7 place-items-center rounded-full ${hi ? "bg-gradient-to-b from-gold to-amber text-[#2a1800]" : "bg-white/10 text-white"}`}>
        <Icon.Check size={15} strokeWidth={2.4} />
      </span>
    );
  if (v === "part") return <span className="grid h-7 w-7 place-items-center rounded-full ring-1 ring-white/20"><span className="h-3.5 w-1.5 rounded-l-full bg-white/50" style={{ marginRight: 6 }} /></span>;
  return <span className="block h-[2px] w-4 rounded-full bg-white/15" />;
}

export function Problem() {
  return (
    <section className="relative">
      {/* Standards marquee */}
      <div className="relative border-y border-white/[0.06] bg-white/[0.02] py-5">
        <p className="mb-3 text-center text-[11px] font-bold uppercase tracking-[0.24em] text-slate-500">
          Designed in line with the rules your clients audit you against
        </p>
        <div className="relative overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]">
          <div className="animate-marquee flex w-max gap-3">
            {[...standards, ...standards].map((t, i) => (
              <span
                key={i}
                className="whitespace-nowrap rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-[13px] font-semibold text-slate-300"
              >
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1440px] px-4 py-24 sm:px-6 md:py-28">
        <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
          <div>
            <SectionHeading
              eyebrow="Why PetroLedger"
              title={
                <>
                  Global tools cover one step. <span className="text-gradient">Your firm runs all of them.</span>
                </>
              }
              sub="A Lagos contractor can run pigging, NDT and cathodic protection one week, supply marine fuel and lubes the next, and haul product on the Lekki-Epe corridor all year. Bunker suites, depot tools and ERP add-ons each cover one part. PetroLedger puts all of it on one ledger, built for Nigerian conditions."
            />
            <div className="mt-10 space-y-3">
              {buyers.map((b, i) => {
                const I = b.icon;
                return (
                  <Reveal key={b.role} delay={i * 90}>
                    <div className="panel group flex gap-4 rounded-3xl p-5 transition hover:border-amber/30">
                      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-amber/10 text-gold ring-1 ring-amber/25 transition group-hover:bg-amber/20">
                        <I size={22} />
                      </span>
                      <div>
                        <p className="text-[12px] font-bold uppercase tracking-[0.16em] text-slate-500">{b.role}</p>
                        <p className="mt-1 text-[17px] font-bold text-white">{b.pain}</p>
                        <p className="mt-1 text-[14.5px] leading-relaxed text-slate-400">{b.line}</p>
                      </div>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>

          <Reveal delay={120}>
            <div className="glass-dark relative overflow-hidden rounded-[32px] p-2">
              <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-amber/20 blur-[90px]" />
              <div className="relative overflow-x-auto no-scrollbar">
                <table className="w-full min-w-[620px] border-separate border-spacing-0 text-left">
                  <thead>
                    <tr>
                      <th className="p-5 text-[12px] font-bold uppercase tracking-[0.16em] text-slate-500">Capability</th>
                      {cols.map((c, i) => (
                        <th
                          key={c}
                          className={`p-5 text-center text-[12.5px] font-bold ${
                            i === 3 ? "rounded-t-3xl bg-gradient-to-b from-amber/20 to-amber/5 text-gold" : "text-slate-300"
                          }`}
                        >
                          {c}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r, ri) => (
                      <tr key={r.cap} className="group">
                        <td className="border-t border-white/[0.06] p-5 text-[14px] font-semibold text-white">{r.cap}</td>
                        {r.cells.map((v, i) => (
                          <td
                            key={i}
                            className={`border-t border-white/[0.06] p-5 ${i === 3 ? "bg-amber/[0.06]" : ""} ${
                              i === 3 && ri === rows.length - 1 ? "rounded-b-3xl" : ""
                            }`}
                          >
                            <div className="flex justify-center">
                              <Mark v={v} hi={i === 3} />
                            </div>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 px-5 pb-4 pt-2 text-[11.5px] text-slate-500">
                <span className="inline-flex items-center gap-2"><Mark v="yes" /> Core strength</span>
                <span className="inline-flex items-center gap-2"><Mark v="part" /> Partial or via customisation</span>
                <span>Category-level view based on public product information.</span>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
