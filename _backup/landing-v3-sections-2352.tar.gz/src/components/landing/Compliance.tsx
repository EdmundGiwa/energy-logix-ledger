"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const matrix = [
  { reg: "NCDMB / NOGICD Act 2010", kind: "Regulator", req: "Nigerian content spend, NCFCC, NCEC, JQS registration", mods: ["EPC-Link", "Compliance Shield"] },
  { reg: "NUPRC", kind: "Regulator", req: "Permits, pipeline integrity", mods: ["PipeIntegrity", "Compliance Shield"] },
  { reg: "NMDPRA", kind: "Regulator", req: "Wholesale metering, depot accuracy", mods: ["RefineryLink"] },
  { reg: "NIMASA", kind: "Regulator", req: "Cabotage, crew, vessel permits", mods: ["SafePass", "Compliance Shield"] },
  { reg: "Nigerian Ports Authority", kind: "Regulator", req: "Port operations", mods: ["BunkerFlow"] },
  { reg: "MARPOL Annex VI", kind: "Convention", req: "Fuel quality records, BDN", mods: ["BunkerFlow"] },
  { reg: "ASTM D1250 · Tables 54/56", kind: "Standard", req: "Measurement conversion", mods: ["BunkerFlow", "RefineryLink"] },
  { reg: "API MPMS", kind: "Standard", req: "Measurement", mods: ["RefineryLink"] },
  { reg: "API 1110 · ASME B31.4 / B31.8", kind: "Standard", req: "Hydrotest", mods: ["PipeIntegrity"] },
  { reg: "ISO 9001 · 14001 · 45001", kind: "Standard", req: "Quality, environment, safety", mods: ["Compliance Shield"] },
  { reg: "ISO 13623", kind: "Standard", req: "Pipeline systems", mods: ["PipeIntegrity"] },
  { reg: "NDPA 2023", kind: "Law", req: "Personal data", mods: ["Core Platform"] },
];

const kinds = ["All", "Regulator", "Standard", "Convention", "Law"] as const;

export function Compliance() {
  const [k, setK] = useState<(typeof kinds)[number]>("All");
  const rows = matrix.filter((r) => k === "All" || r.kind === k);

  return (
    <section id="compliance" className="relative scroll-mt-24 px-4 py-24 sm:px-6 md:py-28">
      <div className="absolute inset-x-0 top-1/3 -z-10 h-[600px] bg-[radial-gradient(ellipse_at_center,rgba(217,119,6,0.12),transparent_60%)]" />
      <div className="mx-auto max-w-[1440px]">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <SectionHeading
              eyebrow="Compliance matrix"
              title={
                <>
                  Audit-ready for <span className="text-gradient">every regulator you answer to.</span>
                </>
              }
              sub="Each requirement is linked to the module that records the evidence. PetroLedger exports to NCDMB's NOGIC-JQS portal and works alongside it. It does not replace it."
            />

            <Reveal delay={100} className="mt-10">
              <div className="glass-amber relative overflow-hidden rounded-[30px] p-6">
                <div className="flex items-center gap-3">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/90 text-navy">
                    <Icon.Shield size={22} />
                  </span>
                  <div>
                    <p className="text-[12px] font-bold uppercase tracking-[0.16em] text-white/70">Start here</p>
                    <p className="text-xl font-extrabold text-white">NCFCC readiness checker</p>
                  </div>
                </div>
                <p className="mt-4 text-[14.5px] leading-relaxed text-white/90">
                  NCDMB will not issue NCEC equipment certificates and approvals without a valid NCDF Compliance Certificate.
                  The checker shows your gaps and sends renewal alerts before they cost you a tender.
                </p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {["90 d", "60 d", "30 d", "7 d"].map((d) => (
                    <span key={d} className="rounded-full bg-black/20 px-3 py-1 text-[12px] font-bold text-white ring-1 ring-white/20">
                      Alert at {d}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>

          <div>
            <Reveal className="flex flex-wrap gap-2">
              {kinds.map((x) => (
                <button
                  key={x}
                  type="button"
                  onClick={() => setK(x)}
                  className={`rounded-full px-4 py-2 text-[13px] font-semibold transition ${
                    k === x ? "bg-white text-navy" : "bg-white/[0.05] text-slate-300 ring-1 ring-white/10 hover:bg-white/10"
                  }`}
                >
                  {x}
                </button>
              ))}
            </Reveal>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {rows.map((r, i) => (
                <div
                  key={r.reg}
                  className="panel rise group relative overflow-hidden rounded-[24px] p-5 transition duration-500 hover:-translate-y-1 hover:border-amber/30"
                  style={{ animationDelay: `${i * 0.04}s` }}
                >
                  <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-amber/0 blur-2xl transition duration-500 group-hover:bg-amber/20" />
                  <div className="flex items-start justify-between gap-3">
                    <p className="text-[16px] font-extrabold leading-snug text-white">{r.reg}</p>
                    <span className="shrink-0 rounded-full bg-white/[0.06] px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider text-slate-400">
                      {r.kind}
                    </span>
                  </div>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-slate-400">{r.req}</p>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {r.mods.map((m) => (
                      <span key={m} className="inline-flex items-center gap-1.5 rounded-lg bg-amber/10 px-2.5 py-1 text-[12px] font-bold text-gold ring-1 ring-amber/20">
                        <Icon.Check size={12} strokeWidth={3} /> {m}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */

type Status = "Standard" | "Add-on" | "Hardware bundle" | "Connector pack" | "Vendor adapter" | "Export / upload" | "Needs agreement";
const integrations: { name: string; purpose: string; status: Status; icon: keyof typeof Icon }[] = [
  { name: "Lagos e-Call-Up", purpose: "Truck scheduling, RFID reads", status: "Needs agreement", icon: "Truck" },
  { name: "Dangote Refinery gantry", purpose: "Loading orders, meter tickets", status: "Needs agreement", icon: "Tank" },
  { name: "NOGIC-JQS (NCDMB)", purpose: "Registration, tenders, M&E", status: "Export / upload", icon: "Building" },
  { name: "NCDMB NCFCC portal", purpose: "Compliance certificate status", status: "Export / upload", icon: "Shield" },
  { name: "Weighbridges", purpose: "Tare and gross", status: "Vendor adapter", icon: "Scale" },
  { name: "AccuLoad · Smith Meter", purpose: "Gantry meter tickets", status: "Vendor adapter", icon: "Gauge" },
  { name: "Telematics providers", purpose: "Geofence, valve state", status: "Vendor adapter", icon: "Satellite" },
  { name: "SAP · Oracle · Odoo", purpose: "Financial sync", status: "Connector pack", icon: "Database" },
  { name: "QuickBooks · Sage", purpose: "Financial sync", status: "Connector pack", icon: "Receipt" },
  { name: "WhatsApp Business API", purpose: "Crew expiry bot, alerts", status: "Add-on", icon: "Message" },
  { name: "Paystack · Flutterwave", purpose: "Payments", status: "Standard", icon: "Wallet" },
  { name: "Zebra · Honeywell", purpose: "Scanners", status: "Hardware bundle", icon: "QR" },
];
const statusCls: Record<Status, string> = {
  Standard: "bg-ok/15 text-emerald-300",
  "Add-on": "bg-amber/15 text-amber-300",
  "Hardware bundle": "bg-white/10 text-slate-300",
  "Connector pack": "bg-sky/15 text-sky-300",
  "Vendor adapter": "bg-sky/15 text-sky-300",
  "Export / upload": "bg-white/10 text-slate-200",
  "Needs agreement": "bg-crit/15 text-red-300",
};

export function Integrations() {
  return (
    <section id="integrations" className="relative scroll-mt-24 px-4 pb-24 sm:px-6 md:pb-28">
      <div className="mx-auto max-w-[1440px]">
        <div className="glass-dark relative overflow-hidden rounded-[40px] p-6 sm:p-10 lg:p-14">
          <div className="absolute -right-20 top-0 h-96 w-96 animate-spin-slow rounded-full border border-dashed border-white/10" />
          <div className="absolute -right-4 top-16 h-64 w-64 animate-spin-slow rounded-full border border-white/[0.06] [animation-direction:reverse]" />
          <div className="relative grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <SectionHeading
                eyebrow="Integrations"
                title={
                  <>
                    Connector-first. <span className="text-gradient-azure">Plays well with your ERP.</span>
                  </>
                }
                sub="Large clients keep SAP, Oracle or Odoo. PetroLedger connects to them instead of competing with them. Each connection is labelled with its real status, so nothing gets promised before access is confirmed."
              />
              <div className="mt-8 flex flex-wrap gap-2">
                {(Object.keys(statusCls) as Status[]).map((s) => (
                  <span key={s} className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusCls[s]}`}>
                    {s}
                  </span>
                ))}
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {integrations.map((it, i) => {
                const I = Icon[it.icon];
                return (
                  <Reveal key={it.name} delay={(i % 3) * 70}>
                    <div className="group h-full rounded-[22px] bg-white/[0.04] p-4 ring-1 ring-white/[0.07] transition duration-500 hover:-translate-y-1 hover:bg-white/[0.07]">
                      <div className="flex items-center justify-between">
                        <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/[0.07] text-white transition group-hover:bg-gold group-hover:text-[#2a1800]">
                          <I size={19} />
                        </span>
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${statusCls[it.status]}`}>{it.status}</span>
                      </div>
                      <p className="mt-4 text-[14.5px] font-bold text-white">{it.name}</p>
                      <p className="mt-0.5 text-[12.5px] text-slate-400">{it.purpose}</p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
