"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

type Cur = "USD" | "NGN";

const tiers = [
  {
    name: "Micro Haulage",
    badge: "New",
    usd: 3600,
    ngn: 5_500_000,
    scope: "Up to 10 trucks · 1 depot",
    features: ["HaulTrac lite", "e-Waybill", "2 admin seats", "Offline field app"],
  },
  {
    name: "Starter",
    usd: 9500,
    ngn: 14_500_000,
    scope: "Up to 35 crew · 2 vessels or 10 trucks",
    features: ["SafePass and field PTW", "BunkerFlow or HaulTrac", "2 admin seats", "Setup from $4,000"],
  },
  {
    name: "Growth",
    featured: true,
    usd: 22500,
    ngn: 34_000_000,
    scope: "Up to 120 crew · 6 vessels · 30 trucks · 2 yards",
    features: ["BunkerFlow, PipeIntegrity, HaulTrac", "Compliance Shield", "NCFCC checker and JQS pack", "8 admin seats"],
  },
  {
    name: "Enterprise",
    usd: 48000,
    ngn: 72_000_000,
    scope: "Up to 400 crew · 15 vessels · 100 trucks · unlimited yards",
    features: ["Full suite incl. RefineryLink, EPC-Link", "Client Portal included", "API access", "24/7 account team"],
  },
  {
    name: "Whitelabel",
    from: true,
    usd: 75000,
    ngn: 112_500_000,
    scope: "Dedicated single-tenant cloud · custom domain",
    features: ["Everything", "Your branding and domain", "Private database", "SAP / Oracle connectors"],
  },
];

const addons: { name: string; usd: number; ngn: number; note?: string }[] = [
  { name: "Lagos e-Call-Up connector", usd: 500, ngn: 750_000, note: "After API access is confirmed" },
  { name: "Gantry / Dangote bridge", usd: 500, ngn: 750_000, note: "Commercial agreement required" },
  { name: "Intelligent pigging ingestion", usd: 750, ngn: 1_125_000 },
  { name: "WhatsApp crew-expiry bot", usd: 250, ngn: 375_000 },
  { name: "Cathodic protection & asset integrity", usd: 400, ngn: 600_000 },
  { name: "TankWorks job costing", usd: 350, ngn: 525_000 },
  { name: "MarineStores", usd: 300, ngn: 450_000 },
  { name: "Refrigerant gas tracking", usd: 150, ngn: 225_000 },
  { name: "e-BDN export interoperability", usd: 400, ngn: 600_000 },
  { name: "NCFCC / NOGIC-JQS export pack", usd: 250, ngn: 375_000, note: "Free in Growth and above" },
  { name: "Client Portal", usd: 300, ngn: 450_000, note: "Free in Enterprise" },
];

const oneTime = [
  ["Starter setup", "$4,000", "₦6,000,000"],
  ["Growth setup", "$8,000", "₦12,000,000"],
  ["Enterprise setup", "$12k – $20k", "₦18M – ₦30M"],
  ["Whitelabel setup", "$25k – $60k", "₦37.5M – ₦90M"],
  ["Site integration (weighbridge or flowmeter)", "$3k – $8k / site", "₦4.5M – ₦12M"],
  ["Hardware (scanners, rugged tablets)", "Cost + 15%", "Cost + 15%"],
];
const support = [
  ["Standard (business hours, 5 days)", "Included", "Included"],
  ["Priority (extended hours, 4-hour response)", "$6,000 / yr", "₦9,000,000 / yr"],
  ["24/7 dedicated", "$18,000 / yr", "₦27,000,000 / yr"],
  ["Additional training days", "$800 / day", "₦1,200,000 / day"],
];

const terms = [
  { k: 1, label: "Annual", off: 0 },
  { k: 2, label: "2 years", off: 0.08 },
  { k: 3, label: "3 years", off: 0.12 },
];

function money(n: number, cur: Cur) {
  if (cur === "USD") return "$" + Math.round(n).toLocaleString("en-US");
  if (n >= 1_000_000) return "₦" + (n / 1_000_000).toLocaleString("en-US", { maximumFractionDigits: 2 }) + "M";
  return "₦" + Math.round(n).toLocaleString("en-US");
}

function Toggle<T extends string | number>({ value, options, onChange }: { value: T; options: { k: T; label: string; hint?: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="inline-flex rounded-2xl bg-white/[0.05] p-1 ring-1 ring-white/10">
      {options.map((o) => (
        <button
          key={String(o.k)}
          type="button"
          onClick={() => onChange(o.k)}
          className={`relative rounded-xl px-4 py-2 text-[13px] font-bold transition ${value === o.k ? "bg-white text-navy shadow" : "text-slate-300 hover:text-white"}`}
        >
          {o.label}
          {o.hint && <span className={`ml-1.5 text-[11px] ${value === o.k ? "text-emerald-600" : "text-emerald-300"}`}>{o.hint}</span>}
        </button>
      ))}
    </div>
  );
}

function Slider({ label, value, display, min, max, step, onChange }: { label: string; value: number; display: string; min: number; max: number; step: number; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <div className="flex items-center justify-between text-[13px]">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono font-bold text-white">{display}</span>
      </div>
      <input type="range" className="mt-3 w-full" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}

function Roi() {
  const [stem, setStem] = useState(1000);
  const [price, setPrice] = useState(600);
  const [loss, setLoss] = useState(0.5);
  const [stems, setStems] = useState(10);
  const perStem = stem * price * (loss / 100);
  const yearly = perStem * stems * 12;

  return (
    <div className="glass-dark relative overflow-hidden rounded-[32px] p-6 sm:p-8">
      <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-amber/20 blur-[90px]" />
      <div className="relative grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <div>
          <p className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.18em] text-gold">
            <Icon.Chart size={15} /> Shrinkage calculator
          </p>
          <p className="mt-2 text-2xl font-extrabold text-white">What is 0.5% worth on your stems?</p>
          <div className="mt-6 space-y-6">
            <Slider label="Stem volume" value={stem} display={`${stem.toLocaleString()} MT`} min={100} max={5000} step={50} onChange={setStem} />
            <Slider label="Fuel price (assumed, replace with benchmark)" value={price} display={`$${price} / MT`} min={300} max={1200} step={10} onChange={setPrice} />
            <Slider label="Shrinkage recovered" value={loss} display={`${loss.toFixed(2)}%`} min={0.1} max={1.5} step={0.05} onChange={setLoss} />
            <Slider label="Stems per month" value={stems} display={String(stems)} min={1} max={60} step={1} onChange={setStems} />
          </div>
        </div>
        <div className="flex flex-col justify-between rounded-[26px] bg-gradient-to-b from-amber/25 to-amber/5 p-6 ring-1 ring-amber/30">
          <div>
            <p className="text-[13px] text-white/70">Per stem</p>
            <p className="text-3xl font-extrabold text-white">{money(perStem, "USD")}</p>
            <p className="mt-5 text-[13px] text-white/70">Per year</p>
            <p className="text-5xl font-extrabold tracking-tight text-gradient">{money(yearly, "USD")}</p>
          </div>
          <p className="mt-6 text-[12px] leading-relaxed text-white/60">
            Formula: stem volume × price per MT × shrinkage %. These figures are illustrative, not a promise. We prove the number in a 60-day
            paid pilot using your own data.
          </p>
        </div>
      </div>
    </div>
  );
}

export function Pricing() {
  const [cur, setCur] = useState<Cur>("USD");
  const [term, setTerm] = useState(1);
  const [tab, setTab] = useState<"addons" | "onetime" | "support">("addons");
  const off = terms.find((t) => t.k === term)!.off;

  return (
    <section id="pricing" className="relative scroll-mt-24 px-4 py-24 sm:px-6 md:py-28">
      <div className="absolute inset-x-0 top-0 -z-10 h-[700px] bg-[radial-gradient(ellipse_at_top,rgba(245,158,11,0.13),transparent_60%)]" />
      <div className="mx-auto max-w-[1440px]">
        <SectionHeading
          center
          eyebrow="Pricing · annual, prepaid"
          title={
            <>
              Start with ten trucks. <span className="text-gradient">Scale to a private cloud.</span>
            </>
          }
          sub="Indicative pricing. Naira prices use roughly ₦1,500–₦1,527 per dollar, are reset every quarter, and every quote states the rate used."
        />

        <Reveal className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Toggle value={cur} onChange={setCur} options={[{ k: "USD", label: "USD $" }, { k: "NGN", label: "NGN ₦" }]} />
          <Toggle
            value={term}
            onChange={setTerm}
            options={terms.map((t) => ({ k: t.k, label: t.label, hint: t.off ? `−${t.off * 100}%` : undefined }))}
          />
        </Reveal>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {tiers.map((t, i) => {
            const base = cur === "USD" ? t.usd : t.ngn;
            const price = base * (1 - off);
            return (
              <Reveal key={t.name} delay={i * 70} className={t.featured ? "xl:-mt-4" : ""}>
                <div
                  className={`relative flex h-full flex-col overflow-hidden rounded-[30px] p-6 transition duration-500 hover:-translate-y-1 ${
                    t.featured ? "glass-amber shadow-[0_40px_90px_-30px_rgba(245,158,11,0.6)]" : "panel"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <p className="text-[17px] font-extrabold text-white">{t.name}</p>
                    {t.featured && <span className="rounded-full bg-white px-2.5 py-1 text-[10.5px] font-extrabold text-navy">Most popular</span>}
                    {t.badge && <span className="rounded-full bg-sky/15 px-2.5 py-1 text-[10.5px] font-bold text-sky-300">{t.badge}</span>}
                  </div>
                  <p className={`mt-1.5 min-h-[40px] text-[12.5px] leading-snug ${t.featured ? "text-white/80" : "text-slate-400"}`}>{t.scope}</p>
                  <div className="mt-5">
                    {t.from && <span className={`text-[12px] font-semibold ${t.featured ? "text-white/70" : "text-slate-400"}`}>From </span>}
                    <span key={`${cur}-${term}`} className="fade-in text-[34px] font-extrabold tracking-tight text-white">
                      {money(price, cur)}
                    </span>
                    <span className={`text-[13px] ${t.featured ? "text-white/70" : "text-slate-500"}`}> / yr</span>
                    {off > 0 && <p className="text-[11.5px] font-semibold text-emerald-300">Save {money(base * off, cur)} a year</p>}
                  </div>
                  <ul className="mt-6 flex-1 space-y-2.5">
                    {t.features.map((f) => (
                      <li key={f} className={`flex gap-2.5 text-[13.5px] ${t.featured ? "text-white" : "text-slate-300"}`}>
                        <Icon.Check size={16} className={`mt-0.5 shrink-0 ${t.featured ? "text-white" : "text-gold"}`} /> {f}
                      </li>
                    ))}
                  </ul>
                  <a
                    href="#contact"
                    className={`mt-7 flex h-12 items-center justify-center gap-2 rounded-2xl text-[14px] font-bold transition ${
                      t.featured ? "bg-white text-navy hover:bg-canvas" : "bg-white/[0.07] text-white ring-1 ring-white/15 hover:bg-white/[0.12]"
                    }`}
                  >
                    {t.from ? "Talk to us" : "Start a pilot"} <Icon.Arrow size={16} />
                  </a>
                </div>
              </Reveal>
            );
          })}
        </div>

        {/* Pilot banner */}
        <Reveal className="mt-5">
          <div className="relative overflow-hidden rounded-[30px] bg-gradient-to-r from-azure/30 via-navy-2/60 to-amber/25 p-6 ring-1 ring-white/10 sm:p-8">
            <div className="shimmer absolute inset-0 opacity-40" />
            <div className="relative flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div className="flex gap-4">
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white text-navy">
                  <Icon.Flask size={26} />
                </span>
                <div>
                  <p className="text-xl font-extrabold text-white">60-day paid pilot on one module</p>
                  <p className="mt-1 max-w-2xl text-[14px] text-slate-300">
                    {cur === "USD" ? "$2,500" : "₦3,750,000"}, credited against your first year if you convert within 60 days. We agree one
                    KPI up front (shrinkage, turnaround or reconciliation time) and report it back to you.
                  </p>
                </div>
              </div>
              <a href="#contact" className="btn-amber inline-flex shrink-0 items-center justify-center gap-2 rounded-2xl px-6 py-4 text-[15px] font-bold">
                Book a pilot <Icon.Arrow size={18} />
              </a>
            </div>
          </div>
        </Reveal>

        <div className="mt-5 grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
          {/* Add-ons etc */}
          <Reveal>
            <div className="panel h-full rounded-[32px] p-6 sm:p-8">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-xl font-extrabold text-white">Extras</p>
                <Toggle
                  value={tab}
                  onChange={setTab}
                  options={[
                    { k: "addons", label: "Add-ons" },
                    { k: "onetime", label: "One-time" },
                    { k: "support", label: "Support" },
                  ]}
                />
              </div>
              <div key={tab + cur} className="mt-5 divide-y divide-white/[0.06]">
                {tab === "addons" &&
                  addons.map((a, i) => (
                    <div key={a.name} className="rise flex items-center justify-between gap-4 py-3" style={{ animationDelay: `${i * 0.03}s` }}>
                      <div className="min-w-0">
                        <p className="text-[14px] font-semibold text-white">{a.name}</p>
                        {a.note && <p className="text-[12px] text-slate-500">{a.note}</p>}
                      </div>
                      <p className="shrink-0 font-mono text-[13.5px] font-bold text-gold">
                        {money(cur === "USD" ? a.usd : a.ngn, cur)}
                        <span className="text-slate-500"> /mo</span>
                      </p>
                    </div>
                  ))}
                {tab !== "addons" &&
                  (tab === "onetime" ? oneTime : support).map(([a, u, n], i) => (
                    <div key={a} className="rise flex items-center justify-between gap-4 py-3.5" style={{ animationDelay: `${i * 0.04}s` }}>
                      <p className="text-[14px] font-semibold text-white">{a}</p>
                      <p className="shrink-0 text-right font-mono text-[13.5px] font-bold text-gold">{cur === "USD" ? u : n}</p>
                    </div>
                  ))}
              </div>
              <div className="mt-5 grid gap-2 text-[12px] text-slate-500 sm:grid-cols-2">
                <p className="flex gap-2"><Icon.Check size={14} className="mt-0.5 shrink-0 text-slate-400" /> Growth and above: 50% on signing, 50% at go-live</p>
                <p className="flex gap-2"><Icon.Check size={14} className="mt-0.5 shrink-0 text-slate-400" /> Naira invoices re-priced if the rate moves more than 10%</p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <Roi />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
