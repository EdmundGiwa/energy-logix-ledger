import Image from "next/image";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

const pillars = [
  { icon: Icon.Lock, t: "Encrypted everywhere", d: "Encryption at rest and in transit, on the server and on the device cache." },
  { icon: Icon.Fingerprint, t: "Cryptographically signed", d: "Signed records carry cryptographic signatures. After sign-off, they cannot be edited." },
  { icon: Icon.Database, t: "Append-only audit log", d: "Every edit, sign-off and deletion is timestamped and attributed to a user. History is never rewritten." },
  { icon: Icon.Server, t: "In-country hosting option", d: "Host in Nigeria, in a foreign cloud region, or both. Whitelabel tenants get a private database." },
  { icon: Icon.IdCard, t: "NDPA 2023 ready", d: "Crew and driver data is handled under a Data Protection Impact Assessment and data processing agreements." },
  { icon: Icon.Key, t: "Single-tenant whitelabel", d: "A dedicated cloud tenant on your own domain and branding, with SAP and Oracle connectors." },
];

export function Security() {
  return (
    <section id="security" className="relative scroll-mt-24 px-4 py-24 sm:px-6 md:py-28">
      <div className="mx-auto max-w-[1440px]">
        <div className="relative overflow-hidden rounded-[40px] border border-white/10">
          <Image src="/images/rig-aerial.jpg" alt="" fill sizes="100vw" className="-z-10 object-cover object-[30%_50%]" />
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink via-ink/90 to-ink/60" />
          <div className="absolute inset-0 -z-10 bg-gradient-to-t from-ink/80 to-transparent" />
          <div className="grid gap-12 p-6 sm:p-10 lg:grid-cols-[0.8fr_1.2fr] lg:p-16">
            <div>
              <SectionHeading
                eyebrow="Security & data protection"
                title={
                  <>
                    Evidence you can put in front of <span className="text-gradient">an IOC auditor.</span>
                  </>
                }
                sub="A signed BDN or a hydrotest certificate is only worth something if nobody can quietly change it later. PetroLedger is built on that rule."
              />
              <Reveal delay={120} className="mt-8 rounded-2xl bg-white/[0.05] p-4 ring-1 ring-white/10">
                <p className="text-[13px] leading-relaxed text-slate-300">
                  <span className="font-bold text-white">Our language is careful on purpose.</span> The interface is designed to WCAG 2.1 AA and
                  the control-room views are designed in line with ISO 11064. Neither is a certification, so we don&apos;t call them
                  one, and neither should your tender pack.
                </p>
              </Reveal>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {pillars.map((p, i) => {
                const I = p.icon;
                return (
                  <Reveal key={p.t} delay={(i % 2) * 90}>
                    <div className="glass group h-full rounded-[24px] p-5 transition duration-500 hover:-translate-y-1">
                      <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/90 text-navy transition group-hover:bg-gold">
                        <I size={20} />
                      </span>
                      <p className="mt-4 text-[16px] font-bold text-white">{p.t}</p>
                      <p className="mt-1.5 text-[13.5px] leading-relaxed text-slate-300">{p.d}</p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
