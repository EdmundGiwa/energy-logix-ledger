"use client";

import { useEffect, useState } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading, useInView } from "./primitives";

const stages = [
  {
    key: "gantry",
    title: "Gantry loading",
    module: "RefineryLink",
    icon: Icon.Tank,
    x: 70,
    y: 150,
    points: ["Meter ticket from AccuLoad / Smith Meter", "Quality certificate linked to the batch", "GOV → NSV at 15 °C or 20 °C"],
    stat: ["Δ meter vs. ATG", "0.06%"],
  },
  {
    key: "weigh",
    title: "Weighbridge",
    module: "HaulTrac",
    icon: Icon.Scale,
    x: 250,
    y: 70,
    points: ["Tare and gross captured digitally", "Compartment seals logged", "e-Waybill issued with QR dispatch data"],
    stat: ["Net load", "34.6 t"],
  },
  {
    key: "park",
    title: "Holding park",
    module: "RefineryLink",
    icon: Icon.QR,
    x: 450,
    y: 140,
    points: ["Check-in by RFID or QR read", "Slot assignment and driver accreditation", "Plans around peak-hour truck bans (5–9am, 6–10pm)"],
    stat: ["Queue position", "#14 of 62"],
  },
  {
    key: "route",
    title: "On the corridor",
    module: "HaulTrac",
    icon: Icon.Route,
    x: 650,
    y: 66,
    points: ["Geofence and compartment-valve state via telematics", "Route deviation and unauthorised-stop alerts", "Fee and levy ledger with evidence"],
    stat: ["Deviation", "None"],
  },
  {
    key: "pod",
    title: "Discharge & POD",
    module: "HaulTrac",
    icon: Icon.Pen,
    x: 830,
    y: 150,
    points: ["Ullage, temperature and water-paste test", "Buyer e-signature on the e-Waybill", "Depot reconciliation closes on discharge"],
    stat: ["Shortage", "0.11%"],
  },
];

const PATH = "M70,150 C140,150 170,70 250,70 C330,70 360,140 450,140 C540,140 560,66 650,66 C740,66 760,150 830,150";
const STEP = 3200;

export function Corridor() {
  const [i, setI] = useState(0);
  const { ref, inView } = useInView<HTMLDivElement>(0.25);
  const s = stages[i];
  const SI = s.icon;

  useEffect(() => {
    if (!inView || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const id = setInterval(() => setI((x) => (x + 1) % stages.length), STEP);
    return () => clearInterval(id);
  }, [inView]);

  return (
    <section id="corridor" className="relative scroll-mt-24 overflow-hidden px-4 py-24 sm:px-6 md:py-28">
      <div className="absolute -left-40 top-20 -z-10 h-[500px] w-[500px] rounded-full bg-amber/10 blur-[140px]" />
      <div className="mx-auto max-w-[1440px]">
        <div className="grid gap-10 lg:grid-cols-[1fr_auto] lg:items-end">
          <SectionHeading
            eyebrow="Depot to discharge · HaulTrac + RefineryLink"
            title={
              <>
                Follow every truck from gantry to POD, <span className="text-gradient">and close the ledger at discharge.</span>
              </>
            }
            sub="Built for the Lekki-Epe corridor: holding-park queues, RFID tagging, driver accreditation and peak-hour bans. Depot reconciliation runs at every discharge instead of at month-end."
          />
          <Reveal className="flex gap-3">
            {[
              ["5", "checkpoints"],
              ["1", "e-Waybill"],
              ["0", "month-end surprises"],
            ].map(([a, b]) => (
              <div key={b} className="panel rounded-2xl px-5 py-4 text-center">
                <p className="text-3xl font-extrabold text-white">{a}</p>
                <p className="text-[11.5px] text-slate-400">{b}</p>
              </div>
            ))}
          </Reveal>
        </div>

        <Reveal className="mt-14">
          <div ref={ref} className="glass-dark relative overflow-hidden rounded-[36px] p-4 sm:p-8">
            <div className="dots-bg absolute inset-0 opacity-40 [mask-image:linear-gradient(180deg,#000,transparent)]" />

            {/* Route */}
            <div className="relative hidden md:block">
              <svg viewBox="0 0 900 220" className="w-full">
                <defs>
                  <linearGradient id="routeG" x1="0" x2="1">
                    <stop offset="0" stopColor="#38bdf8" />
                    <stop offset="1" stopColor="#fbbf24" />
                  </linearGradient>
                </defs>
                <path d={PATH} stroke="rgba(255,255,255,0.08)" strokeWidth="26" fill="none" strokeLinecap="round" />
                <path d={PATH} stroke="url(#routeG)" strokeWidth="3" fill="none" strokeDasharray="10 10" className="animate-dash" />
                {stages.map((st, k) => {
                  const on = k === i;
                  const done = k < i;
                  return (
                    <g key={st.key} onClick={() => setI(k)} className="cursor-pointer">
                      {on && <circle cx={st.x} cy={st.y} r="34" fill="rgba(251,191,36,0.18)" className="animate-glow" />}
                      <circle
                        cx={st.x}
                        cy={st.y}
                        r="22"
                        fill={on ? "#fbbf24" : done ? "#12304d" : "#0b1f33"}
                        stroke={on || done ? "#fbbf24" : "rgba(255,255,255,0.25)"}
                        strokeWidth="2"
                        style={{ transition: "fill .4s" }}
                      />
                      <text x={st.x} y={st.y + 5} textAnchor="middle" fontSize="14" fontWeight="800" fill={on ? "#2a1800" : "#fff"}>
                        {k + 1}
                      </text>
                      <text x={st.x} y={st.y + (st.y < 100 ? -36 : 46)} textAnchor="middle" fontSize="13" fontWeight="700" fill={on ? "#fff" : "rgba(255,255,255,0.55)"}>
                        {st.title}
                      </text>
                    </g>
                  );
                })}
                {/* Truck */}
                <g>
                  <circle r="9" fill="#fff" stroke="#d97706" strokeWidth="3">
                    <animateMotion dur={`${STEP * stages.length}ms`} repeatCount="indefinite" path={PATH} />
                  </circle>
                </g>
              </svg>
            </div>

            {/* Mobile stepper */}
            <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:hidden">
              {stages.map((st, k) => (
                <button
                  key={st.key}
                  type="button"
                  onClick={() => setI(k)}
                  className={`shrink-0 rounded-full px-4 py-2 text-[12.5px] font-bold ${k === i ? "bg-gold text-[#2a1800]" : "bg-white/[0.06] text-slate-300"}`}
                >
                  {k + 1}. {st.title}
                </button>
              ))}
            </div>

            {/* Detail */}
            <div key={s.key} className="relative mt-6 grid gap-5 md:mt-2 lg:grid-cols-[1.2fr_1fr_0.8fr]">
              <div className="rise flex gap-4">
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-b from-gold to-amber text-[#2a1800]">
                  <SI size={26} />
                </span>
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-sky-300">{s.module}</p>
                  <p className="text-2xl font-extrabold text-white">{s.title}</p>
                  <div className="mt-3 h-1 w-48 overflow-hidden rounded-full bg-white/10">
                    <div key={i} className="h-full origin-left bg-gold" style={{ animation: `progress ${STEP}ms linear forwards` }} />
                  </div>
                </div>
              </div>
              <ul className="rise space-y-2" style={{ animationDelay: "0.08s" }}>
                {s.points.map((p) => (
                  <li key={p} className="flex gap-2.5 text-[14px] text-slate-300">
                    <Icon.Check size={16} className="mt-0.5 shrink-0 text-gold" /> {p}
                  </li>
                ))}
              </ul>
              <div className="rise rounded-2xl bg-white/[0.05] p-4 ring-1 ring-white/10" style={{ animationDelay: "0.14s" }}>
                <p className="text-[12px] text-slate-400">{s.stat[0]}</p>
                <p className="mt-1 text-3xl font-extrabold text-white">{s.stat[1]}</p>
              </div>
            </div>
          </div>
        </Reveal>

        <div className="mt-5 grid gap-5 md:grid-cols-2">
          <Reveal>
            <div className="panel flex h-full gap-4 rounded-[28px] p-6">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-sky/10 text-sky-300 ring-1 ring-sky/20">
                <Icon.Plug size={20} />
              </span>
              <div>
                <p className="text-[16px] font-bold text-white">Lagos e-Call-Up connector</p>
                <p className="mt-1.5 text-[14px] leading-relaxed text-slate-400">
                  The e-Call-Up system is run by the Lagos State Government. PetroLedger will connect to it once API access is
                  confirmed. Until then, the holding-park queue manager works on its own.
                </p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div className="panel flex h-full gap-4 rounded-[28px] p-6">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-amber/10 text-gold ring-1 ring-amber/20">
                <Icon.Scale size={20} />
              </span>
              <div>
                <p className="text-[16px] font-bold text-white">Neutral on fees, firm on evidence</p>
                <p className="mt-1.5 text-[14px] leading-relaxed text-slate-400">
                  The fee and levy ledger records each per-truck and holding-park charge with evidence, so you can settle disputes on
                  facts. It does not endorse any levy.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
