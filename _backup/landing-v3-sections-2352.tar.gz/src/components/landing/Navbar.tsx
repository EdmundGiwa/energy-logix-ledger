"use client";

import { useEffect, useState } from "react";
import { Icon, LogoMark, Wordmark } from "./icons";

const links = [
  { href: "#modules", label: "Modules" },
  { href: "#platform", label: "Platform" },
  { href: "#corridor", label: "Corridor" },
  { href: "#compliance", label: "Compliance" },
  { href: "#pricing", label: "Pricing" },
  { href: "#roadmap", label: "Roadmap" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) if (e.isIntersecting) setActive(`#${e.target.id}`);
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    links.forEach((l) => {
      const el = document.querySelector(l.href);
      if (el) io.observe(el);
    });
    return () => {
      window.removeEventListener("scroll", onScroll);
      io.disconnect();
    };
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-5">
      <nav
        className={`mx-auto flex max-w-[1440px] items-center justify-between rounded-2xl px-3 py-2 transition-all duration-500 sm:px-4 ${
          scrolled ? "glass-dark shadow-[0_20px_60px_-20px_rgba(0,0,0,0.7)]" : "border border-transparent"
        }`}
      >
        <a href="#top" className="flex items-center gap-3" aria-label="PetroLedger home">
          <LogoMark size={38} />
          <Wordmark />
        </a>

        <ul className="hidden items-center gap-0.5 rounded-xl bg-white/[0.04] p-1 ring-1 ring-white/[0.06] lg:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className={`relative block rounded-lg px-4 py-2 text-[13.5px] font-medium transition ${
                  active === l.href ? "bg-white/10 text-white" : "text-slate-300 hover:text-white"
                }`}
              >
                {l.label}
                {active === l.href && (
                  <span className="absolute inset-x-4 -bottom-[3px] h-[2px] rounded-full bg-gradient-to-r from-transparent via-gold to-transparent" />
                )}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <a
            href="#contact"
            className="hidden rounded-lg px-3.5 py-2 text-[13.5px] font-medium text-slate-300 transition hover:text-white sm:block"
          >
            Sign in
          </a>
          <a
            href="#contact"
            className="btn-amber hidden items-center gap-1.5 rounded-xl px-4 py-2.5 text-[13.5px] font-bold sm:inline-flex"
          >
            Start a pilot <Icon.ArrowUpRight size={16} />
          </a>
          <button
            type="button"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
            className="grid h-11 w-11 place-items-center rounded-xl bg-white/[0.08] text-white ring-1 ring-white/10 lg:hidden"
          >
            {open ? <Icon.X /> : <Icon.Menu />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="glass-dark rise mx-auto mt-2 max-w-[1440px] rounded-2xl p-3 lg:hidden">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="flex items-center justify-between rounded-lg px-4 py-3 font-medium text-slate-200 hover:bg-white/[0.06]"
            >
              {l.label} <Icon.Chevron size={16} className="text-slate-500" />
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="btn-amber mt-2 flex items-center justify-center gap-1.5 rounded-xl px-4 py-3 font-bold"
          >
            Start a 60-day pilot <Icon.ArrowUpRight size={16} />
          </a>
        </div>
      )}
    </header>
  );
}
