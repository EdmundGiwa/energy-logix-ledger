"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { Icon } from "./icons";
import { Reveal, SectionHeading } from "./primitives";

type Entry = { id: number; t: string; who: string; what: string; hash: string };

const captures = [
  { who: "T. Nwosu · Barge master", what: "Sounding · Tank 2S · 1.92 m" },
  { who: "K. Ibrahim · Technician", what: "Gas test · H₂S 0 ppm · LEL 2%" },
  { who: "M. Oduya · Driver", what: "POD · WB-104882 · buyer signed" },
  { who: "R. Ekpo · Inspector", what: "CP reading · KP-46 · −0.94 V" },
  { who: "J. Afolabi · Dispatcher", what: "Weighbridge · gross 49.8 t" },
];

function hash(n: number) {
  let h = (n * 2654435761) >>> 0;
  let out = "";
  for (let i = 0; i < 8; i++) {
    out += "0123456789abcdef"[h & 15];
    h = (h >>> 4) ^ (h * 31);
  }
  return out;
}

function stamp(offsetMin: number) {
  const base = 14 * 60 + 23 + offsetMin;
  return `${String(Math.floor(base / 60) % 24).padStart(2, "0")}:${String(base % 60).padStart(2, "0")}`;
}

function FieldPhone() {
  const [online, setOnline] = useState(true);
  const [queue, setQueue] = useState<number[]>([]);
  const [syncing, setSyncing] = useState(false);
  const [log, setLog] = useState<Entry[]>(() =>
    [0, 1, 2].map((i) => ({ id: i, t: stamp(-i * 4), who: captures[i].who, what: captures[i].what, hash: hash(i + 1) }))
  );
  const counter = useRef(10);
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const capture = () => {
    counter.current += 1;
    const id = counter.current;
    if (online) {
      const c = captures[id % captures.length];
      setLog((l) => [{ id, t: stamp(id - 10), who: c.who, what: c.what, hash: hash(id) }, ...l].slice(0, 6));
    } else {
      setQueue((q) => [...q, id]);
    }
  };

  const toggle = () => {
    if (online) {
      setOnline(false);
      return;
    }
    setOnline(true);
    if (!queue.length) return;
    setSyncing(true);
    const pending = [...queue];
    pending.forEach((id, i) => {
      const t = window.setTimeout(() => {
        const c = captures[id % captures.length];
        setLog((l) => [{ id, t: stamp(id - 10), who: c.who, what: c.what, hash: hash(id) }, ...l].slice(0, 6));
        setQueue((q) => q.filter((x) => x !== id));
        if (i === pending.length - 1) setSyncing(false);
      }, 500 + i * 450);
      timers.current.push(t);
    });
  };

  return (
    <div className="grid gap-5 md:grid-cols-[300px_1fr] md:items-center">
      {/* Phone */}
      <div className="relative mx-auto w-[290px]">
        <div className="absolute -inset-10 -z-10 rounded-full bg-amber/20 blur-[80px]" />
        <div className="rounded-[46px] border border-white/15 bg-gradient-to-b from-[#1b3554] to-[#0a1726] p-2.5 shadow-[0_50px_100px_-30px_rgba(0,0,0,0.9)]">
          <div className="relative overflow-hidden rounded-[38px] bg-ink">
            <div className="flex items-center justify-between px-6 pb-2 pt-3 text-[11px] font-semibold text-white">
              <span>14:23</span>
              <span className="h-5 w-20 rounded-full bg-black" />
              <span className="flex items-center gap-1">{online ? <Icon.Wifi size={13} /> : <Icon.WifiOff size={13} className="text-amber-300" />}</span>
            </div>
            <div className="px-4 pb-4">
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-slate-500">Field app</p>
              <p className="mt-0.5 text-[18px] font-extrabold text-white">Barge PB-04</p>

              <div className={`mt-3 rounded-2xl p-3 transition-colors duration-500 ${online ? "bg-ok/10 ring-1 ring-ok/25" : "bg-amber/10 ring-1 ring-amber/30"}`}>
                <p className={`text-[12px] font-bold ${online ? "text-emerald-300" : "text-amber-300"}`}>
                  {online ? (syncing ? "Delta sync in progress…" : "Connected · VSAT link") : "Offline · working locally"}
                </p>
                <p className="mt-0.5 text-[11px] text-slate-400">
                  {online ? "Records sync as you save" : "SQLite on device. Nothing is lost."}
                </p>
              </div>

              <button
                type="button"
                onClick={capture}
                className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-white text-[13.5px] font-bold text-navy transition active:scale-[0.98]"
              >
                <Icon.Pen size={16} /> Capture reading
              </button>
              <button
                type="button"
                onClick={toggle}
                className={`mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-2xl text-[13.5px] font-bold transition active:scale-[0.98] ${
                  online ? "bg-white/[0.07] text-white ring-1 ring-white/15" : "btn-amber"
                }`}
              >
                {online ? (
                  <>
                    <Icon.WifiOff size={16} /> Simulate link drop
                  </>
                ) : (
                  <>
                    <Icon.Sync size={16} /> Reconnect and sync
                  </>
                )}
              </button>

              <div className="mt-3 min-h-[86px] space-y-1.5">
                {queue.length === 0 && <p className="pt-6 text-center text-[11px] text-slate-600">No records waiting to sync</p>}
                {queue.slice(-3).map((id) => (
                  <div key={id} className="rise flex items-center gap-2 rounded-xl bg-white/[0.05] px-2.5 py-2 text-[11px]">
                    <span className="h-1.5 w-1.5 rounded-full bg-amber" />
                    <span className="truncate text-slate-300">{captures[id % captures.length].what}</span>
                  </div>
                ))}
              </div>
            </div>
            {/* Persistent status bar */}
            <div className="flex items-center justify-between border-t border-white/10 bg-white/[0.04] px-4 py-2.5 font-mono text-[10px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className={`pulse-dot h-1.5 w-1.5 rounded-full ${online ? "bg-emerald-400 text-emerald-400" : "bg-amber text-amber"}`} />
                {online ? "Heartbeat OK" : "No link"}
              </span>
              <span>{(1284 + queue.length).toLocaleString()} cached</span>
              <span>Sync {online ? "14:23" : "14:19"}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Audit log */}
      <div className="rounded-[26px] border border-white/10 bg-black/20 p-4">
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-2 text-[14px] font-bold text-white">
            <Icon.Lock size={16} className="text-gold" /> Immutable audit log
          </p>
          <span className="rounded-full bg-white/[0.06] px-2.5 py-1 font-mono text-[10px] text-slate-400">append-only</span>
        </div>
        <div className="mt-3 space-y-2">
          {log.map((e) => (
            <div key={e.id} className="rise grid grid-cols-[44px_1fr] gap-3 rounded-2xl bg-white/[0.03] p-3 ring-1 ring-white/[0.05]">
              <span className="font-mono text-[11px] text-slate-500">{e.t}</span>
              <div className="min-w-0">
                <p className="truncate text-[13px] font-semibold text-white">{e.what}</p>
                <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] text-slate-500">
                  <span>{e.who}</span>
                  <span className="font-mono text-sky-300/80">sig {e.hash}</span>
                </p>
              </div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[11.5px] leading-relaxed text-slate-500">
          Non-critical fields resolve last-write-wins. Signed records never merge: they are immutable after sign-off, and a
          correction is a new entry.
        </p>
      </div>
    </div>
  );
}

function Bento({ title, icon, children, className = "", delay = 0 }: { title: string; icon: ReactNode; children: ReactNode; className?: string; delay?: number }) {
  return (
    <Reveal delay={delay} className={className}>
      <div className="panel group h-full rounded-[28px] p-6 transition duration-500 hover:-translate-y-1 hover:border-amber/25">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-amber/10 text-gold ring-1 ring-amber/20">{icon}</span>
          <p className="text-[16px] font-bold text-white">{title}</p>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </Reveal>
  );
}

const roles = ["MD", "GM", "Dispatcher", "Barge master", "Technician", "Driver", "Compliance officer"];
const vault = ["MTCs", "NDT reports", "Certificates", "Insurance", "NCEC", "NCFCC", "Permits"];

export function CorePlatform() {
  return (
    <section id="platform" className="relative scroll-mt-24 px-4 py-24 sm:px-6 md:py-28">
      <div className="absolute inset-0 -z-10 grid-bg [mask-image:radial-gradient(ellipse_at_center,#000_30%,transparent_75%)]" />
      <div className="mx-auto max-w-[1440px]">
        <SectionHeading
          center
          eyebrow="Core platform · included in every tier"
          title={
            <>
              Built for the field: <span className="text-gradient">no signal, no problem.</span>
            </>
          }
          sub="Every field module works offline on SQLite and delta-syncs when the link returns. Try it: drop the link, capture a few readings, then reconnect."
        />

        <Reveal className="mt-14">
          <div className="glass-dark rounded-[36px] p-5 sm:p-8">
            <FieldPhone />
          </div>
        </Reveal>

        <div className="mt-5 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          <Bento title="Role-based access" icon={<Icon.Users size={20} />} className="xl:col-span-2">
            <div className="flex flex-wrap gap-2">
              {roles.map((r) => (
                <span key={r} className="rounded-full bg-white/[0.05] px-3 py-1.5 text-[12.5px] font-semibold text-slate-300 ring-1 ring-white/10">
                  {r}
                </span>
              ))}
            </div>
            <p className="mt-4 text-[13.5px] leading-relaxed text-slate-400">Every user sees exactly what their role needs, from the MD&apos;s dashboard to the driver&apos;s waybill.</p>
          </Bento>
          <Bento title="Naira and dollar ledgers" icon={<Icon.Wallet size={20} />} delay={80}>
            <div className="flex items-end gap-3">
              <p className="text-3xl font-extrabold text-white">₦</p>
              <Icon.Sync size={18} className="mb-2 text-gold" />
              <p className="text-3xl font-extrabold text-white">$</p>
            </div>
            <p className="mt-3 text-[13.5px] leading-relaxed text-slate-400">Each transaction stores a snapshot of the rate used.</p>
          </Bento>
          <Bento title="Bilingual UI" icon={<Icon.Message size={20} />} delay={160}>
            <div className="flex gap-2">
              <span className="rounded-lg bg-gold px-2.5 py-1 text-[12px] font-bold text-[#2a1800]">English</span>
              <span className="rounded-lg bg-white/[0.06] px-2.5 py-1 text-[12px] font-semibold text-slate-400">Pidgin</span>
              <span className="rounded-lg bg-white/[0.06] px-2.5 py-1 text-[12px] font-semibold text-slate-400">Français</span>
            </div>
            <p className="mt-3 text-[13.5px] leading-relaxed text-slate-400">English first. Pidgin and French locales to follow.</p>
          </Bento>
          <Bento title="Document vault" icon={<Icon.FileText size={20} />}>
            <div className="flex flex-wrap gap-1.5">
              {vault.map((v) => (
                <span key={v} className="rounded-md bg-white/[0.05] px-2 py-1 text-[11.5px] text-slate-300">
                  {v}
                </span>
              ))}
            </div>
          </Bento>
          <Bento title="Field hardware" icon={<Icon.QR size={20} />} delay={80}>
            <p className="text-[13.5px] leading-relaxed text-slate-400">
              Supports Zebra and Honeywell scanners, and ATEX-rated phones where clients require them. Touch targets are 48 px for gloved hands.
            </p>
          </Bento>
          <Bento title="Web, tablet and phone" icon={<Icon.Monitor size={20} />} delay={160} className="xl:col-span-2">
            <div className="flex items-center gap-3">
              {[Icon.Monitor, Icon.Layers, Icon.Phone].map((I, i) => (
                <span key={i} className="grid h-12 w-12 place-items-center rounded-2xl bg-white/[0.05] text-slate-200">
                  <I size={22} />
                </span>
              ))}
              <p className="text-[13.5px] leading-relaxed text-slate-400">
                Control room on the web, rugged tablets in the yard, phones on the barge. The navy, azure and amber design system is built for glare and night shifts.
              </p>
            </div>
          </Bento>
        </div>
      </div>
    </section>
  );
}
