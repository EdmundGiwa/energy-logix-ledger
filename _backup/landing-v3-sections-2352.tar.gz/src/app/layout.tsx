import type { Metadata } from "next";
import { Manrope, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PetroLedger Energy OS — Every litre, every line, on record",
  description:
    "One operating system for Nigerian energy service contractors: bunkering and e-BDN, pipeline integrity, depot and gantry reconciliation, bulk haulage e-Waybills, NCDMB local content, permits and crew gating. Offline-first, audit-ready.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${manrope.variable} ${jetbrains.variable} antialiased`}>
      <body className="min-h-full">{children}</body>
    </html>
  );
}
